#!/usr/bin/env python3
"""Riesgos 0.2, 0.5 y 0.8: análisis emparejado de 100 bloques de 15 celdas."""
import csv
import itertools
import json
from pathlib import Path
import platform
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
from article5.io import write_csv,sha256
from tests.audit_exports import read
from run_risk import verify_manifest,read_baseline,save_json

T=ROOT/'outputs/tables'
F=ROOT/'outputs/figures'
RISKS=[.2,.5,.8]
STRATEGIES=list('ABCDE')
LABELS=dict(A='Fuerte',B='Débil / puente',C='Balanceada',D='Secuencial',E='Aleatoria')
METRICS=['new_adoptions','total_adoptions','adoption_at_12','attempts','sent','unique_reach','coverage','conversion',
         'eligible_conversion','effort_efficiency','redundancy','new_communities_adopted','fallback_rate',
         'early_extinction','viable_after_12','attempts_after_12','adoptions_after_12','extinction_month',
         'max_cascade_size','max_cascade_depth']
PAIR_METRICS=['new_adoptions','coverage','conversion','effort_efficiency','redundancy','new_communities_adopted','early_extinction']


def stats(a):
    a=np.asarray([np.nan if x is None else x for x in a],dtype=float)
    a=a[np.isfinite(a)]
    if not len(a):
        return dict(n=0,mean=None,sd=None,median=None,minimum=None,maximum=None,q1=None,q3=None,iqr=None,p05=None,p95=None)
    q=np.quantile(a,[.05,.25,.5,.75,.95],method='linear')
    return dict(n=int(len(a)),mean=float(a.mean()),sd=float(a.std(ddof=1)) if len(a)>1 else None,
                median=float(q[2]),minimum=float(a.min()),maximum=float(a.max()),q1=float(q[1]),q3=float(q[3]),
                iqr=float(q[3]-q[1]),p05=float(q[0]),p95=float(q[4]))


def interval(a):
    a=np.asarray(a);a=a[np.isfinite(a)]
    if not len(a):return dict(ci95_low=None,ci95_high=None,bootstrap_valid=0)
    q=np.quantile(a,[.025,.975],method='linear')
    return dict(ci95_low=float(q[0]),ci95_high=float(q[1]),bootstrap_valid=int(len(a)))


def nondominated(points):
    return np.array([not any(np.all(q>=p) and np.any(q>p) for q in points) for p in points])


def contrast_row(values,indices,metadata):
    return metadata | stats(values) | interval(np.nanmean(values[indices],axis=1)) | dict(
        positive=int(np.sum(values>0)),zero=int(np.sum(values==0)),negative=int(np.sum(values<0)))


def main():
    design=json.loads((ROOT/'design/risk_design.json').read_text())
    completion_path=ROOT/'outputs/checks/risk_completion.json'
    completion=json.loads(completion_path.read_text())
    assert completion['status']=='PASS' and completion['analysis_runs']==1500
    assert completion['design_sha256']==sha256(ROOT/'design/risk_design.json')
    assert completion['runner_sha256']==sha256(ROOT/'run_risk.py')
    baseline=read_baseline(design)
    data=read(T/'run_summary_1500.csv')
    by={(r['repetition_id'],r['risk'],r['strategy']):r for r in data}
    assert len(data)==len(by)==1500
    for name,digest in completion['receipt_sha256'].items():
        p=ROOT/'outputs/checks'/name
        assert sha256(p)==digest
        r=json.loads(p.read_text());prefix=r['prefix']
        manifest=ROOT/'outputs/raw'/prefix/f'{prefix}_run_manifest.json'
        assert sha256(manifest)==r['manifest_sha256'];verify_manifest(manifest)
        row=by[r['result']['repetition_id'],r['result']['risk'],r['result']['strategy']]
        assert all(row[k]==v for k,v in r['result'].items() if k not in ('model_version','configuration_version'))
    for receipt in baseline:
        r=receipt['result'];row=by[r['repetition_id'],.5,r['strategy']]
        assert all(row[k]==v for k,v in r.items() if k not in ('model_version','configuration_version'))
    for risk in RISKS:
        for s in STRATEGIES:assert sum((r['risk'],r['strategy'])==(risk,s) for r in data)==100

    rng=np.random.default_rng(design['analysis_seed'])
    indices=rng.integers(0,100,size=(2000,100))
    write_csv(T/'bootstrap_block_indices.csv',[dict(bootstrap_id=i+1,**{f'draw_{j+1:03d}':int(v)+1 for j,v in enumerate(row)}) for i,row in enumerate(indices)])
    arrays={};boots={};descriptive=[]
    for m in METRICS:
        a=np.array([[[np.nan if by[rep,risk,s][m] is None else by[rep,risk,s][m] for s in STRATEGIES]
                     for risk in RISKS] for rep in range(1,101)],dtype=float)
        arrays[m]=a;boots[m]=np.nanmean(a[indices],axis=1)
        for i,risk in enumerate(RISKS):
            for j,s in enumerate(STRATEGIES):
                descriptive.append(dict(risk=risk,strategy=s,metric=m,**stats(a[:,i,j]),**interval(boots[m][:,i,j])))
    write_csv(T/'descriptive_statistics.csv',descriptive)
    lookup={(r['risk'],r['strategy'],r['metric']):r for r in descriptive}

    within=[];risk_effects=[];interactions=[];raw_deltas=[]
    for i,risk in enumerate(RISKS):
        for left,right in itertools.combinations(range(5),2):
            for m in PAIR_METRICS:
                delta=arrays[m][:,i,right]-arrays[m][:,i,left]
                meta=dict(risk=risk,contrast=f'{STRATEGIES[right]}-{STRATEGIES[left]}',metric=m)
                within.append(contrast_row(delta,indices,meta))
                raw_deltas.extend(dict(kind='strategy_within_risk',repetition_id=r+1,risk=risk,strategy='NA',
                                       contrast=meta['contrast'],metric=m,delta=None if np.isnan(v) else float(v)) for r,v in enumerate(delta))
    for low,high in [(0,1),(1,2),(0,2)]:
        for j,s in enumerate(STRATEGIES):
            for m in PAIR_METRICS:
                delta=arrays[m][:,high,j]-arrays[m][:,low,j]
                meta=dict(strategy=s,lower_risk=RISKS[low],higher_risk=RISKS[high],contrast=f'{RISKS[high]}-{RISKS[low]}',metric=m)
                risk_effects.append(contrast_row(delta,indices,meta))
                raw_deltas.extend(dict(kind='risk_within_strategy',repetition_id=r+1,risk='NA',strategy=s,
                                       contrast=meta['contrast'],metric=m,delta=None if np.isnan(v) else float(v)) for r,v in enumerate(delta))
    for other in ['B','D']:
        j=STRATEGIES.index(other)
        for m in PAIR_METRICS:
            delta=(arrays[m][:,2,0]-arrays[m][:,2,j])-(arrays[m][:,0,0]-arrays[m][:,0,j])
            meta=dict(contrast=f'(A-{other})_high-(A-{other})_low',reference_strategy='A',other_strategy=other,metric=m)
            interactions.append(contrast_row(delta,indices,meta))
            raw_deltas.extend(dict(kind='risk_strategy_interaction',repetition_id=r+1,risk='NA',strategy='NA',
                                   contrast=meta['contrast'],metric=m,delta=None if np.isnan(v) else float(v)) for r,v in enumerate(delta))
    write_csv(T/'strategy_contrasts_within_risk.csv',within)
    write_csv(T/'paired_risk_effects.csv',risk_effects)
    write_csv(T/'paired_risk_strategy_interactions.csv',interactions)
    write_csv(T/'paired_differences.csv',raw_deltas)

    survival=[];profiles=[];thresholds=[]
    for i,risk in enumerate(RISKS):
        for j,s in enumerate(STRATEGIES):
            rows=[by[rep,risk,s] for rep in range(1,101)]
            early=lookup[risk,s,'early_extinction']
            survival.append(dict(risk=risk,strategy=s,runs=100,extinct_by_12=sum(r['early_extinction'] for r in rows),
                                 early_rate=early['mean'],early_ci_low=early['ci95_low'],early_ci_high=early['ci95_high'],
                                 viable_at_end_12=sum(r['viable_after_12'] for r in rows),
                                 runs_with_attempts_after_12=sum(r['attempts_after_12']>0 for r in rows),
                                 attempts_after_12=sum(r['attempts_after_12'] for r in rows),
                                 adoptions_after_12=sum(r['adoptions_after_12'] for r in rows),
                                 censored_at_60=sum(not r['extinction_event'] for r in rows)))
            for threshold in ['0.1','0.25','0.5']:
                reached=np.array([r[f'event_{threshold}'] for r in rows],dtype=float)
                thresholds.append(dict(risk=risk,strategy=s,threshold=float(threshold),reached=int(reached.sum()),
                                       fraction=float(reached.mean()),**interval(reached[indices].mean(axis=1)),
                                       **{f'time_among_reached_{k}':v for k,v in stats([r[f'time_{threshold}'] for r in rows]).items()}))
    for r in data:
        profiles.append({k:r[k] for k in ['repetition_id','risk','strategy','attempts','fallback_attempts','fallback_rate']} |
                        {f'fraction_{c}':r[f'attempts_{c}']/r['attempts'] if r['attempts'] else None for c in ['strong','weak','intermediate','bridge']})
    write_csv(T/'survival_at_12.csv',survival)
    write_csv(T/'threshold_attainment.csv',thresholds)
    write_csv(T/'realized_selection_profiles.csv',profiles)
    dcols=['repetition_id','risk','active_promoters_at_12','extinction_month','attempts_after_12','sent_after_12',
           'adoptions_after_12','route_A_after_12','route_B_after_12']
    write_csv(T/'strategy_D_phase2.csv',[{k:r[k] for k in dcols} for r in data if r['strategy']=='D'])

    tier_groups={}
    with (T/'selection_tiers.csv').open(newline='') as handle:
        for r in csv.DictReader(handle):
            key=(float(r['risk']),r['strategy'],r['phase'],r['requested_route'],int(r['selected_tier']))
            tier_groups.setdefault(key,[]).append(r)
    tier_summary=[]
    for key,rows in sorted(tier_groups.items()):
        n=sum(int(r['attempts']) for r in rows);den=sum(int(r['route_attempts']) for r in rows)
        tier_summary.append(dict(zip(['risk','strategy','phase','requested_route','selected_tier'],key)) |
                            dict(attempts_pooled=n,route_attempts_pooled=den,fraction_pooled=n/den if den else None) |
                            stats([None if r['fraction']=='NA' else float(r['fraction']) for r in rows]))
    write_csv(T/'selection_tier_summary.csv',tier_summary)

    frontier=[];bootfront=[]
    for i,risk in enumerate(RISKS):
        point=np.stack([np.nanmean(arrays['coverage'][:,i],axis=0),np.nanmean(arrays['conversion'][:,i],axis=0)],axis=1)
        pointnd=nondominated(point)
        bpoints=np.stack([boots['coverage'][:,i],boots['conversion'][:,i]],axis=2)
        bnd=np.array([nondominated(p) for p in bpoints])
        valid=np.all(np.isfinite(arrays['coverage'][:,i])&np.isfinite(arrays['conversion'][:,i]),axis=1)
        rnd=np.array([nondominated(np.stack([arrays['coverage'][rep,i],arrays['conversion'][rep,i]],axis=1)) for rep in np.where(valid)[0]])
        for j,s in enumerate(STRATEGIES):
            frontier.append(dict(risk=risk,strategy=s,coverage_mean=float(point[j,0]),conversion_mean=float(point[j,1]),
                                 nondominated_mean=bool(pointnd[j]),bootstrap_mean_nondominated_fraction=float(bnd[:,j].mean()),
                                 run_nondominated_fraction=float(rnd[:,j].mean()),complete_blocks=int(valid.sum())))
        bootfront.extend(dict(risk=risk,bootstrap_id=b+1,strategy=s,coverage=float(bpoints[b,j,0]),
                              conversion=float(bpoints[b,j,1]),nondominated=bool(bnd[b,j])) for b in range(2000) for j,s in enumerate(STRATEGIES))
    write_csv(T/'finite_trust_reach_frontier.csv',frontier)
    write_csv(T/'bootstrap_frontier_points.csv',bootfront)

    grouped={}
    for r in read(T/'system_trajectories_1500.csv'):
        grouped.setdefault((r['risk'],r['strategy'],r['month']),[]).append(r)
    trajectory=[]
    for (risk,s,month),rows in sorted(grouped.items()):
        assert len(rows)==100
        for m in ['cumulative_new_adoptions','coverage','active_promoters','new_communities_adopted']:
            trajectory.append(dict(risk=risk,strategy=s,month=month,metric=m,**stats([r[m] for r in rows])))
    write_csv(T/'trajectory_summary.csv',trajectory)
    headline=[dict(risk=risk,strategy=s,**{f'{m}_{k}':lookup[risk,s,m][k] for m in ['new_adoptions','coverage','conversion','early_extinction']
                                          for k in ['mean','ci95_low','ci95_high']}) for risk in RISKS for s in STRATEGIES]
    write_csv(T/'headline_results.csv',headline)
    plot(lookup,boots,risk_effects,frontier)
    from report_risk import make_report
    make_report(data,lookup,risk_effects,interactions,within,survival,frontier,completion)
    refresh_manifest(completion_path)
    print(json.dumps(dict(status='PASS',analysis_runs=1500,independent_blocks=100,headline=headline,
                          risk_interactions=interactions,survival=survival,frontier=frontier),indent=2))


def refresh_manifest(completion_path):
    import matplotlib
    outputs=sorted(T.glob('*.csv'))+sorted(F.glob('*'))+[ROOT/'outputs/Article_5_Informe_riesgo_v0.2.md']
    save_json(ROOT/'outputs/analysis_manifest.json',dict(comparison_id='risk1500_python_v0.2',independent_blocks=100,
        cells_per_block=15,bootstrap_replicates=2000,bootstrap_seed=20261001,bootstrap_generator='numpy.default_rng / PCG64',
        interval_method='percentile 2.5% and 97.5%; pointwise; no multiplicity adjustment',
        rates='unweighted mean of run-level rates unless explicitly pooled',python_version=platform.python_version(),
        numpy_version=np.__version__,matplotlib_version=matplotlib.__version__,
        scripts_sha256={p:sha256(ROOT/p) for p in ['analyze_risk.py','report_risk.py']},
        completion_sha256=sha256(completion_path),output_sha256={str(p.relative_to(ROOT)):sha256(p) for p in outputs}))


def plot(lookup,boots,risk_effects,frontier):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    F.mkdir(parents=True,exist_ok=True)
    colors=dict(zip(STRATEGIES,['#0072B2','#D55E00','#009E73','#CC79A7','#666666']))
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':200})
    fig,axes=plt.subplots(1,3,figsize=(12,4.6))
    for ax,m,title,pct in zip(axes,['new_adoptions','coverage','conversion'],['Nuevas adopciones','Cobertura por WOM','Conversión'],[False,True,True]):
        for s in STRATEGIES:
            rows=[lookup[risk,s,m] for risk in RISKS];y=[r['mean'] for r in rows]
            ax.errorbar(RISKS,y,yerr=[[r['mean']-r['ci95_low'] for r in rows],[r['ci95_high']-r['mean'] for r in rows]],
                        marker='o',ms=4,lw=1.4,capsize=3,color=colors[s],label=f'{s} · {LABELS[s]}')
        ax.set_title(title,fontweight='bold');ax.set_xticks(RISKS,['Bajo\n0,20','Medio\n0,50','Alto\n0,80']);ax.grid(axis='y',alpha=.18);ax.set_ylim(bottom=0)
        if pct:ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,ncol=5,loc='lower center',frameon=False,bbox_to_anchor=(.5,.025),fontsize=9)
    fig.suptitle('Comparación de riesgo: 100 repeticiones emparejadas por celda',fontweight='bold')
    fig.text(.5,.005,'Medias e IC 95% bootstrap · 1.000 corridas nuevas + 500 base reutilizadas · mu = 0,20',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.12,1,.94));savefig(fig,'efectos_riesgo')

    fig,axes=plt.subplots(1,3,figsize=(12,4.6))
    for ax,m,title,pct in zip(axes,['new_adoptions','conversion','early_extinction'],['Cambio en nuevas adopciones','Cambio en conversión','Cambio en extinción temprana'],[False,True,True]):
        for j,s in enumerate(STRATEGIES):
            row=next(r for r in risk_effects if (r['strategy'],r['metric'],r['contrast'])==(s,m,'0.8-0.2'))
            scale=100 if pct else 1
            ax.errorbar(j,scale*row['mean'],yerr=[[scale*(row['mean']-row['ci95_low'])],[scale*(row['ci95_high']-row['mean'])]],
                        fmt='o',ms=6,color=colors[s],capsize=4)
        ax.axhline(0,color='#555555',ls='--',lw=.8);ax.set_xticks(range(5),STRATEGIES);ax.grid(axis='y',alpha=.18)
        ax.set_title(title,fontweight='bold',fontsize=10);ax.set_ylabel('Puntos porcentuales' if pct else 'Adopciones')
    fig.suptitle('Riesgo alto menos riesgo bajo: diferencias dentro de cada repetición',fontweight='bold',fontsize=12)
    fig.text(.5,.03,'Puntos: diferencia media · Barras: IC 95% de la diferencia emparejada · 2.000 remuestreos',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.07,1,.94));savefig(fig,'diferencias_alto_menos_bajo')

    fig,axes=plt.subplots(1,3,figsize=(12,4.6),sharex=True,sharey=True)
    for i,(ax,risk) in enumerate(zip(axes,RISKS)):
        for j,s in enumerate(STRATEGIES):
            x,y=lookup[risk,s,'coverage'],lookup[risk,s,'conversion']
            ax.scatter(boots['coverage'][:,i,j],boots['conversion'][:,i,j],s=2,alpha=.05,color=colors[s],rasterized=True)
            ax.errorbar(x['mean'],y['mean'],xerr=[[x['mean']-x['ci95_low']],[x['ci95_high']-x['mean']]],
                        yerr=[[y['mean']-y['ci95_low']],[y['ci95_high']-y['mean']]],fmt='o',color=colors[s],ms=5,capsize=2)
            ax.annotate(s,(x['mean'],y['mean']),xytext=(4,4),textcoords='offset points',color=colors[s],fontsize=9,fontweight='bold')
        ax.set_title(f"Riesgo {str(risk).replace('.',',')}",fontweight='bold');ax.set_xlabel('Cobertura media');ax.grid(alpha=.16)
        ax.xaxis.set_major_formatter(PercentFormatter(1,decimals=0));ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=1))
    axes[0].set_ylabel('Conversión media')
    fig.suptitle('Confianza–alcance según el riesgo',fontweight='bold')
    fig.text(.5,.025,'Nubes: medias bootstrap · Barras: IC 95% puntuales · La no dominación se limita a estas cinco estrategias.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.07,1,.94));savefig(fig,'fronteras_por_riesgo')


def savefig(fig,name):
    fig.savefig(F/f'{name}.png',facecolor='white')
    fig.savefig(F/f'{name}.pdf',facecolor='white',metadata={'CreationDate':None,'ModDate':None})
    import matplotlib.pyplot as plt
    plt.close(fig)


if __name__=='__main__':main()
