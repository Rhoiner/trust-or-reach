# Artículo 5 — Comparación de riesgo, Python v0.2

Ejercicio académico sin calibración empírica. Se ejecutan 1.000 corridas nuevas (riesgo 0,20 y 0,80) y se reutilizan las 500 corridas de riesgo 0,50. Son 100 repeticiones emparejadas de quince celdas: tres riesgos por cinco estrategias. El motor v0.2 y las demás reglas permanecen intactos.

## Lectura y paquetes

Abrir `outputs/Article_5_Informe_riesgo_v0.2.md`. La tabla breve es `headline_results.csv`; las 1.500 observaciones están en `run_summary_1500.csv`.

Todos los ZIP de esta entrega comparten la carpeta superior `Article_5_Riesgo_v0.2`. Extraerlos en un mismo directorio. Los 40 ZIP de datos son independientes; cada uno contiene cinco repeticiones de un riesgo (25 corridas). `low` corresponde a 0,20 y `high` a 0,80. No son fragmentos binarios de un único ZIP.

- `engine/`: motor, configuración base y auditor v0.2.
- `design/`: diseño congelado y plan de 1.000 corridas nuevas.
- `provenance/`: especificación histórica, cierre y comprobantes de la base de 500 corridas, y tablas base necesarias para el análisis.
- `outputs/raw/`: 1.000 carpetas nuevas, con 11 CSV y un manifiesto por corrida; se incluyen todas las trazas agente–período.
- `outputs/checks/`: nuevas auditorías, emparejamiento de quince celdas, cierre y verificaciones del análisis.
- `outputs/tables/`: resúmenes, contrastes, remuestreos, selección realizada, supervivencia y trayectorias.
- `outputs/figures/`: tres figuras, en PNG y PDF.

La base de riesgo medio conserva sus archivos originales: [índice de la comparación base](https://drive.google.com/file/d/1opEIwwqzsjo7rBcXJUvqXAGKAeQVU8Is/view?usp=drivesdk). Sus trazas completas no se duplican en los nuevos ZIP. Los registros conservan sus identificadores y la columna `data_origin` distingue la reutilización de las corridas nuevas.

## Ejecutar las condiciones nuevas

El motor y el auditor utilizan exclusivamente la biblioteca estándar. Entorno original: Python 3.12.14. Para reproducir el proyecto completo se recomienda este entorno, con las dependencias gráficas indicadas abajo.

Descomprimir el código en una carpeta nueva, entrar a `Article_5_Riesgo_v0.2` y ejecutar:

```bash
python run_risk.py --workers 4
```

Cada proceso ejecuta una repetición con sus diez condiciones nuevas. El orden de los procesos no cambia las semillas. Para intervalos usar, por ejemplo, `--start 1 --stop 10`. Las corridas ya auditadas se omiten únicamente tras confirmar compatibilidad de diseño y ejecutor e integridad de archivos. No usar `python -O`, que desactiva comprobaciones del auditor.

El cierre combina las 1.000 corridas nuevas con las 500 base incluidas como resultados de referencia en `provenance/`. No vuelve a simular el riesgo medio. Para reconstruir también esas 500 simulaciones desde cero, utilizar el paquete original de comparación base y verificar las huellas antes de reemplazar cualquier referencia.

Con todos los ZIP nuevos descargados se puede ejecutar `python run_risk.py --finalize-only` para validar y regenerar el cierre. Esta acción actualiza la fecha del cierre; ejecutar luego el análisis para actualizar su manifiesto. El análisis también verifica el cierre original sin regenerarlo.

## Análisis y figuras

```bash
python -m pip install -r requirements-analysis.txt
python analyze_risk.py
```

El análisis requiere todos los datos nuevos y sus comprobantes, además del paquete de código que incluye las referencias de riesgo medio. NumPy realiza los remuestreos y Matplotlib produce figuras científicas. El análisis no modifica el motor ni ejecuta simulaciones.

```bash
python package_risk.py
```

Este comando vuelve a crear los paquetes de entrega y su manifiesto SHA-256. Solo empaqueta archivos finalizados que constan en los manifiestos de las corridas; no incluye temporales. Reservar aproximadamente 10 GB para CSV nuevos y ZIP.

## Diseño e inferencia

600 agentes, seis comunidades, 12 promotores iniciales, 60 períodos, mu 0,20. Cuatro intentos por promotor, hasta dos por período. La semilla base de cada repetición es `20260925 + 1000*(r-1)`. Se conservan nodos, enlaces, atributos, consumidores, promotores iniciales y cinta de sorteos entre los quince escenarios de cada repetición.

A prioriza fuertes. B prioriza débiles entre comunidades, después débiles internos, otros puentes y resto. C solicita A con probabilidad 0,50. D solicita A con 0,80 hasta el período 12 y 0,30 desde el 13. E selecciona uniformemente. La ruta solicitada puede diferir de la clase realmente usada por las sustituciones previstas.

La unidad independiente es la repetición, n = 100. Los datos de riesgo medio se incorporan una sola vez. El piloto no añade observaciones. El bootstrap utiliza 2.000 remuestreos de bloques completos de quince condiciones, semilla 20261001, NumPy `default_rng`/PCG64. Se conservan los índices para reproducir exactamente las comparaciones. Los IC 95% son percentiles 2,5 y 97,5, con interpolación lineal, puntuales y sin corrección por multiplicidad. Las tasas indefinidas se conservan como NA; los contrastes usan pares completos e informan n.

Se calculan: diez contrastes entre estrategias dentro de cada riesgo; tres contrastes de riesgo dentro de cada estrategia (0,5−0,2; 0,8−0,5; 0,8−0,2); y dos cambios de diferencias A−B y A−D entre riesgo alto y bajo. La interacción es una diferencia de diferencias dentro del mismo bloque, no la resta de extremos de IC marginales.

## Diccionario mínimo

CSV con coma, punto decimal, UTF-8, `true`/`false` y `NA`. Las tasas se guardan como fracciones 0–1; el informe muestra porcentajes o diferencias en puntos porcentuales. Leer las fases `all`, `1_12` y `13_60` como texto.

| Campo / archivo | Definición |
|---|---|
| `new_adoptions` | Adoptantes nuevos; excluye los 12 iniciales |
| `total_adoptions` | Iniciales más nuevos |
| `adoption_at_12` | Adopción total al cierre de 12 |
| `coverage` | Receptores únicos no iniciales / 588 |
| `conversion` | Nuevas adopciones / envíos |
| `effort_efficiency` | Nuevas adopciones / intentos |
| `redundancy` | Exposiciones repetidas / envíos |
| `fallback_rate` | Intentos que utilizan un nivel posterior al primero / intentos |
| `new_communities_adopted` | Comunidades nuevas, excluye las dos sembradas; máximo cuatro |
| `early_extinction` | Sin capacidad de continuar al cierre de 12 |
| `extinction_month` | Período de extinción, NA si no ocurre en 60 |
| `extinction_event` | Indica extinción observada, para distinguirla de censura |
| `attempts_after_12` | Actividad efectiva desde el período 13 |
| `time_*`, `event_*`, `observed_*` | Primer paso por 10%, 25% y 50% de adopción total; evento y censura |
| `paired_risk_effects.csv` | Riesgo mayor menos menor, dentro de cada estrategia y repetición |
| `strategy_contrasts_within_risk.csv` | Primera estrategia del rótulo menos segunda, dentro de cada riesgo |
| `paired_risk_strategy_interactions.csv` | Diferencia A−alternativa en riesgo alto menos esa diferencia en riesgo bajo |
| `selection_tier_summary.csv` | Medias por corrida y proporciones agrupadas explícitamente rotuladas `pooled` |
| `finite_trust_reach_frontier.csv` | No dominación de medias puntuales, medias bootstrap y resultados por repetición |

Las tasas medias no se ponderan por número de eventos. Los resúmenes de tiempos entre quienes alcanzan un umbral o se extinguen son condicionales, con n explícito; la censura no se convierte en evento. Los percentiles de resultados entre corridas no son IC de las medias. La frecuencia bootstrap de no dominación no es probabilidad de optimalidad universal.

## Alcance

Solo cambia el riesgo. No se modifica mu, la fecha de transición de D, la energía ni los coeficientes de confianza. No se calibran parámetros con datos reales ni se excluyen resultados para favorecer una estrategia. Separación de comunidades, portafolio y sensibilidad permanecen pendientes. El manuscrito no se edita en esta entrega.
