#!/usr/bin/env python3
"""Controles de balance de las tablas, sin ejecutar nuevas simulaciones."""
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
from analyze_risk import ROOT, T, RISKS, STRATEGIES, read, plot, refresh_manifest
from report_risk import make_report


def raw(name):
    with (T/name).open(newline='') as h:
        return list(csv.DictReader(h))


def key(r):
    return int(r['repetition_id']),float(r['risk']),r['strategy']


def main():
    data=read(T/'run_summary_1500.csv')
    by={key(r):r for r in data}
    assert len(data)==len(by)==1500
    assert Counter((r['risk'],r['strategy']) for r in data)==Counter({(r,s):100 for r in RISKS for s in STRATEGIES})
    assert Counter(r['data_origin'] for r in data)==Counter(new_risk_extension=1000,reused_base500=500)
    assert all(r['total_adoptions']==r['new_adoptions']+12 for r in data)
    trajectory=read(T/'system_trajectories_1500.csv')
    assert len(trajectory)==91500
    periods=defaultdict(set)
    for r in trajectory:
        k=key(r); assert r['month'] not in periods[k];periods[k].add(r['month'])
        if r['month']==60:
            assert r['cumulative_new_adoptions']==by[k]['new_adoptions']
            assert r['total_adoptions']==by[k]['total_adoptions']
    assert len(periods)==1500 and all(v==set(range(61)) for v in periods.values())

    classes=raw('conversion_by_actual_tie_class.csv')
    assert len(classes)==13500
    assert {r['phase'] for r in classes}=={'all','1_12','13_60'}
    cg=defaultdict(list)
    for r in classes:cg[key(r),r['phase']].append(r)
    assert len(cg)==4500
    for (k,phase),rows in cg.items():
        assert {r['tie_class'] for r in rows}=={'strong','weak','intermediate'}
        s=by[k]
        for metric,after in [('attempts','attempts_after_12'),('sent','sent_after_12'),('new_adoptions','adoptions_after_12')]:
            expected=s[metric] if phase=='all' else (s[after] if phase=='13_60' else s[metric]-s[after])
            assert sum(int(r[metric]) for r in rows)==expected,(k,phase,metric)

    tiers=raw('selection_tiers.csv');tg=defaultdict(list)
    assert {r['phase'] for r in tiers}=={'all','1_12','13_60'}
    for r in tiers:tg[key(r),r['phase']].append(r)
    assert len(tg)==4500
    for (k,phase),rows in tg.items():
        s=by[k];expected=s['attempts'] if phase=='all' else (s['attempts_after_12'] if phase=='13_60' else s['attempts']-s['attempts_after_12'])
        assert sum(int(r['attempts']) for r in rows)==expected
        route_groups=defaultdict(list)
        for r in rows:route_groups[r['requested_route']].append(r)
        for rr in route_groups.values():
            assert len({r['route_attempts'] for r in rr})==1
            assert sum(int(r['attempts']) for r in rr)==int(rr[0]['route_attempts'])

    within=read(T/'strategy_contrasts_within_risk.csv')
    effects=read(T/'paired_risk_effects.csv')
    interactions=read(T/'paired_risk_strategy_interactions.csv')
    assert (len(within),len(effects),len(interactions))==(210,105,14)
    assert all(r['n']==100 and r['bootstrap_valid']==2000 and r['positive']+r['negative']+r['zero']==100 for r in within+effects+interactions)
    assert len(read(T/'paired_differences.csv'))==32900
    indices=np.array([[int(r[f'draw_{i:03d}'])-1 for i in range(1,101)] for r in raw('bootstrap_block_indices.csv')])
    assert indices.shape==(2000,100)
    assert np.array_equal(indices,np.random.default_rng(20261001).integers(0,100,size=(2000,100)))
    for rows,kind in [(within,'within'),(effects,'risk'),(interactions,'interaction')]:
        for r in rows:
            m=r['metric'];delta=[]
            for rep in range(1,101):
                if kind=='within':
                    left,right=r['contrast'].split('-');v=by[rep,r['risk'],left][m]-by[rep,r['risk'],right][m]
                elif kind=='risk':
                    v=by[rep,r['higher_risk'],r['strategy']][m]-by[rep,r['lower_risk'],r['strategy']][m]
                else:
                    s=r['other_strategy'];v=(by[rep,.8,'A'][m]-by[rep,.8,s][m])-(by[rep,.2,'A'][m]-by[rep,.2,s][m])
                delta.append(v)
            a=np.array(delta,dtype=float);interval=np.quantile(a[indices].mean(axis=1),[.025,.975])
            assert abs(a.mean()-r['mean'])<1e-12
            assert np.allclose(interval,[r['ci95_low'],r['ci95_high']],atol=1e-12,rtol=0)

    descriptive=read(T/'descriptive_statistics.csv')
    lookup={(r['risk'],r['strategy'],r['metric']):r for r in descriptive}
    baseline_path=ROOT.parent/'Article_5_Base_500_v0.2/outputs/tables/descriptive_statistics.csv'
    baseline_regression={'available':baseline_path.exists()}
    if baseline_path.exists():
        base=read(baseline_path);matched=0
        for old in base:
            if (.5,old['strategy'],old['metric']) not in lookup:continue
            current=lookup[.5,old['strategy'],old['metric']]
            for field in ['n','mean','sd','median','minimum','maximum','q1','q3','iqr','p05','p95']:
                a,b=old[field],current[field]
                assert (a is None and b is None) or (a is not None and b is not None and abs(a-b)<1e-12),(old['metric'],field)
            matched+=1
        baseline_regression.update(status='PASS',descriptive_rows_matched=matched)
    completion=json.loads((ROOT/'outputs/checks/risk_completion.json').read_text())
    assert completion['status']=='PASS' and completion['new_audits_passed']==1000
    boots={}
    for m in ['coverage','conversion']:
        a=np.array([[[by[rep,risk,s][m] for s in STRATEGIES] for risk in RISKS] for rep in range(1,101)],dtype=float)
        boots[m]=np.nanmean(a[indices],axis=1)
    survival=read(T/'survival_at_12.csv');frontier=read(T/'finite_trust_reach_frontier.csv')
    plot(lookup,boots,effects,frontier)
    make_report(data,lookup,effects,interactions,within,survival,frontier,completion)
    refresh_manifest(ROOT/'outputs/checks/risk_completion.json')
    receipt=dict(status='PASS',runs=1500,independent_blocks=100,cells_per_block=15,
        new_runs=1000,reused_baseline_runs=500,system_rows=91500,
        actual_tie_class_rows=13500,actual_tie_phase_groups=4500,selection_phase_groups=4500,
        paired_contrasts_checked=329,paired_differences=32900,bootstrap_replicates=2000,
        bootstrap_indices_reconstructed=True,baseline_regression=baseline_regression,
        csv_phase_labels_preserved=True,all_contrast_n=100,all_bootstrap_valid=2000,
        final_system_states_match_summary=True,phase_totals_match_summary=True)
    (ROOT/'outputs/checks/analysis_checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()
