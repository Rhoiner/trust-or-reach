"""Informe técnico de riesgo, generado a partir de los resultados auditados."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parent
RISKS=[.2,.5,.8]
LABELS=dict(A='Fuerte',B='Débil / puente',C='Balanceada',D='Secuencial',E='Aleatoria')


def f(v,n=2):
    return 'NA' if v is None else f'{v:.{n}f}'.replace('.',',')


def ci(r,scale=1):
    return f"[{f(scale*r['ci95_low'])}; {f(scale*r['ci95_high'])}]"


def make_report(data,lookup,effects,interactions,within,survival,frontier,completion):
    high_low={(r['strategy'],r['metric']):r for r in effects if r['contrast']=='0.8-0.2'}
    main_table='\n'.join(f"| {s} · {LABELS[s]} | "+' | '.join(f(lookup[r,s,'new_adoptions']['mean']) for r in RISKS)+f" | {f(high_low[s,'new_adoptions']['mean'])} {ci(high_low[s,'new_adoptions'])} |" for s in 'ABCDE')
    conversion_table='\n'.join(f"| {s} | "+' | '.join(f(100*lookup[r,s,'conversion']['mean']) for r in RISKS)+f" | {f(100*high_low[s,'conversion']['mean'])} {ci(high_low[s,'conversion'],100)} |" for s in 'ABCDE')
    coverage_table='\n'.join(f"| {s} | "+' | '.join(f(100*lookup[r,s,'coverage']['mean']) for r in RISKS)+f" | {f(100*high_low[s,'coverage']['mean'])} {ci(high_low[s,'coverage'],100)} |" for s in 'ABCDE')
    compact_table='\n'.join(f"| {f(r['risk'],1)} | {r['strategy']} | {r['extinct_by_12']}% | {r['runs_with_attempts_after_12']}/100 | {r['censored_at_60']} |" for r in survival)
    interaction_table='\n'.join(f"| A−{r['other_strategy']} | {r['metric']} | {f((100 if r['metric'] in ['coverage','conversion'] else 1)*r['mean'])} | {ci(r,100 if r['metric'] in ['coverage','conversion'] else 1)} |" for r in interactions if r['metric'] in ['new_adoptions','coverage','conversion'])
    dtable=[]
    for risk in RISKS:
        rows=[r for r in data if r['risk']==risk and r['strategy']=='D']
        attempts=sum(r['attempts_after_12'] for r in rows);b=sum(r['route_B_after_12'] for r in rows)
        dtable.append(f"| {f(risk,1)} | {sum(r['attempts_after_12']>0 for r in rows)}/100 | {attempts} | {f(100*b/attempts) if attempts else 'NA'}% | {sum(r['adoptions_after_12'] for r in rows)} |")
    frontier_table='\n'.join(f"| {f(risk,1)} | {', '.join(r['strategy'] for r in frontier if r['risk']==risk and r['nondominated_mean'])} | "+' · '.join(f"{r['strategy']}: {f(100*r['bootstrap_mean_nondominated_fraction'],1)}%" for r in frontier if r['risk']==risk)+' |' for risk in RISKS)
    fallback='\n'.join(f"| {s} | "+' | '.join(f(100*lookup[risk,s,'fallback_rate']['mean'])+'%' for risk in RISKS)+' |' for s in 'ABCDE')
    winners={risk:max('ABCDE',key=lambda s:lookup[risk,s,'new_adoptions']['mean']) for risk in RISKS}
    interaction_lookup={(r['other_strategy'],r['metric']):r for r in interactions}
    ab_conv=interaction_lookup['B','conversion']
    ab_adop=interaction_lookup['B','new_adoptions']
    da_low=next(r for r in within if r['risk']==.2 and r['contrast']=='D-A' and r['metric']=='conversion')
    date=datetime.fromisoformat(completion['finalization_utc']).astimezone(ZoneInfo('America/Bogota')).strftime('%Y-%m-%d')
    monotonic='\n'.join(f"| {s} | {high_low[s,'new_adoptions']['negative']} | {high_low[s,'new_adoptions']['zero']} | {high_low[s,'new_adoptions']['positive']} |" for s in 'ABCDE')
    text=f'''# Artículo 5 — Comparación de riesgo bajo, medio y alto

Python v0.2 · Finalización local: {date} · Comparación `risk1500_python_v0.2`

## Entrega y resultado principal

Se completaron **1.000 corridas nuevas**: 500 con riesgo bajo (0,20) y 500 con riesgo alto (0,80). Las 1.000 aprobaron la auditoría de exportaciones. Se reutilizaron las 500 corridas de riesgo medio (0,50), previamente auditadas y verificadas, para formar una comparación de **1.500 corridas en 100 bloques emparejados de quince condiciones**.

Las medias de adopción, cobertura y conversión disminuyen al pasar de riesgo bajo a alto en las cinco estrategias. La mayor media de nuevas adopciones corresponde a {winners[.2]} en riesgo bajo, {winners[.5]} en medio y {winners[.8]} en alto. Sin embargo, la ventaja de A frente a B aumenta en conversión y disminuye en número de adopciones: son indicadores diferentes. Estos resultados describen un ejercicio académico bajo supuestos explícitos; no son calibración empírica ni predicciones de ventas.

## Diseño y reutilización de la base

Se conservó el motor Python v0.2. Solo cambió el parámetro de riesgo a 0,20 y 0,80. Permanecieron 600 consumidores, seis comunidades, 12 promotores iniciales, 60 períodos, mu = 0,20, calidad = 0,90, cuatro intentos de energía por promotor y hasta dos intentos por período. A prioriza fuertes; B débiles con prioridad de puente; C solicita A/B con probabilidades 0,50/0,50; D solicita A con 0,80 hasta 12 y 0,30 desde 13; E selecciona uniformemente.

Cada repetición utiliza una misma red, atributos, consumidores, promotores iniciales y cinta de sorteos para los tres riesgos y las cinco estrategias. Cambian las decisiones y las trayectorias al cambiar las probabilidades de adopción. Los 100 bloques conservan las semillas de la base: 20260925 + 1000 × (r − 1), con los desplazamientos definidos en la especificación.

Se incorporó una sola vez cada corrida de riesgo medio, conservando `run_id`, `experiment_id` y sus resultados originales. La columna `data_origin` distingue `reused_base500` de `new_risk_extension`. El piloto no añade observaciones. La unidad independiente es la repetición, **n = 100**, no 1.500 corridas independientes ni consumidores o eventos individuales.

## Auditoría

| Comprobación | Resultado |
|---|---:|
| Nuevas corridas y auditorías | 1.000 / 1.000 |
| Corridas base reutilizadas | 500 |
| Bloques con quince celdas emparejadas | 100 / 100 |
| Redes distintas | 100 |
| Nuevos registros de sistema | {completion['new_system_rows']:,} |
| Nuevos registros agente–período | {completion['new_agent_period_rows']:,} |
| Nuevos intentos/eventos | {completion['new_events']:,} |
| Intentos/eventos incluyendo la base | {completion['combined_events']:,} |
| Exclusiones por desempeño | 0 |

Se verificó la integridad de la base antes de reutilizarla. Las auditorías nuevas reconstruyeron eventos desde CSV y contrastaron recursos, elegibilidad, envío, adopción, exposiciones, ascendencia, cascadas, estados e indicadores. Se verificaron las huellas del motor y de los archivos. El emparejamiento cubrió nodos, enlaces, red y cinta de sorteos de las quince celdas. Estas verificaciones son computacionales, no validación empírica.

## Análisis e incertidumbre

Las tasas se calculan primero por corrida y después se promedian sin ponderar por eventos. Los cocientes no definidos se conservan como NA. Las tablas incluyen n válido, media, mediana, DE muestral, rango, cuartiles, IQR y percentiles 5–95.

Se utilizaron 2.000 remuestreos de los 100 bloques completos, con las quince condiciones juntas; semilla 20261001 y generador NumPy PCG64. Los IC del 95% son los percentiles 2,5 y 97,5 de medias o diferencias remuestreadas. Los mismos índices se aplican a todos los contrastes y quedan exportados. Se usan pares completos cuando una tasa no está definida. Los IC son puntuales, sin ajuste por multiplicidad; no se realizaron pruebas de significación. Expresan incertidumbre Monte Carlo para este diseño, no incertidumbre sobre sus supuestos.

Se calcularon diferencias entre estrategias dentro de cada riesgo, cambios de riesgo dentro de cada estrategia y dos contrastes de interacción predefinidos: A frente a B y A frente a D. No se excluyeron cascadas grandes o pequeñas por ser inesperadas.

## Nuevas adopciones

Se excluyen los 12 adoptantes iniciales. La última columna muestra riesgo alto menos bajo, calculado dentro de cada repetición.

| Estrategia | Bajo 0,20 | Medio 0,50 | Alto 0,80 | Alto − bajo: media [IC 95%] |
|---|---:|---:|---:|---:|
{main_table}

El cambio agregado no se impuso como regla de verificación. La comparación de las 100 parejas por estrategia muestra cuántas terminaron con menos, igual o más adopciones bajo riesgo alto:

| Estrategia | Menos adopciones | Igual | Más adopciones |
|---|---:|---:|---:|
{monotonic}

El aumento del riesgo reduce directamente la probabilidad de adopción para el mismo consumidor, vínculo e historial; las trayectorias completas también cambian contactos, promotores y exposiciones. Por eso no se exige monotonía de los totales en cada pareja para aprobar la simulación.

## Conversión y cobertura

Conversión = nuevas adopciones / envíos; cobertura = receptores únicos no iniciales / 588. Los niveles son porcentajes y las diferencias son puntos porcentuales (pp), no variaciones porcentuales relativas.

| Estrategia | Conversión baja % | Media % | Alta % | Alto − bajo: pp [IC 95%] |
|---|---:|---:|---:|---:|
{conversion_table}

| Estrategia | Cobertura baja % | Media % | Alta % | Alto − bajo: pp [IC 95%] |
|---|---:|---:|---:|---:|
{coverage_table}

![Niveles según riesgo](figures/efectos_riesgo.png)

![Diferencias alto menos bajo](figures/diferencias_alto_menos_bajo.png)

## ¿Cambia la diferencia entre estrategias?

La interacción se define como `(A − alternativa) en riesgo alto − (A − alternativa) en riesgo bajo`. Un valor positivo significa que crece la diferencia de A respecto a la alternativa; no significa necesariamente que aumente el nivel de adopción de A. Conversión y cobertura se muestran en pp; adopciones, en personas.

| Comparación | Indicador | Cambio en la diferencia | IC 95% |
|---|---|---:|---:|
{interaction_table}

La ventaja de A frente a B en conversión aumenta {f(100*ab_conv['mean'])} pp, IC 95% {ci(ab_conv,100)} pp. En cambio, su ventaja en número de nuevas adopciones pasa de {f(lookup[.2,'A','new_adoptions']['mean']-lookup[.2,'B','new_adoptions']['mean'])} a {f(lookup[.8,'A','new_adoptions']['mean']-lookup[.8,'B','new_adoptions']['mean'])}: un cambio de {f(ab_adop['mean'])}, IC 95% {ci(ab_adop)}. A conserva más adopciones que B en promedio, pero la caída general de difusión reduce la distancia absoluta entre ambas.

Por tanto, no corresponde afirmar sin precisar el indicador que el riesgo alto «favorece más» a A. `paired_risk_strategy_interactions.csv` contiene los siete indicadores y sus n válidos; `strategy_contrasts_within_risk.csv` contiene los diez contrastes entre estrategias para cada riesgo.

## Extinción y oportunidad de actuar de D

| Riesgo | Estrategia | Extinción al cierre de 12 | Con intentos desde 13 | Sin extinción observada en 60 |
|---|---|---:|---:|---:|
{compact_table}

La extinción corresponde a ausencia de capacidad para continuar, no a un período aislado sin envíos. Las corridas sin extinción observada permanecen censuradas en 60. `extinction_month` se resume solo entre extinciones observadas, con n explícito; no se usa como duración media incondicional. Todas las series se conservan hasta 60. Los tiempos a 10%, 25% y 50% de adopción total se guardan con sus indicadores de ocurrencia y censura.

| Riesgo de D | Corridas con segunda fase | Intentos desde 13, suma | Ruta B solicitada desde 13 | Adopciones desde 13, suma |
|---|---:|---:|---:|---:|
{chr(10).join(dtable)}

El corte de D permaneció en el período 12. La proporción de ruta B de esta tabla agrupa intentos y no es una cuota impuesta. Comparar D con A o C no identifica exclusivamente el efecto del cambio de fase, porque sus mezclas también difieren al inicio.

## Sustituciones y selección realizada

| Estrategia | Sustituciones, riesgo bajo | Riesgo medio | Riesgo alto |
|---|---:|---:|---:|
{fallback}

Las cifras son medias de sustituciones/intentos por corrida. Una sustitución es usar un nivel posterior al primero de la ruta solicitada. En B, pasar a débiles internos ya cuenta como sustitución. E tiene un solo nivel. Los contactos realmente fuertes, débiles, intermedios y puentes se conservan por separado; puente y clase no son categorías excluyentes. Las tablas por clase real son descriptivas y no identifican un efecto puro del vínculo, porque cambian receptores y momentos de contacto.

## Frontera confianza–alcance

| Riesgo | No dominadas en medias puntuales | Frecuencia de no dominación de medias bootstrap |
|---|---|---|
{frontier_table}

La no dominación maximiza simultáneamente cobertura y conversión y se restringe a las cinco estrategias y tres riesgos estudiados. Las frecuencias bootstrap no son probabilidades de optimalidad universal; los intervalos y diferencias emparejadas deben acompañar esta descripción.

En riesgo bajo, D aparece en la frontera puntual por una diferencia de conversión respecto a A de solo {f(100*da_low['mean'])} pp, con IC 95% {ci(da_low,100)} pp, que incluye cero. Este resultado no establece que D convierta mejor que A.

![Fronteras por riesgo](figures/fronteras_por_riesgo.png)

## Interpretación y límites

El papel directo del riesgo ya estaba definido en el modelo: `z = a0 + bT*w*T − gR*riesgo*(1−w*T) − bX*exceso`, con adopción `N*F*logística(z)`. No se presenta ese signo impuesto como descubrimiento empírico. Lo que se evalúa es su propagación a conversión agregada, continuidad, alcance y diferencias entre estrategias cuando cambian los promotores y contactos.

Mu se mantuvo en 0,20. La heterogeneidad entre las 100 redes no sustituye un experimento que cambie su mezcla entre comunidades. Tampoco se aislaron todavía confianza, cooperación y compromiso mediante sensibilidad. Estos resultados constituyen un ejercicio teórico, sin datos reales ni parámetros estimados para empresas.

La siguiente etapa prevista es variar mu a 0,05 y 0,40 manteniendo riesgo 0,50: 1.000 corridas adicionales y reutilización de la base. Ese diseño, junto con el de riesgo, no constituye un cruce factorial completo riesgo × mu y no identifica su interacción conjunta. No se ejecutó esa etapa ni se modificó el manuscrito en esta entrega.

## Entregables y reproducción

`run_risk.py` ejecuta y audita solo las 1.000 condiciones nuevas; `provenance/` conserva la base reutilizada y sus huellas; `analyze_risk.py` reúne las 1.500 observaciones y produce tablas, IC, figuras e informe. Los ZIP de trazas contienen todos los CSV finalizados de las nuevas corridas; las trazas de riesgo medio permanecen en la entrega base. El índice enlaza ambas entregas y el README describe la reproducción.

Los archivos de análisis conservan 1.500 filas de resumen, quince celdas por bloque, indicadores de origen y denominadores. Los manifiestos documentan semillas, versiones, huellas y ejecución. Fuente normativa: especificación mínima Python v0.2, secciones 8–12, y el diseño congelado `design/risk_design.json`.
'''
    (ROOT/'outputs/Article_5_Informe_riesgo_v0.2.md').write_text(text,encoding='utf-8')
