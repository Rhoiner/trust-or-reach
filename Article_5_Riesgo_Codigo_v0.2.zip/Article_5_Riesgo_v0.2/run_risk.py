#!/usr/bin/env python3
"""Comparación de riesgo: 1000 nuevas corridas y 500 base reutilizadas; motor Python v0.2 intacto."""
import argparse
from collections import Counter
from dataclasses import replace
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / 'engine'
sys.path.insert(0, str(ENGINE))
from article5 import Config, Model
from article5.io import export_run, sha256, write_csv
from tests.audit_exports import audit_run, content_hash

RAW = ROOT / 'outputs' / 'raw'
CHECKS = ROOT / 'outputs' / 'checks'
DESIGN = ROOT / 'design' / 'risk_design.json'


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', dir=path.parent, encoding='utf-8', suffix='.pending', delete=False) as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(handle.name, path)


def verify_manifest(path):
    manifest = json.loads(path.read_text())
    for filename, digest in manifest['output_sha256'].items():
        if sha256(path.parent / filename) != digest:
            raise RuntimeError(f'Archivo incompleto o alterado: {filename}')
    for filename, digest in manifest['source_sha256'].items():
        if sha256(ENGINE / filename) != digest:
            raise RuntimeError(f'Motor alterado: {filename}')
    return manifest


def planned_rows(design):
    rows = []
    for rep in design['repetitions']:
        seed = design['seed_base'] + design['repetition_stride'] * (rep - 1)
        for risk in design['risk_levels_new']:
            label = 'low' if risk == .2 else 'high'
            for strategy in design['strategies']:
                rows.append(dict(prefix=f'r{rep:03d}_{label}_{strategy}', repetition_id=rep, strategy=strategy,
                                 risk=risk, mu=design['mu'], population=600, horizon=60, seed_base_r=seed,
                                 dynamics_seed=seed+201, consumer_seed=seed+202, initial_promoter_seed=seed+200))
    return rows


def execute(row, base, design):
    prefix = row['prefix']
    receipt_path = CHECKS / f'{prefix}_audit.json'
    folder = RAW / prefix
    manifest_path = folder / f'{prefix}_run_manifest.json'
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        if receipt['design_sha256'] != sha256(DESIGN) or receipt['runner_sha256'] != sha256(Path(__file__)):
            raise RuntimeError(f'{prefix}: diseño o ejecutor diferente; utilizar una copia nueva del experimento')
        verify_manifest(manifest_path)
        if receipt['manifest_sha256'] != sha256(manifest_path) or receipt['status'] != 'PASS':
            raise RuntimeError(f'{prefix}: comprobante de auditoría inválido')
        print(f'{prefix}: ya completada; integridad confirmada', flush=True)
        return
    start = time.monotonic()
    config = replace(base, repetition=row['repetition_id'], strategy=row['strategy'],
                     experiment_id=design['experiment_id'], risk=row['risk']).validate()
    model = Model(config).run()
    export_run(model, folder, prefix, purpose='risk_comparison_extension')
    manifest = verify_manifest(manifest_path)
    data, meta, _, _ = audit_run(folder, prefix)
    events, periods, cascades = data['events'], data['system_period'], data['cascades']
    if len(periods) != 61 or len(data['agent_period']) != 36600:
        raise RuntimeError('Horizonte o número de estados incompleto')
    edges = {(e['source'], e['target']): e for e in data['edges']}
    classes = Counter(edges[min(e['sender'], e['receiver']), max(e['sender'], e['receiver'])]['tie_class'] for e in events)
    routes = Counter(e['route'] for e in events)
    attempts = len(events)
    fallback = sum(e['fallback'] for e in events)
    late = [e for e in events if e['month'] >= 13]
    result = meta | model.summary() | dict(
        fallback_attempts=fallback, fallback_rate=fallback / attempts if attempts else None,
        attempts_strong=classes['strong'], attempts_weak=classes['weak'], attempts_intermediate=classes['intermediate'],
        attempts_bridge=sum(e['bridge'] for e in events),
        requested_route_A=routes['A'], requested_route_B=routes['B'], requested_route_E=routes['E'],
        active_promoters_at_12=periods[12]['active_promoters'], active_cascades_at_12=periods[12]['active_cascades'],
        viable_after_12=periods[12]['active_promoters'] > 0,
        attempts_after_12=len(late), sent_after_12=sum(e['sent'] for e in late),
        adoptions_after_12=sum(e['adoption'] for e in late),
        route_A_after_12=sum(e['route'] == 'A' for e in late), route_B_after_12=sum(e['route'] == 'B' for e in late),
        max_active_promoters=max(p['active_promoters'] for p in periods),
        satisfied_new_promoters=sum(a.adopted and not a.seed and a.satisfaction >= config.satisfaction_threshold for a in model.agents),
        max_cascade_size=max(c['size'] for c in cascades), max_cascade_depth=max(c['depth'] for c in cascades),
        accepted_candidate=model.network.accepted_candidate)
    assert sum(classes.values()) == attempts and sum(routes.values()) == attempts
    tier_rows = []
    for phase, selected in [('all', events), ('1_12', [e for e in events if e['month'] <= 12]), ('13_60', late)]:
        for route in ('A', 'B', 'E'):
            group = [e for e in selected if e['route'] == route]
            for tier in range(4 if route == 'B' else 2 if route == 'A' else 1):
                count = sum(e['selected_tier'] == tier for e in group)
                tier_rows.append(meta | dict(phase=phase, requested_route=route, selected_tier=tier,
                                            attempts=count, route_attempts=len(group),
                                            fraction=count / len(group) if group else None))
    trajectories = [{k:p[k] for k in ('month','total_adoptions','coverage','conversion','active_promoters','new_communities_adopted')} |
                    dict(repetition_id=row['repetition_id'],strategy=row['strategy'],risk=row['risk'],
                         cumulative_new_adoptions=p['total_adoptions']-12) for p in periods]
    actual_ties = []
    for phase, selected in [('all',events),('1_12',[e for e in events if e['month']<=12]),('13_60',late)]:
        for tie in ('strong','weak','intermediate'):
            subset = [e for e in selected if edges[min(e['sender'],e['receiver']),max(e['sender'],e['receiver'])]['tie_class']==tie]
            nsent = sum(e['sent'] for e in subset)
            nadopt = sum(e['adoption'] for e in subset)
            actual_ties.append(dict(repetition_id=row['repetition_id'],strategy=row['strategy'],risk=row['risk'],phase=phase,
                                    tie_class=tie,attempts=len(subset),sent=nsent,new_adoptions=nadopt,
                                    conversion=nadopt/nsent if nsent else None))
    receipt = dict(prefix=prefix, status='PASS', execution_utc=datetime.now(timezone.utc).isoformat(),
                   elapsed_seconds=round(time.monotonic() - start, 3), python_version=platform.python_version(),
                   design_sha256=sha256(DESIGN), runner_sha256=sha256(Path(__file__)),
                   manifest_sha256=sha256(manifest_path),
                   node_content_sha256=content_hash(data['nodes']), edge_content_sha256=content_hash(data['edges']),
                   network_content_sha256=manifest['network_content_sha256'], tape_sha256=manifest['tape_sha256'],
                   event_rows=len(events), system_rows=len(periods), agent_period_rows=len(data['agent_period']),
                   result=result, tiers=tier_rows, trajectories=trajectories, actual_ties=actual_ties)
    save_json(receipt_path, receipt)
    print(f"{prefix}: PASS; adopciones nuevas={model.new_total}; extinción={model.extinction_month}; intentos después de 12={len(late)}", flush=True)


def read_baseline(design):
    for path,digest in design['provenance_sha256'].items():
        assert sha256(ROOT/path)==digest,path
    completion = json.loads((ROOT/'provenance/base500_completion.json').read_text())
    assert completion['status']=='PASS' and completion['completed_runs']==500
    receipts=[]
    for name,digest in completion['receipt_sha256'].items():
        path=ROOT/'provenance/base_checks'/name
        assert sha256(path)==digest,path
        receipt=json.loads(path.read_text())
        assert receipt['status']=='PASS' and receipt['result']['risk']==.5
        receipts.append(receipt)
    return receipts


def finalize(design):
    baseline=read_baseline(design)
    receipts=[]
    for row in planned_rows(design):
        path=CHECKS/f'{row["prefix"]}_audit.json'
        if not path.exists():
            return False
        receipt=json.loads(path.read_text())
        manifest_path=RAW/row['prefix']/f'{row["prefix"]}_run_manifest.json'
        verify_manifest(manifest_path)
        assert receipt['manifest_sha256']==sha256(manifest_path)
        assert receipt['design_sha256']==sha256(DESIGN)
        assert receipt['runner_sha256']==sha256(Path(__file__))
        assert receipt['status']=='PASS'
        receipts.append(receipt)
    all_receipts=baseline+receipts
    paired=[]
    for rep in design['repetitions']:
        block=[r for r in all_receipts if r['result']['repetition_id']==rep]
        assert len(block)==15
        assert {(r['result']['risk'],r['result']['strategy']) for r in block}=={(risk,s) for risk in [.2,.5,.8] for s in 'ABCDE'}
        for key in ('node_content_sha256','edge_content_sha256','network_content_sha256','tape_sha256'):
            assert len({r[key] for r in block})==1,(rep,key)
        paired.append(dict(repetition_id=rep,status='PASS',paired_cells=15,
                           network_content_sha256=block[0]['network_content_sha256'],tape_sha256=block[0]['tape_sha256']))
    assert len({r['network_content_sha256'] for r in paired})==100
    assert len({r['result']['run_id'] for r in all_receipts})==1500
    write_csv(CHECKS/'paired_15cell_checks.csv',paired)
    write_csv(CHECKS/'new_run_audits.csv',[{k:r[k] for k in ('prefix','status','execution_utc','elapsed_seconds','event_rows','system_rows','agent_period_rows')} for r in receipts])
    tables=ROOT/'outputs/tables'
    rows=[]
    for r in all_receipts:
        rows.append(r['result'] | dict(comparison_id='risk1500_python_v0.2',
                                        data_origin='reused_base500' if r['result']['risk']==.5 else 'new_risk_extension'))
    rows.sort(key=lambda r:(r['repetition_id'],r['risk'],r['strategy']))
    write_csv(tables/'run_summary_1500.csv',rows)
    write_csv(tables/'selection_tiers.csv',[t for r in all_receipts for t in r['tiers']])
    from tests.audit_exports import read
    baseline_periods=[r | dict(risk=.5) for r in read(ROOT/'provenance/base_tables/system_trajectories_500.csv')]
    write_csv(tables/'system_trajectories_1500.csv',baseline_periods+[p for r in receipts for p in r['trajectories']])
    # Mantener las fases como etiquetas de texto, sin convertir sus guiones bajos a números.
    import csv
    baseline_ties=[]
    with (ROOT/'provenance/base_tables/conversion_by_actual_tie_class.csv').open() as handle:
        for r in csv.DictReader(handle):
            baseline_ties.append(dict(repetition_id=int(r['repetition_id']),strategy=r['strategy'],risk=.5,
                                      phase=r['phase'],tie_class=r['tie_class'],attempts=int(r['attempts']),
                                      sent=int(r['sent']),new_adoptions=int(r['new_adoptions']),
                                      conversion=None if r['conversion']=='NA' else float(r['conversion'])))
    write_csv(tables/'conversion_by_actual_tie_class.csv',baseline_ties+[t for r in receipts for t in r['actual_ties']])
    completed=dict(status='PASS',experiment_id=design['experiment_id'],comparison_id='risk1500_python_v0.2',
                   model_version='0.2',new_runs=1000,new_audits_passed=1000,reused_baseline_runs=500,
                   analysis_runs=1500,independent_paired_blocks=100,cells_per_block=15,distinct_networks=100,
                   new_system_rows=sum(r['system_rows'] for r in receipts),
                   new_agent_period_rows=sum(r['agent_period_rows'] for r in receipts),
                   new_events=sum(r['event_rows'] for r in receipts),
                   combined_system_rows=sum(r['system_rows'] for r in all_receipts),
                   combined_agent_period_rows=sum(r['agent_period_rows'] for r in all_receipts),
                   combined_events=sum(r['event_rows'] for r in all_receipts),
                   empirical_calibration=False,model_rules_changed=False,changed_parameter='risk',
                   finalization_utc=datetime.now(timezone.utc).isoformat(),python_version=platform.python_version(),
                   design_sha256=sha256(DESIGN),runner_sha256=sha256(Path(__file__)),
                   receipt_sha256={f'{r["prefix"]}_audit.json':sha256(CHECKS/f'{r["prefix"]}_audit.json') for r in receipts})
    save_json(CHECKS/'risk_completion.json',completed)
    print('RISK_COMPLETE: 1000 new runs audited; 500 reused; 100 matched 15-cell blocks.',flush=True)
    return True


def run_block(rep):
    design = json.loads(DESIGN.read_text())
    base = Config.load(ROOT / design['base_config'])
    for row in planned_rows(design):
        if row['repetition_id'] == rep:
            execute(row, base, design)
    return rep


def main():
    from concurrent.futures import ProcessPoolExecutor, as_completed
    if not __debug__:
        raise RuntimeError('Ejecutar sin -O: se requieren las comprobaciones del auditor')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', type=int, default=1)
    parser.add_argument('--stop', type=int, default=100)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--finalize-only', action='store_true')
    args = parser.parse_args()
    assert 1 <= args.start <= args.stop <= 100 and 1 <= args.workers <= 8
    design = json.loads(DESIGN.read_text())
    for file in design['engine_files']:
        if sha256(ROOT / file['path']) != file['sha256']:
            raise RuntimeError(f'Motor v0.2 alterado: {file["path"]}')
    base = Config.load(ROOT / design['base_config'])
    assert (base.population, base.horizon, base.risk, base.mu) == (600, 60, .5, .2)
    assert (base.seed_base, design['seed_base'], design['repetition_stride']) == (20260925, 20260925, 1000)
    read_baseline(design)
    plan = planned_rows(design)
    assert len(plan) == 1000
    write_csv(ROOT / 'design' / 'run_plan_1000.csv', plan)
    if not args.finalize_only:
        started = time.monotonic()
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = {pool.submit(run_block, rep): rep for rep in range(args.start, args.stop + 1)}
            for f in as_completed(futures):
                rep = f.result()
                n = len(list(CHECKS.glob('r*_audit.json')))
                save_json(CHECKS / 'progress.json', dict(completed_audited_runs=n, last_completed_block=rep,
                                                       elapsed_seconds=round(time.monotonic()-started,2)))
                print(f'PROGRESS: {n}/1000 audited; block {rep} completed', flush=True)
    complete = finalize(design)
    if args.finalize_only and not complete:
        raise RuntimeError('Faltan corridas para cerrar la comparación de riesgo')


if __name__ == '__main__':
    main()

