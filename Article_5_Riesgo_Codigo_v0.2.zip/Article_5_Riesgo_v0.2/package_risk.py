#!/usr/bin/env python3
"""ZIP independientes por riesgo y cinco repeticiones; solo archivos finalizados."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent/'Article_5_Riesgo_Entregables'


def package(name,paths):
    files=sorted(p for p in paths if p.is_file() and '__pycache__' not in p.parts)
    path=DEST/name
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(Path(ROOT.name)/p.relative_to(ROOT)))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
    row=dict(file=name,files=len(files),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    print(json.dumps(row),flush=True)
    return row


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--raw-only',action='store_true')
    parser.add_argument('--support-only',action='store_true')
    args=parser.parse_args()
    assert not(args.raw_only and args.support_only)
    DEST.mkdir(exist_ok=True)
    if not args.support_only:
        rows=[]
        for risk,label in [(.2,'low'),(.8,'high')]:
            for start in range(1,101,5):
                paths=[]
                for rep in range(start,start+5):
                    for s in 'ABCDE':
                        folder=ROOT/'outputs/raw'/f'r{rep:03d}_{label}_{s}'
                        manifest=folder/f'{folder.name}_run_manifest.json'
                        m=json.loads(manifest.read_text())
                        paths.extend([manifest,*[folder/name for name in m['output_sha256']]])
                assert len(paths)==300
                row=package(f'Article_5_Riesgo_{label}_r{start:03d}_r{start+4:03d}_v0.2.zip',paths)
                row.update(risk=risk,repetition_first=start,repetition_last=start+4,runs=25)
                rows.append(row)
        assert sum(r['runs'] for r in rows)==1000
        (DEST/'raw_packages.json').write_text(json.dumps(rows,indent=2)+'\n')
    if not args.raw_only:
        specifications={
          'Article_5_Riesgo_Codigo_v0.2.zip':[*ROOT.joinpath('engine').rglob('*'),*ROOT.joinpath('design').glob('*'),
             *ROOT.joinpath('provenance').rglob('*'),*ROOT.glob('*.py'),ROOT/'README.md',ROOT/'requirements-analysis.txt'],
          'Article_5_Riesgo_Diseno_v0.2.zip':list(ROOT.joinpath('design').glob('*')),
          'Article_5_Riesgo_Verificacion_v0.2.zip':list(ROOT.joinpath('outputs/checks').glob('*.json'))+list(ROOT.joinpath('outputs/checks').glob('*.csv')),
          'Article_5_Riesgo_Analisis_v0.2.zip':[*ROOT.joinpath('outputs/tables').glob('*.csv'),*ROOT.joinpath('outputs/figures').glob('*'),
             ROOT/'outputs/Article_5_Informe_riesgo_v0.2.md',ROOT/'outputs/analysis_manifest.json'],
          'Article_5_Riesgo_Figuras_v0.2.zip':list(ROOT.joinpath('outputs/figures').glob('*'))}
        support=[package(name,paths) for name,paths in specifications.items()]
        rows=json.loads((DEST/'raw_packages.json').read_text())+support
        (DEST/'Article_5_Riesgo_Manifiesto_paquetes_v0.2.json').write_text(json.dumps(rows,indent=2)+'\n')


if __name__=='__main__':main()
