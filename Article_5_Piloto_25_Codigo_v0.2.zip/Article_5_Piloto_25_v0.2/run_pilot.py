#!/usr/bin/env python3
"""Piloto fijo: cinco estrategias por cinco repeticiones; motor Python v0.2 intacto."""
import argparse
from collections import Counter
from dataclasses import replace
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / 'engine'
sys.path.insert(0, str(ENGINE))
from article5 import Config, Model
from article5.io import export_run, sha256, write_csv
from tests.audit_exports import audit_run, content_hash

RAW = ROOT / 'outputs' / 'raw'
CHECKS = ROOT / 'outputs' / 'checks'
DESIGN = ROOT / 'design' / 'pilot_design.json'


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', dir=path.parent, encoding='utf-8', suffix='.pending', delete=False) as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(handle.name, path)


def verify_manifest(path):
    manifest = json.loads(path.read_text())
    for filename, digest in manifest['output_sha256'].items():
        if sha256(path.parent / filename) != digest:
            raise RuntimeError(f'Archivo incompleto o alterado: {filename}')
    for filename, digest in manifest['source_sha256'].items():
        if sha256(ENGINE / filename) != digest:
            raise RuntimeError(f'Motor alterado: {filename}')
    return manifest


def planned_rows(design):
    rows = []
    for rep in design['repetitions']:
        seed = design['seed_base'] + design['repetition_stride'] * (rep - 1)
        for strategy in design['strategies']:
            rows.append(dict(prefix=f'r{rep:02d}_{strategy}', repetition_id=rep, strategy=strategy,
                             risk=design['risk'], mu=design['mu'], population=design['population'],
                             horizon=design['horizon'], seed_base_r=seed, dynamics_seed=seed + 201,
                             consumer_seed=seed + 202, initial_promoter_seed=seed + 200))
    return rows


def execute(row, base, design):
    prefix = row['prefix']
    receipt_path = CHECKS / f'{prefix}_audit.json'
    folder = RAW / prefix
    manifest_path = folder / f'{prefix}_run_manifest.json'
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        if receipt['design_sha256'] != sha256(DESIGN) or receipt['runner_sha256'] != sha256(Path(__file__)):
            raise RuntimeError(f'{prefix}: diseño o ejecutor diferente; utilizar una copia nueva del experimento')
        verify_manifest(manifest_path)
        if receipt['manifest_sha256'] != sha256(manifest_path) or receipt['status'] != 'PASS':
            raise RuntimeError(f'{prefix}: comprobante de auditoría inválido')
        print(f'{prefix}: ya completada; integridad confirmada', flush=True)
        return
    start = time.monotonic()
    config = replace(base, repetition=row['repetition_id'], strategy=row['strategy'],
                     experiment_id=design['experiment_id']).validate()
    model = Model(config).run()
    export_run(model, folder, prefix, purpose='technical_pilot_25')
    manifest = verify_manifest(manifest_path)
    data, meta, _, _ = audit_run(folder, prefix)
    events, periods, cascades = data['events'], data['system_period'], data['cascades']
    if len(periods) != 61 or len(data['agent_period']) != 36600:
        raise RuntimeError('Horizonte o número de estados incompleto')
    edges = {(e['source'], e['target']): e for e in data['edges']}
    classes = Counter(edges[min(e['sender'], e['receiver']), max(e['sender'], e['receiver'])]['tie_class'] for e in events)
    routes = Counter(e['route'] for e in events)
    attempts = len(events)
    fallback = sum(e['fallback'] for e in events)
    late = [e for e in events if e['month'] >= 13]
    result = meta | model.summary() | dict(
        fallback_attempts=fallback, fallback_rate=fallback / attempts if attempts else None,
        attempts_strong=classes['strong'], attempts_weak=classes['weak'], attempts_intermediate=classes['intermediate'],
        attempts_bridge=sum(e['bridge'] for e in events),
        requested_route_A=routes['A'], requested_route_B=routes['B'], requested_route_E=routes['E'],
        active_promoters_at_12=periods[12]['active_promoters'], active_cascades_at_12=periods[12]['active_cascades'],
        viable_after_12=periods[12]['active_promoters'] > 0,
        attempts_after_12=len(late), sent_after_12=sum(e['sent'] for e in late),
        adoptions_after_12=sum(e['adoption'] for e in late),
        route_A_after_12=sum(e['route'] == 'A' for e in late), route_B_after_12=sum(e['route'] == 'B' for e in late),
        max_active_promoters=max(p['active_promoters'] for p in periods),
        satisfied_new_promoters=sum(a.adopted and not a.seed and a.satisfaction >= config.satisfaction_threshold for a in model.agents),
        max_cascade_size=max(c['size'] for c in cascades), max_cascade_depth=max(c['depth'] for c in cascades),
        accepted_candidate=model.network.accepted_candidate)
    assert sum(classes.values()) == attempts and sum(routes.values()) == attempts
    tier_rows = []
    for phase, selected in [('all', events), ('1_12', [e for e in events if e['month'] <= 12]), ('13_60', late)]:
        for route in ('A', 'B', 'E'):
            group = [e for e in selected if e['route'] == route]
            for tier in range(4 if route == 'B' else 2 if route == 'A' else 1):
                count = sum(e['selected_tier'] == tier for e in group)
                tier_rows.append(meta | dict(phase=phase, requested_route=route, selected_tier=tier,
                                            attempts=count, route_attempts=len(group),
                                            fraction=count / len(group) if group else None))
    receipt = dict(prefix=prefix, status='PASS', execution_utc=datetime.now(timezone.utc).isoformat(),
                   elapsed_seconds=round(time.monotonic() - start, 3), python_version=platform.python_version(),
                   design_sha256=sha256(DESIGN), runner_sha256=sha256(Path(__file__)),
                   manifest_sha256=sha256(manifest_path),
                   node_content_sha256=content_hash(data['nodes']), edge_content_sha256=content_hash(data['edges']),
                   network_content_sha256=manifest['network_content_sha256'], tape_sha256=manifest['tape_sha256'],
                   event_rows=len(events), system_rows=len(periods), agent_period_rows=len(data['agent_period']),
                   result=result, tiers=tier_rows)
    save_json(receipt_path, receipt)
    print(f"{prefix}: PASS; adopciones nuevas={model.new_total}; extinción={model.extinction_month}; intentos después de 12={len(late)}", flush=True)


def finalize(design):
    plan = planned_rows(design)
    receipts = []
    for row in plan:
        path = CHECKS / f'{row["prefix"]}_audit.json'
        if not path.exists():
            return False
        receipt = json.loads(path.read_text())
        manifest_path = RAW / row['prefix'] / f'{row["prefix"]}_run_manifest.json'
        verify_manifest(manifest_path)
        assert receipt['manifest_sha256'] == sha256(manifest_path)
        assert receipt['design_sha256'] == sha256(DESIGN)
        assert receipt['runner_sha256'] == sha256(Path(__file__))
        assert receipt['status'] == 'PASS'
        receipts.append(receipt)
    paired = []
    for rep in design['repetitions']:
        block = [r for r in receipts if r['result']['repetition_id'] == rep]
        assert len(block) == 5 and {r['result']['strategy'] for r in block} == set('ABCDE')
        for key in ('node_content_sha256', 'edge_content_sha256', 'network_content_sha256', 'tape_sha256'):
            assert len({r[key] for r in block}) == 1, (rep, key)
        paired.append(dict(repetition_id=rep, status='PASS', strategies=5,
                           network_content_sha256=block[0]['network_content_sha256'], tape_sha256=block[0]['tape_sha256']))
    assert len({r['network_content_sha256'] for r in paired}) == 5
    assert len({r['result']['run_id'] for r in receipts}) == 25
    write_csv(CHECKS / 'paired_checks.csv', paired)
    write_csv(CHECKS / 'run_audits.csv', [{k: r[k] for k in ('prefix', 'status', 'execution_utc', 'elapsed_seconds', 'event_rows', 'system_rows', 'agent_period_rows')} for r in receipts])
    summary_folder = ROOT / 'outputs' / 'tables'
    write_csv(summary_folder / 'run_summary_25.csv', [r['result'] for r in receipts])
    write_csv(summary_folder / 'selection_tiers.csv', [row for r in receipts for row in r['tiers']])
    completed = dict(status='PASS', experiment_id=design['experiment_id'], model_version='0.2',
                     planned_runs=25, completed_runs=25, audited_runs=25, paired_blocks_passed=5,
                     distinct_networks=5, horizon=60, system_period_rows=sum(r['system_rows'] for r in receipts),
                     agent_period_rows=sum(r['agent_period_rows'] for r in receipts), events=sum(r['event_rows'] for r in receipts),
                     empirical_calibration=False, model_modified=False, principal_experiment_executed=False,
                     finalization_utc=datetime.now(timezone.utc).isoformat(), python_version=platform.python_version(),
                     design_sha256=sha256(DESIGN), runner_sha256=sha256(Path(__file__)),
                     total_run_audit_seconds=round(sum(r['elapsed_seconds'] for r in receipts), 3),
                     receipt_sha256={f'{r["prefix"]}_audit.json': sha256(CHECKS / f'{r["prefix"]}_audit.json') for r in receipts})
    save_json(CHECKS / 'pilot_completion.json', completed)
    print('PILOT_COMPLETE: 25 audited runs, 5 paired blocks, no model changes.', flush=True)
    return True


def main():
    if not __debug__:
        raise RuntimeError('Ejecutar sin -O: se requieren las comprobaciones del auditor')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', type=int, choices=range(1, 6), help='Ejecutar solo esta repetición (cinco estrategias)')
    parser.add_argument('--finalize-only', action='store_true')
    args = parser.parse_args()
    design = json.loads(DESIGN.read_text())
    for file in design['engine_files']:
        if sha256(ROOT / file['path']) != file['sha256']:
            raise RuntimeError(f'Motor v0.2 alterado: {file["path"]}')
    base = Config.load(ROOT / design['base_config'])
    assert (base.population, base.horizon, base.risk, base.mu) == (600, 60, .5, .2)
    plan = planned_rows(design)
    assert len(plan) == 25
    write_csv(ROOT / 'design' / 'run_plan_25.csv', plan)
    if not args.finalize_only:
        for row in plan:
            if args.batch is None or row['repetition_id'] == args.batch:
                execute(row, base, design)
    complete = finalize(design)
    if args.finalize_only and not complete:
        raise RuntimeError('Faltan corridas para cerrar el piloto')


if __name__ == '__main__':
    main()
