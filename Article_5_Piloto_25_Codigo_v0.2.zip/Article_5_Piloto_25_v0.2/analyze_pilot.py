#!/usr/bin/env python3
"""Análisis descriptivo del piloto; no ejecuta ni modifica el modelo."""
import csv
import hashlib
import itertools
import json
from pathlib import Path
import platform
import statistics as st
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'engine'))
from article5.io import write_csv
from tests.audit_exports import read
from run_pilot import verify_manifest

TABLES = ROOT / 'outputs' / 'tables'
FIGURES = ROOT / 'outputs' / 'figures'
REPORT = ROOT / 'outputs' / 'Article_5_Informe_piloto_25_v0.2.md'
STRATEGIES = list('ABCDE')
LABELS = dict(A='Fuerte', B='Débil / puente', C='Balanceada', D='Secuencial', E='Aleatoria')
METRICS = ['new_adoptions', 'total_adoptions', 'adoption_at_12', 'attempts', 'sent',
           'unique_reach', 'coverage', 'conversion', 'eligible_conversion',
           'effort_efficiency', 'redundancy', 'fallback_rate', 'extinction_month',
           'new_communities_adopted', 'max_cascade_size', 'max_cascade_depth']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def quantile(xs, q):
    """Cuantil con interpolación lineal en (n-1)*q, incluido n=1."""
    xs = sorted(xs)
    x = (len(xs) - 1) * q
    i = int(x)
    return xs[i] + (x - i) * (xs[min(i + 1, len(xs) - 1)] - xs[i])


def stats(xs):
    valid = [x for x in xs if x is not None]
    if not valid:
        return dict(n=0, mean=None, sd=None, median=None, minimum=None, maximum=None,
                    p05=None, q1=None, q3=None, p95=None)
    return dict(n=len(valid), mean=st.mean(valid), sd=st.stdev(valid) if len(valid) > 1 else None,
                median=st.median(valid), minimum=min(valid), maximum=max(valid),
                **{k: quantile(valid, q) for k, q in [('p05', .05), ('q1', .25), ('q3', .75), ('p95', .95)]})


def fmt(x, decimals=1):
    return 'NA' if x is None else f'{x:.{decimals}f}'.replace('.', ',')


def main():
    completion_path = ROOT / 'outputs/checks/pilot_completion.json'
    completion = json.loads(completion_path.read_text())
    assert completion['status'] == 'PASS' and completion['completed_runs'] == 25
    assert completion['runner_sha256'] == sha(ROOT / 'run_pilot.py')
    assert completion['design_sha256'] == sha(ROOT / 'design/pilot_design.json')
    data = read(TABLES / 'run_summary_25.csv')
    assert len(data) == 25
    for name, digest in completion['receipt_sha256'].items():
        path = ROOT / 'outputs/checks' / name
        assert sha(path) == digest
        receipt = json.loads(path.read_text())
        prefix = receipt['prefix']
        manifest_path = ROOT / 'outputs/raw' / prefix / f'{prefix}_run_manifest.json'
        assert sha(manifest_path) == receipt['manifest_sha256']
        verify_manifest(manifest_path)
        matched = [r for r in data if r['run_id'] == receipt['result']['run_id']]
        assert len(matched) == 1
        # Versiones se leen como números en los CSV, como cadenas en JSON.
        assert all(matched[0][k] == v for k, v in receipt['result'].items()
                   if k not in ('model_version', 'configuration_version'))

    groups = {s: [r for r in data if r['strategy'] == s] for s in STRATEGIES}
    descriptives = [dict(strategy=s, metric=m, **stats([r[m] for r in groups[s]]))
                    for s in STRATEGIES for m in METRICS]
    write_csv(TABLES / 'descriptive_statistics.csv', descriptives)
    lookup = {(r['strategy'], r['metric']): r for r in descriptives}
    mean = lambda s, m: lookup[s, m]['mean']

    paired = []
    pair_metrics = ['new_adoptions', 'coverage', 'conversion', 'effort_efficiency', 'redundancy']
    by_rep_strategy = {(r['repetition_id'], r['strategy']): r for r in data}
    for left, right in itertools.combinations(STRATEGIES, 2):
        for rep in range(1, 6):
            a, b = by_rep_strategy[rep, left], by_rep_strategy[rep, right]
            for metric in pair_metrics:
                delta = None if a[metric] is None or b[metric] is None else b[metric] - a[metric]
                paired.append(dict(repetition_id=rep, contrast=f'{right}-{left}', metric=metric,
                                   left_strategy=left, right_strategy=right,
                                   left_value=a[metric], right_value=b[metric], delta_right_minus_left=delta))
    write_csv(TABLES / 'paired_differences.csv', paired)
    pair_summary = []
    for left, right in itertools.combinations(STRATEGIES, 2):
        for m in pair_metrics:
            xs = [r['delta_right_minus_left'] for r in paired if r['contrast'] == f'{right}-{left}' and r['metric'] == m]
            valid = [x for x in xs if x is not None]
            pair_summary.append(dict(contrast=f'{right}-{left}', metric=m, **stats(xs),
                                     positive=sum(x > 0 for x in valid), zero=sum(x == 0 for x in valid),
                                     negative=sum(x < 0 for x in valid)))
    write_csv(TABLES / 'paired_summary.csv', pair_summary)

    survival = []
    for s, g in groups.items():
        survival.append(dict(strategy=s, runs=len(g), extinct_by_12=sum(r['early_extinction'] for r in g),
                             viable_at_end_12=sum(r['viable_after_12'] for r in g),
                             runs_with_attempts_after_12=sum(r['attempts_after_12'] > 0 for r in g),
                             attempts_after_12=sum(r['attempts_after_12'] for r in g),
                             adoptions_after_12=sum(r['adoptions_after_12'] for r in g),
                             censored_at_60=sum(not r['extinction_event'] for r in g)))
    write_csv(TABLES / 'survival_at_12.csv', survival)
    d_columns = ['repetition_id', 'active_promoters_at_12', 'active_cascades_at_12', 'extinction_month',
                 'attempts_after_12', 'sent_after_12', 'adoptions_after_12', 'route_A_after_12', 'route_B_after_12']
    write_csv(TABLES / 'strategy_D_phase2.csv', [{k: r[k] for k in d_columns} for r in groups['D']])

    profiles = []
    for r in data:
        profiles.append({k: r[k] for k in ['repetition_id', 'strategy', 'attempts', 'fallback_attempts', 'fallback_rate']} |
                        {f'fraction_{c}': r[f'attempts_{c}'] / r['attempts'] for c in ['strong', 'weak', 'intermediate', 'bridge']} |
                        {f'requested_fraction_{c}': r[f'requested_route_{c}'] / r['attempts'] for c in 'ABE'})
    write_csv(TABLES / 'realized_selection_profiles.csv', profiles)
    tier_rows = read(TABLES / 'selection_tiers.csv')
    tiers = []
    for s in STRATEGIES:
        for phase in ['all', '1_12', '13_60']:
            for route in 'ABE':
                for tier in range(4 if route == 'B' else 2 if route == 'A' else 1):
                    cells = [r for r in tier_rows if (r['strategy'], r['phase'], r['requested_route'], r['selected_tier']) == (s, phase, route, tier)]
                    denom = sum(r['route_attempts'] for r in cells)
                    count = sum(r['attempts'] for r in cells)
                    tiers.append(dict(strategy=s, phase=phase, requested_route=route, selected_tier=tier,
                                      attempts_pooled=count, route_attempts_pooled=denom,
                                      fraction_pooled=count / denom if denom else None,
                                      **stats([r['fraction'] for r in cells])))
    write_csv(TABLES / 'selection_tier_summary.csv', tiers)
    network_rows = []
    for rep in range(1, 6):
        p = f'r{rep:02d}_A'
        for r in read(ROOT / 'outputs/raw' / p / f'{p}_network_diagnostics.csv'):
            network_rows.append({k: r[k] for k in ['repetition_id', 'active_only', 'edges', 'mean_degree', 'density',
                                                  'components', 'giant_component', 'bridges', 'bridge_share', 'modularity', 'mean_clustering']})
    write_csv(TABLES / 'network_diagnostics_5.csv', network_rows)
    adoption_grid = [dict(repetition_id=rep, **{s: by_rep_strategy[rep, s]['new_adoptions'] for s in STRATEGIES}) for rep in range(1, 6)]
    write_csv(TABLES / 'new_adoptions_paired.csv', adoption_grid)
    headline = [dict(strategy=s, new_adoptions_mean=mean(s, 'new_adoptions'),
                     new_adoptions_sd=lookup[s, 'new_adoptions']['sd'],
                     new_adoptions_min=lookup[s, 'new_adoptions']['minimum'],
                     new_adoptions_max=lookup[s, 'new_adoptions']['maximum'],
                     coverage_mean=mean(s, 'coverage'), conversion_mean=mean(s, 'conversion'),
                     fallback_rate_mean=mean(s, 'fallback_rate'),
                     runs_active_after_12=sum(r['attempts_after_12'] > 0 for r in groups[s])) for s in STRATEGIES]
    write_csv(TABLES / 'headline_results.csv', headline)

    # Figuras científicas estáticas; los puntos pequeños siempre representan corridas reales.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    FIGURES.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False,
                         'axes.spines.right': False, 'figure.dpi': 140, 'savefig.dpi': 180})
    colors = dict(zip(STRATEGIES, ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#5D5D5D']))
    rep_colors = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#8B6D00']
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.2))
    panels = [('new_adoptions', 'Nuevas adopciones', False), ('coverage', 'Cobertura por WOM', True),
              ('conversion', 'Conversión', True)]
    for ax, (metric, title, percent) in zip(axes, panels):
        for rep in range(1, 6):
            ax.plot(STRATEGIES, [by_rep_strategy[rep, s][metric] for s in STRATEGIES],
                    marker='o', lw=1, ms=4, alpha=.75, color=rep_colors[rep - 1], label=f'Repetición {rep}')
        ax.scatter(STRATEGIES, [mean(s, metric) for s in STRATEGIES], color='black', marker='D', s=42,
                   zorder=5, label='Media de 5 corridas')
        ax.set_title(title, fontweight='bold')
        ax.grid(axis='y', alpha=.2)
        ax.set_ylim(bottom=0)
        if percent:
            ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=3, frameon=False, bbox_to_anchor=(.5, .015))
    fig.suptitle('Piloto: cinco comparaciones emparejadas de A–E', fontweight='bold', y=.99)
    fig.text(.5, .14, 'A fuerte · B débil / puente · C balanceada · D secuencial · E aleatoria', ha='center', fontsize=9)
    fig.tight_layout(rect=(0, .19, 1, .94))
    save_figure(fig, 'resultados_emparejados')

    fig, axes = plt.subplots(2, 3, figsize=(12, 6.6), sharex=True, sharey=True)
    for ax, s in zip(axes.flat, STRATEGIES):
        for rep in range(1, 6):
            p = f'r{rep:02d}_{s}'
            periods = read(ROOT / 'outputs/raw' / p / f'{p}_system_period.csv')
            ax.step([r['month'] for r in periods], [r['total_adoptions'] - 12 for r in periods],
                    where='post', color=rep_colors[rep - 1], lw=1.5, label=f'Repetición {rep}')
        ax.axvline(12, color='#666666', ls='--', lw=.9)
        ax.set_title(f'{s} · {LABELS[s]}', fontweight='bold')
        ax.set_xlim(0, 60)
        ax.set_ylim(bottom=0)
        ax.grid(alpha=.18)
    axes.flat[-1].axis('off')
    handles, labels = axes.flat[0].get_legend_handles_labels()
    axes.flat[-1].legend(handles, labels, loc='upper left', frameon=False)
    axes.flat[-1].text(.03, .34, 'Línea discontinua: cierre del período 12.\nD cambia sus probabilidades desde 13.\n\nTodas las series llegan al período 60;\ntras la extinción, el acumulado es constante.',
                       transform=axes.flat[-1].transAxes, fontsize=9, va='top', linespacing=1.6)
    fig.supxlabel('Período del modelo')
    fig.supylabel('Nuevas adopciones acumuladas (excluye 12 iniciales)')
    fig.suptitle('Trayectorias del piloto Python v0.2', fontweight='bold')
    fig.tight_layout(rect=(.015, .02, 1, .96))
    save_figure(fig, 'trayectorias_25')

    main_table = '\n'.join(f"| {s} · {LABELS[s]} | {fmt(mean(s,'new_adoptions'))} ± {fmt(lookup[s,'new_adoptions']['sd'])} | {lookup[s,'new_adoptions']['minimum']}–{lookup[s,'new_adoptions']['maximum']} | {fmt(100*mean(s,'coverage'))}% | {fmt(100*mean(s,'conversion'))}% | {fmt(100*mean(s,'redundancy'))}% |" for s in STRATEGIES)
    adoption_table = '\n'.join('| ' + ' | '.join(str(r[k]) for k in ['repetition_id', *STRATEGIES]) + ' |' for r in adoption_grid)
    survival_table = '\n'.join(f"| {r['strategy']} | {r['extinct_by_12']}/5 | {r['viable_at_end_12']}/5 | {r['runs_with_attempts_after_12']}/5 | {r['attempts_after_12']} | {r['adoptions_after_12']} |" for r in survival)
    fallback_table = '\n'.join(f"| {s} | {fmt(100*mean(s,'fallback_rate'))}% | {fmt(100*st.mean(r['fraction_strong'] for r in profiles if r['strategy']==s))}% | {fmt(100*st.mean(r['fraction_weak'] for r in profiles if r['strategy']==s))}% | {fmt(100*st.mean(r['fraction_bridge'] for r in profiles if r['strategy']==s))}% |" for s in STRATEGIES)
    dtable = '\n'.join(f"| {r['repetition_id']} | {r['active_promoters_at_12']} | {r['attempts_after_12']} | {r['route_A_after_12']} | {r['route_B_after_12']} | {r['adoptions_after_12']} |" for r in groups['D'])
    late_d = sum(r['attempts_after_12'] for r in groups['D'])
    route_b_d = sum(r['route_B_after_12'] for r in groups['D'])
    active_networks = [r for r in network_rows if r['active_only']]
    report = f'''# Artículo 5 — Informe del piloto de 25 corridas

Python v0.2 · 26 de septiembre de 2026 · Experimento `pilot25_python_v0.2`

## Resultado del piloto

Se completaron **25 de 25 corridas y las 25 aprobaron la auditoría de sus exportaciones**. Los cinco bloques conservaron la misma red, atributos, consumidores, promotores iniciales y cinta de sorteos entre A–E. Se utilizaron cinco redes distintas entre repeticiones. El motor, las probabilidades, los recursos y el cambio de fase de D permanecieron en v0.2, sin ajustes. No se realizó calibración con datos reales.

El resultado permite continuar con el diseño del experimento principal. No establece una estrategia superior: hay solo cinco repeticiones independientes y variación considerable. D tuvo oportunidad de actuar después del período 12 en **3 de 5** corridas; en las otras dos la difusión ya se había extinguido.

## Diseño y alcance

Cada repetición incluye las estrategias A fuerte, B débil con prioridad de puente, C balanceada, D secuencial y E aleatoria. Se mantuvieron 600 consumidores, seis comunidades, 12 promotores iniciales, riesgo 0,50, mu 0,20, calidad 0,90, dos intentos por período, cuatro intentos por promotor y horizonte de 60 períodos. Los períodos son una convención del modelo, no meses calibrados.

Las semillas base son 20260925, 20261925, 20262925, 20263925 y 20264925. El diseño y el plan registran los desplazamientos para redes, atributos, consumidores y dinámica. Las comparaciones entre estrategias están emparejadas dentro de cada repetición. La unidad independiente es la repetición, **n = 5**, no las 25 corridas ni los consumidores individuales.

Este piloto queda separado de la base principal. No se ejecutaron las 500 corridas principales ni los análisis de sensibilidad. Fuente normativa: `Article_5_Especificacion_minima_Python_v0.2.md`, secciones 8–12; implementación congelada registrada en `design/pilot_design.json`.

## Verificación técnica

| Comprobación | Resultado |
|---|---:|
| Corridas completas / auditadas | 25 / 25 |
| Bloques emparejados correctos | 5 / 5 |
| Redes distintas entre repeticiones | 5 |
| Registros de sistema, incluidos períodos 0 y 60 | 1.525 |
| Registros agente–período | 915.000 |
| Intentos registrados como eventos | 5.309 |
| Corridas excluidas | 0 |
| Corridas censuradas por extinción al cierre de 60 | 0 |

La auditoría reconstruyó los eventos desde los CSV y contrastó elegibilidad, probabilidades, gasto de energía, límites por período y pareja dirigida, adopciones únicas, ascendencia, cascadas, acumulados y métricas. Las huellas SHA-256 confirmaron la integridad de las tablas y la identidad del motor. Estas comprobaciones verifican consistencia computacional; no son validación empírica.

Las cinco redes aceptaron el primer candidato, sin selección por desempeño de difusión. La componente activa mayor contiene 600 consumidores en cuatro redes y 599 en la repetición 4; todas superan el criterio mínimo de 570. El grado medio activo varió entre {fmt(min(r['mean_degree'] for r in active_networks),2)} y {fmt(max(r['mean_degree'] for r in active_networks),2)}; la fracción de enlaces entre comunidades, entre {fmt(100*min(r['bridge_share'] for r in active_networks))}% y {fmt(100*max(r['bridge_share'] for r in active_networks))}%. Mu es una proporción esperada y no la modularidad observada.

## Resultados descriptivos

Las tasas de la tabla son **medias de las cinco tasas por corrida**, no cocientes obtenidos al juntar eventos. DE es la desviación estándar muestral entre repeticiones. Todas las conversiones tienen denominador positivo. Nuevas adopciones excluye a los 12 adoptantes iniciales. Cobertura = receptores únicos no iniciales / 588; conversión = nuevas adopciones / envíos; redundancia = exposiciones repetidas / envíos.

| Estrategia | Nuevas adopciones: media ± DE | Mín.–máx. | Cobertura media | Conversión media | Redundancia media |
|---|---:|---:|---:|---:|---:|
{main_table}

Las nuevas adopciones de cada bloque muestran cuánto depende el promedio de la repetición:

| Repetición | A | B | C | D | E |
|---|---:|---:|---:|---:|---:|
{adoption_table}

A alcanzó una media de 67,2 nuevas adopciones, pero su rango fue 15–179. La repetición 3 elevó especialmente los resultados de A y D. En el contraste emparejado A menos E, las diferencias fueron −8, −4, 77, 6 y 17 adopciones: A obtuvo más en tres repeticiones y E en dos. Una diferencia media de 17,6 no demuestra superioridad general.

B presentó menor redundancia media y una media de 2,4 nuevas comunidades adoptantes frente a 1,2 de A, pero su cobertura individual media fue menor. Llegar a más comunidades y alcanzar a más personas son indicadores distintos. La prioridad de B combina fuerza del vínculo y posición entre comunidades, por lo que este contraste no identifica sus efectos por separado.

No se realizaron pruebas de significación ni selección de parámetros. Los percentiles 5 y 95 y los cuartiles incluidos en las tablas son resúmenes interpolados de cinco observaciones, no intervalos de confianza. El archivo de diferencias emparejadas conserva los diez contrastes y el sentido explícito «derecha menos izquierda».

![Resultados emparejados](figures/resultados_emparejados.png)

## Supervivencia y oportunidad de actuar de D

Las 25 difusiones se extinguieron entre los períodos {min(r['extinction_month'] for r in data)} y {max(r['extinction_month'] for r in data)}. Las series se conservaron hasta 60. La extinción se refiere a pérdida de capacidad para continuar; un período sin envíos no se clasifica por sí solo como extinción.

| Estrategia | Extintas al cierre de 12 | Con capacidad al cierre de 12 | Con intentos desde 13 | Intentos desde 13, suma | Nuevas adopciones desde 13, suma |
|---|---:|---:|---:|---:|---:|
{survival_table}

D solicita A con probabilidad 0,80 hasta el período 12 y 0,30 desde el 13; el resto solicita B. La segunda fase se observó así:

| Repetición de D | Promotores con capacidad al cierre de 12 | Intentos desde 13 | Ruta A solicitada | Ruta B solicitada | Nuevas adopciones desde 13 |
|---|---:|---:|---:|---:|---:|
{dtable}

Los {late_d} intentos de la segunda fase de D solicitaron B en {route_b_d} ocasiones ({fmt(100*route_b_d/late_d)}%). Es una proporción agrupada descriptiva, no una cuota impuesta. Las diferencias observadas frente a otras estrategias no identifican el efecto causal del cambio de fase: D tiene también una mezcla diferente antes del período 13. No se adelantó retrospectivamente la transición.

![Trayectorias de las 25 corridas](figures/trayectorias_25.png)

## Sustituciones y contactos realizados

«Sustitución» significa que se seleccionó un nivel posterior al primero de la ruta solicitada. En B, pasar de débiles entre comunidades a débiles internas ya cuenta como sustitución, aunque el contacto siga siendo débil. E tiene un solo nivel; su tasa cero se deriva de esa definición. Las columnas de clase y puente no son excluyentes: un contacto puede ser débil y puente a la vez. Se muestran medias de proporciones por corrida.

| Estrategia | Sustituciones / intentos | Contactos fuertes / intentos | Contactos débiles / intentos | Puentes / intentos |
|---|---:|---:|---:|---:|
{fallback_table}

B necesitó sustituciones en un promedio del {fmt(100*mean('B','fallback_rate'))}% de sus intentos. Por ello, el artículo debe distinguir la ruta solicitada del contacto realmente seleccionado. Los archivos `selection_tiers.csv`, `selection_tier_summary.csv` y `realized_selection_profiles.csv` permiten revisar niveles, fases y denominadores. Las sustituciones previstas por el diseño no constituyen errores del modelo.

## Decisión sugerida

El piloto no detectó un bloqueo técnico para ejecutar la comparación base de 100 repeticiones por estrategia. Conviene mantener v0.2 y el corte de D en 12 para esa etapa, conservar el emparejamiento y reportar extinción temprana, sustituciones y variación junto con conversión y cobertura. Cualquier cambio de reglas debe registrarse como una versión y un experimento separados, sin reemplazar este piloto.

La siguiente etapa propuesta es la comparación base de 500 corridas. No se ha ejecutado. Los resultados actuales son evidencia del comportamiento del modelo bajo estos supuestos académicos; no son estimaciones de ventas ni recomendaciones empíricas para empresas.

## Archivos y reproducción

- `design/`: diseño congelado y plan de 25 corridas.
- `engine/`: motor y auditor Python v0.2, sin modificaciones.
- `run_pilot.py`: ejecutor por bloques, reanudación e integridad.
- `analyze_pilot.py`: tablas, figuras e informe reproducibles.
- `outputs/raw/`: 11 tablas CSV y un manifiesto por corrida.
- `outputs/checks/`: 25 comprobantes, auditoría agregada, cinco verificaciones de emparejamiento y cierre del piloto.
- `outputs/tables/`: resultados por corrida, estadísticas, contrastes, supervivencia, perfiles y diagnósticos.
- `outputs/figures/`: dos figuras en PNG y PDF.

Se ejecutó con Python {platform.python_version()}. El motor y las auditorías usan la biblioteca estándar; el análisis gráfico usa Matplotlib {matplotlib.__version__}. El README contiene los comandos. Los tiempos de ejecución se conservan como metadatos del entorno y no se interpretan como un benchmark.
'''
    REPORT.write_text(report, encoding='utf-8')
    generated = sorted(TABLES.glob('*.csv')) + sorted(FIGURES.glob('*')) + [REPORT]
    manifest = dict(experiment_id=completion['experiment_id'], analysis_unit='repetition', independent_repetitions=5,
                    inference='descriptive only; no superiority tests', percentiles='linear interpolation, index (n-1)*q',
                    rates='mean of run-level ratios, unless explicitly labeled pooled',
                    python_version=platform.python_version(), matplotlib_version=matplotlib.__version__,
                    analysis_script_sha256=sha(Path(__file__)), completion_sha256=sha(completion_path),
                    output_sha256={str(p.relative_to(ROOT)): sha(p) for p in generated})
    (ROOT / 'outputs/analysis_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(status='PASS', analysis_tables=len(list(TABLES.glob('*.csv'))), figures=4,
                          report=str(REPORT), late_phase_D_runs=3, headline=headline), ensure_ascii=False, indent=2))


def save_figure(fig, name):
    fig.savefig(FIGURES / f'{name}.png', facecolor='white')
    fig.savefig(FIGURES / f'{name}.pdf', facecolor='white', metadata={'CreationDate': None, 'ModDate': None})
    import matplotlib.pyplot as plt
    plt.close(fig)


if __name__ == '__main__':
    main()
