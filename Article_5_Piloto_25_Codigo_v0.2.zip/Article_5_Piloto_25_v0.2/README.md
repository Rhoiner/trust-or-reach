# Artículo 5 — Piloto de 25 corridas, Python v0.2

Piloto académico ejecutado el 26 de septiembre de 2026. Cinco estrategias A–E por cinco repeticiones emparejadas. Las 25 corridas y los cinco bloques aprobaron la auditoría. No hay calibración empírica ni cambios al motor v0.2.

## Lectura de los resultados

Abrir `outputs/Article_5_Informe_piloto_25_v0.2.md`. La tabla breve es `outputs/tables/headline_results.csv`; las 25 observaciones completas están en `outputs/tables/run_summary_25.csv`.

La unidad independiente es la repetición (n = 5). Los promedios no constituyen pruebas de superioridad. D actuó desde el período 13 en tres de cinco corridas. No se movió su transición para favorecerla. El piloto se conserva separado del experimento principal.

## Paquetes y estructura

Los ZIP de código, datos, verificación, análisis y figuras tienen la misma carpeta superior `Article_5_Piloto_25_v0.2`. Extraerlos en el mismo directorio para reunir el proyecto. El paquete de análisis ya incluye las figuras; el paquete de figuras permite descargarlas por separado.

- Código: `engine/`, `design/`, `run_pilot.py`, `analyze_pilot.py`, este README y requisitos gráficos.
- Datos: `outputs/raw/`, 25 carpetas, cada una con 11 CSV y un manifiesto JSON.
- Verificación: `outputs/checks/`, 25 comprobantes, verificaciones emparejadas, resumen de auditoría y cierre.
- Análisis: `outputs/tables/`, `outputs/figures/`, informe y manifiesto de análisis.
- Diseño: configuración JSON y `run_plan_25.csv`, también incluidos en el código.

## Ejecutar desde cero

Python 3.10 o posterior; la ejecución original utilizó Python 3.12.14. El modelo y su auditor usan exclusivamente la biblioteca estándar. Descomprimir únicamente el paquete de código en una carpeta nueva y ejecutar desde `Article_5_Piloto_25_v0.2`:

```bash
python run_pilot.py
```

También se puede ejecutar un bloque con `python run_pilot.py --batch 1` y continuar con los bloques 2 a 5. El ejecutor omite corridas ya completas después de validar su integridad. Se detiene si encuentra un comprobante incompatible o datos alterados. No utilizar `python -O`: desactiva las comprobaciones de la auditoría.

Con los paquetes de datos y verificación ya descomprimidos, se puede comprobar la integridad y regenerar el cierre sin simular:

```bash
python run_pilot.py --finalize-only
```

Esta operación actualiza la fecha de cierre; regenerar después el análisis para actualizar su manifiesto. Si se quiere comprobar la evidencia original sin modificar sus metadatos, ejecutar directamente el análisis: verifica las huellas de los datos, el motor, los comprobantes y la tabla de 25 resultados antes de leerlos.

## Generar tablas, figuras e informe

```bash
python -m pip install -r requirements-analysis.txt
python analyze_pilot.py
```

Matplotlib solo es necesario para las figuras. Los CSV y las estadísticas se procesan con la biblioteca estándar. El análisis no ejecuta corridas ni modifica sus resultados. Produce 12 tablas CSV, dos figuras en PNG y PDF, un informe Markdown y un manifiesto con SHA-256.

## Diseño congelado

600 agentes, seis comunidades, 12 promotores iniciales, 60 períodos, riesgo 0,50, mu 0,20. Cada repetición comparte red, atributos, consumidores, promotores y cinta de sorteos entre estrategias. Cinco redes distintas entre repeticiones. El plan identifica semillas e IDs; el JSON conserva las huellas del motor v0.2 y del ZIP de origen.

A prioriza vínculos fuertes; B prioriza débiles entre comunidades, luego débiles internos, otros puentes y resto; C solicita A o B con probabilidad 0,50; D solicita A con probabilidad 0,80 hasta 12 y 0,30 desde 13; E elige uniformemente. Cada promotor dispone de cuatro intentos, hasta dos por período. Los intentos totales pueden diferir porque las nuevas adopciones crean promotores.

## Diccionario mínimo

Los CSV usan coma como separador, punto decimal, UTF-8, `true`/`false` y `NA` para valores no definidos. Identificadores de repetición 1–5; estrategias A–E. Los porcentajes se guardan como fracciones entre 0 y 1.

| Campo o archivo | Interpretación |
|---|---|
| `new_adoptions` | Nuevos adoptantes, excluye los 12 iniciales |
| `total_adoptions` | Iniciales + nuevos |
| `adoption_at_12` | Adoptantes totales al cierre del período 12 |
| `unique_reach` | Receptores únicos de al menos un envío, excluye iniciales |
| `coverage` | Alcance único / 588 |
| `conversion` | Nuevas adopciones / envíos |
| `effort_efficiency` | Nuevas adopciones / intentos |
| `redundancy` | Exposiciones repetidas / envíos |
| `fallback_rate` | Intentos que usaron un nivel posterior al primero de su ruta / intentos |
| `extinction_month` | Primer cierre sin promotores con capacidad para continuar; NA si no ocurre |
| `early_extinction` | Extinción al cierre de 12 o antes |
| `viable_after_12` | Existe capacidad al cierre de 12 |
| `attempts_after_12` | Intentos efectivamente observados en 13–60 |
| `time_0.1`, `time_0.25`, `time_0.5` | Primer período con 10%, 25% o 50% de adopción total; NA si no se alcanza |
| `event_*`, `observed_*` | Indicador de umbral alcanzado y tiempo observado/censurado en 60 |
| `paired_differences.csv` | Diferencia «estrategia derecha menos izquierda» dentro de cada repetición |
| `descriptive_statistics.csv` | n válido, media, DE muestral, mediana, mínimo, máximo y cuantiles lineales |
| `selection_tier_summary.csv` | Incluye tanto medias por corrida como proporciones agrupadas rotuladas `pooled` |

Las tasas medias se calculan por corrida y luego entre las cinco repeticiones; no se ponderan por número de eventos. Los percentiles interpolados de n = 5 no son intervalos de confianza. No se calcularon pruebas de significación.

## Trazabilidad

`outputs/checks/pilot_completion.json` registra la ejecución original, las 25 auditorías y las huellas de sus comprobantes. Cada manifiesto de corrida contiene huellas de tablas, código, red y cinta de sorteos. `outputs/analysis_manifest.json` registra la procedencia de los resultados derivados.

El análisis y la interpretación no sustituyen la especificación `Article_5_Especificacion_minima_Python_v0.2.md` del proyecto. El motor está congelado. No se ejecutaron el experimento principal ni la sensibilidad y no se añadieron resultados al manuscrito.
