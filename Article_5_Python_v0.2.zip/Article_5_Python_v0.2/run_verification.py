#!/usr/bin/env python3
"""Ejecuta 20 pruebas y audita seis corridas técnicas; no ejecuta el piloto."""
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import platform
import sys
import time
import unittest

from article5.io import sha256, write_csv
from tests.audit_exports import audit_run, content_hash
from tests.test_model import Verification

PROJECT = Path(__file__).resolve().parent
OUTPUT = PROJECT / 'outputs' / 'verification'


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows = []

    def record(self, test, status, detail):
        name = test._testMethodName
        self.rows.append(dict(test_id=name.split('_')[1], test=name, status=status, detail=detail))
        print(f'{name}: {status}', flush=True)

    def addSuccess(self, test):
        super().addSuccess(test)
        self.record(test, 'PASS', getattr(test, 'observed', 'All assertions passed'))

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.record(test, 'FAIL', self._exc_info_to_string(err, test))

    def addError(self, test, err):
        super().addError(test, err)
        self.record(test, 'ERROR', self._exc_info_to_string(err, test))


def main():
    if not __debug__:
        raise RuntimeError('No ejecutar con -O: la auditoría requiere assertions activas')
    OUTPUT.mkdir(parents=True, exist_ok=True)
    # Retirar únicamente el resumen de éxito previo. Cada CSV se publica de forma atómica.
    (OUTPUT / 'verification_summary.json').unlink(missing_ok=True)
    (OUTPUT / 'python_audit.csv').unlink(missing_ok=True)
    start, timestamp = time.monotonic(), datetime.now(timezone.utc).isoformat()
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Verification)
    result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=RecordingResult).run(suite)
    (OUTPUT / 'verification.log').write_text(stream.getvalue(), encoding='utf-8')
    write_csv(OUTPUT / 'model_tests.csv', result.rows)
    if not result.wasSuccessful() or result.testsRun != 20:
        raise RuntimeError('Pruebas fallidas: revisar outputs/verification/verification.log')
    audits, signatures, metrics = [], [], []
    for prefix in [f'smoke_{s}' for s in 'ABCDE'] + ['no_bridges']:
        data, metadata, _, _ = audit_run(OUTPUT, prefix)
        manifest = json.loads((OUTPUT / f'{prefix}_run_manifest.json').read_text())
        for filename, digest in manifest['output_sha256'].items():
            if sha256(OUTPUT / filename) != digest:
                raise RuntimeError(f'Archivo incompleto o alterado: {filename}')
        for filename, digest in manifest['source_sha256'].items():
            if sha256(PROJECT / filename) != digest:
                raise RuntimeError(f'Código modificado durante la ejecución: {filename}')
        if prefix.startswith('smoke_'):
            signatures.append((content_hash(data['nodes']), content_hash(data['edges']), manifest['tape_sha256']))
        audits.append(dict(audit=prefix, status='PASS', detail=f"Independent replay: {len(data['events'])} events; 61 periods; 36600 agent-period records; file hashes match"))
        metrics.append({'run': prefix} | {k: data['run_summary'][0][k] for k in
                       ('attempts', 'sent', 'new_adoptions', 'total_adoptions', 'unique_reach', 'extinction_month', 'active_promoters')})
        print(f'{prefix}: independent audit PASS', flush=True)
    if not all(s == signatures[0] for s in signatures):
        raise RuntimeError('A-E no comparten condiciones iniciales y sorteos')
    audits.append(dict(audit='paired_initial_conditions_and_tapes', status='PASS', detail='Identical A-E nodes, edges, attributes, initial promoters and precomputed random numbers'))
    write_csv(OUTPUT / 'python_audit.csv', audits)
    write_csv(OUTPUT / 'technical_run_summary.csv', metrics)
    summary = dict(status='PASS', model_version='0.2', configuration_version='0.2', platform='Python',
        python_version=platform.python_version(), environment=platform.platform(), execution_utc=timestamp,
        elapsed_seconds=round(time.monotonic() - start, 3), model_tests_passed=20, specification_tests_passed=16,
        migration_tests_passed=4, independent_audits_passed=7, smoke_runs=5, no_bridge_control_runs=1,
        empirical_calibration=False, pilot_executed=False, conditional_netlogo_replay=True,
        netlogo_random_sequence_equivalence=False)
    (OUTPUT / 'verification_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print(f'VERIFICATION FAILED: {exc}', file=sys.stderr)
        sys.exit(1)
