"""V01–V16: reglas; M01–M04: migración y ejecución en Python."""
from array import array
from collections import Counter, defaultdict
from dataclasses import replace
import json
import math
import os
from pathlib import Path
import random
import tempfile
import unittest

from article5 import Config, Model
from article5.io import export_run, sha256
from article5.model import adoption_probability, adoption_score, ratio, route_for, send_probability
from article5.network import Edge, Network, diagnostics, generate_network
from tests.audit_exports import read, close

PROJECT = Path(__file__).resolve().parent.parent
OUTPUT = PROJECT / 'outputs' / 'verification'
REFERENCE = PROJECT / 'tests' / 'reference_netlogo'


def fixture(edges, *, seeds=(0,), needs=None, fits=None, **changes):
    c = replace(Config(), population=8, communities=2, community_size=4, expected_degree=2,
                horizon=4, min_active_giant=0, seeds_per_community=1, seeded_communities=(0,), **changes)
    edges_dict = {}
    for values in edges:
        i, j, strength, kind, *attributes = values
        trust, coop, commitment = attributes or (0.8, 1, 1)
        edges_dict[i, j] = Edge(i, j, strength, trust, coop, commitment, strength >= c.inactive_cut, i // 4 != j // 4, kind)
    network = Network(tuple(i // 4 for i in range(8)), tuple(needs or [1] * 8), tuple(fits or [1] * 8), seeds, edges_dict, 'fixture')
    m = Model(c, network)
    # U=0 succeeds for strictly positive probabilities; never for probability zero.
    m.tape.dynamic = array('d', [0]) * len(m.tape.dynamic)
    m.tape.follow = array('d', [0]) * len(m.tape.follow)
    return m


def accounting(test, model):
    test.assertEqual(sum(a.adopted for a in model.agents), len(model.network.seeds) + model.new_total)
    test.assertEqual(model.sent_total, sum(a.exposures for a in model.agents))
    test.assertEqual(model.sent_total, model.repeated_total + sum(a.exposures > 0 and not a.seed for a in model.agents))
    test.assertEqual(model.attempted_total, sum(a.attempts for a in model.agents))
    test.assertTrue(all(0 <= a.energy <= model.config.initial_energy and a.attempts <= model.config.initial_energy for a in model.agents))
    test.assertTrue(all(count <= 2 for count in model.history.values()))
    person_month, pairs_month = Counter(), Counter()
    for e in model.events:
        person_month[e['sender'], e['month']] += 1
        pairs_month[e['sender'], e['receiver'], e['month']] += 1
        test.assertEqual(e['energy_before'] - e['energy_after'], 1)
        if e['adoption']:
            test.assertTrue(e['sent'] and e['eligible_to_adopt'])
    test.assertTrue(all(v <= model.config.monthly_capacity for v in person_month.values()))
    test.assertTrue(all(v <= 1 for v in pairs_month.values()))


class Verification(unittest.TestCase):
    def test_V01_network(self):
        m = Model()
        self.assertEqual(len(m.agents), 600)
        self.assertEqual(Counter(a.community for a in m.agents), {i: 100 for i in range(6)})
        self.assertTrue(all(i < j for i, j in m.network.edges))
        self.assertEqual(len(m.network.seeds), 12)
        self.assertGreaterEqual(diagnostics(m.network, True)['giant_component'], 570)
        self.assertTrue(all(0 <= x <= 1 for e in m.network.edges.values() for x in (e.strength, e.trust, e.cooperation, e.commitment)))
        with self.assertRaises(RuntimeError):
            generate_network(replace(Config(), expected_degree=0, max_candidates=2))

    def test_V02_strength_and_bridges(self):
        m = fixture([(0, 1, 0.1, 'weak'), (0, 4, 0.95, 'strong'), (0, 3, 0.01, 'inactive')])
        self.assertFalse(m.network.edge(0, 1).bridge)
        self.assertTrue(m.network.edge(0, 4).bridge)
        self.assertNotIn(3, m.structural_targets(0, {0}))
        n = generate_network(Config())
        active = [e for e in n.edges.values() if e.active]
        self.assertEqual(sum(e.tie_class == 'weak' for e in active), math.floor(0.3 * len(active)))
        self.assertEqual(sum(e.tie_class == 'strong' for e in active), math.floor(0.3 * len(active)))
        self.assertLessEqual(max(e.strength for e in active if e.tie_class == 'weak'), min(e.strength for e in active if e.tie_class == 'strong'))

    def test_V03_routes_and_fallbacks(self):
        m = fixture([(0, 1, 0.9, 'strong'), (0, 2, 0.2, 'weak'), (0, 4, 0.2, 'weak'), (0, 5, 0.9, 'strong')])
        for pool, route, expected in [([1, 2, 4, 5], 'A', (1, 0)), ([1, 2, 4, 5], 'B', (4, 0)),
                                      ([1, 2, 5], 'B', (2, 1)), ([1, 5], 'B', (5, 2)), ([1], 'B', (1, 3)), ([2], 'A', (2, 1))]:
            self.assertEqual(m.choose_target(0, pool, route, 0), expected)
        self.assertEqual(m.choose_target(0, [], 'B', 0), (None, None))
        for strategy, month, u, expected in [('C', 1, .499, 'A'), ('C', 1, .5, 'B'),
                                            ('D', 12, .799, 'A'), ('D', 12, .8, 'B'),
                                            ('D', 13, .299, 'A'), ('D', 13, .3, 'B')]:
            self.assertEqual(route_for(strategy, month, u), expected)

    def test_V04_uniform_choice(self):
        m = fixture([(0, 1, .9, 'strong'), (0, 2, .2, 'weak'), (0, 4, .2, 'weak'), (0, 5, .9, 'strong')])
        rng = random.Random(731)
        counts = Counter(m.choose_target(0, [1, 2, 4, 5], 'E', rng.random())[0] for _ in range(20000))
        self.assertTrue(all(abs(counts[i] - 5000) <= 300 for i in (1, 2, 4, 5)), counts)
        self.observed = f'20 000 draws; counts={dict(sorted(counts.items()))}; 5000 +/-300'

    def test_V05_paired_resources(self):
        signature = None
        for strategy in 'ABCDE':
            m = Model(replace(Config(), strategy=strategy))
            current = (m.network.signature(), m.tape.signature())
            if signature is None:
                signature = current
            self.assertEqual(current, signature)
            m.run()
            accounting(self, m)
            self.assertEqual(len(m.periods), 61)
            self.assertEqual(len(m.agent_periods), 36600)
            export_run(m, OUTPUT, f'smoke_{strategy}')
        self.observed = 'A-E: identical initial network/attributes/seeds and random tapes; resource checks passed'

    def test_V06_commitment_and_energy(self):
        needs = [1, 0] + [1] * 6
        m = fixture([(0, 1, .8, 'strong', .8, 1, 0)], needs=needs).run()
        self.assertEqual((m.attempted_total, m.agents[0].energy, m.extinction_month), (1, 3, 1))
        m = fixture([(0, 1, .8, 'strong')], needs=needs).run()
        self.assertEqual([e['month'] for e in m.events], [1, 2])
        m = fixture([(0, 1, .8, 'strong', .8, 0, 1)], needs=needs, c0=0).run()
        self.assertEqual((m.sent_total, m.attempted_total, m.agents[0].energy), (0, 2, 2))

    def test_V07_probability_bounds(self):
        c = Config()
        for n in (0, .5, 1):
            for f in (0, .5, 1):
                self.assertTrue(0 <= send_probability(n, f, c) <= 1)
                for t in (0, .5, 1):
                    for x in (0, 1, 2, 100):
                        p = adoption_probability(n, f, t, x, c)
                        self.assertTrue(0 <= p <= 1)
                        if n == 0 or f == 0:
                            self.assertEqual(p, 0)
        self.assertEqual(adoption_probability(1, 1, 1, 0, replace(c, a0=-10000)), 0)
        self.assertEqual(adoption_probability(1, 1, 1, 0, replace(c, a0=10000)), 1)
        self.assertGreater(send_probability(1, 1, c), send_probability(1, 0, c))

    def test_V08_trust_risk(self):
        for risk in (.2, .5, .8):
            c = replace(Config(), trust_weight=0, risk=risk)
            self.assertEqual(adoption_probability(.7, .8, 0, 0, c), adoption_probability(.7, .8, 1, 0, c))
            c = replace(c, trust_weight=1)
            self.assertAlmostEqual(adoption_score(1, 0, c) - adoption_score(0, 0, c), c.bT + c.gR * risk)
        self.assertLessEqual(adoption_probability(1, 1, .5, 0, replace(Config(), risk=.8)), adoption_probability(1, 1, .5, 0, replace(Config(), risk=.2)))

    def test_V09_no_bridges(self):
        m = Model(replace(Config(), mu=0, min_active_giant=0)).run()
        self.assertFalse(any(e.bridge for e in m.network.edges.values()))
        self.assertTrue(all(a.community in (0, 1) for a in m.agents if a.adopted))
        accounting(self, m)
        export_run(m, OUTPUT, 'no_bridges')

    def test_V10_functional_bridge(self):
        m = fixture([(0, 1, .9, 'strong'), (1, 4, .2, 'weak'), (4, 5, .9, 'strong')], monthly_capacity=1).run()
        self.assertEqual(m.agents[4].adoption_month, 2)
        parent = m.events[m.agents[4].parent_event]
        self.assertTrue(parent['bridge'])
        self.assertEqual(parent['sender_community'], 0)

    def test_V11_exposures_and_unique_adoption(self):
        edges = [(0, 2, .8, 'strong'), (1, 2, .8, 'strong')]
        m = fixture(edges, seeds=(0, 1), needs=[1, 1, 0, 1, 1, 1, 1, 1])
        m.step()
        self.assertEqual((m.sent_total, m.repeated_total, sum(a.exposures > 0 for a in m.agents)), (2, 1, 1))
        self.assertEqual([e['prior_exposures'] for e in m.events], [0, 1])
        m = fixture(edges, seeds=(0, 1))
        m.step()
        self.assertEqual((m.sent_total, m.new_total, m.eligible_sent_total), (2, 1, 1))
        self.assertIsNone(m.events[-1]['p_adopt'])
        accounting(self, m)

    def test_V12_activation_delay(self):
        edges = [(0, 1, .8, 'strong'), (1, 2, .8, 'strong')]
        m = fixture(edges, quality=.1)
        m.step()
        self.assertTrue(m.agents[1].adopted)
        self.assertEqual(m.agents[1].energy, 0)
        self.assertEqual(m.state_name(m.agents[1], m.viable_ids()), 'customer')
        m = fixture(edges, quality=1, monthly_capacity=1)
        m.step()
        self.assertTrue(m.agents[1].adopted)
        self.assertFalse(m.agents[2].adopted)
        m.step()
        self.assertEqual(m.agents[2].adoption_month, 2)

    def test_V13_ancestry(self):
        m = Model().run()
        for a in m.agents:
            if a.adopted and not a.seed:
                e, parent = m.events[a.parent_event], m.agents[a.parent_agent]
                self.assertTrue(e['adoption'])
                self.assertEqual(e['receiver'], a.agent_id)
                self.assertEqual(a.root_id, parent.root_id)
                self.assertEqual(a.generation, parent.generation + 1)
                self.assertLess(parent.adoption_month, a.adoption_month)
        self.assertEqual(len({e['receiver'] for e in m.events if e['adoption']}), m.new_total)

    def test_V14_exact_reproduction(self):
        c = replace(Config(), strategy='C')
        first = Model(c).run()
        random.seed(123)  # El generador global no debe cambiar el modelo.
        for _ in range(100):
            random.random()
        second = Model(c).run()
        self.assertEqual(first.network.signature(), second.network.signature())
        self.assertEqual(first.tape.signature(), second.tape.signature())
        for name in ('events', 'periods', 'agent_periods', 'cascade_activity'):
            self.assertEqual(getattr(first, name), getattr(second, name))
        self.assertEqual(first.summary(), second.summary())
        self.assertEqual(first.cascades(), second.cascades())

    def test_V15_extinction(self):
        m = Model(replace(Config(), initial_energy=0)).run()
        self.assertEqual((m.events, m.new_total, m.extinction_month), ([], 0, 0))
        self.assertIsNone(ratio(0, 0))
        m = fixture([(0, 1, .8, 'strong', .8, 1, .5)], needs=[1, 0, 1, 1, 1, 1, 1, 1])
        m.step()
        m.tape.follow[len(m.tape.pairs) + m.tape.pair_index[0, 1]] = .9
        m.step()
        self.assertEqual(m.period_attempts, 0)
        self.assertIsNone(m.extinction_month)
        self.assertTrue(m.viable_ids())
        m.tape.follow[2 * len(m.tape.pairs) + m.tape.pair_index[0, 1]] = .1
        m.step()
        self.assertEqual(m.period_attempts, 1)

    def test_V16_balances_and_extremes(self):
        m = Model().run()
        accounting(self, m)
        self.assertEqual(sum(row['size'] for row in m.cascades()), m.new_total)
        edges = [(0, 1, .8, 'strong')]
        self.assertEqual(fixture(edges, needs=[0] * 8).run().new_total, 0)
        self.assertEqual(fixture(edges, seeds=tuple(range(8))).run().events, [])
        m = fixture(edges, initial_energy=100, needs=[1, 0, 1, 1, 1, 1, 1, 1]).run()
        self.assertEqual(m.attempted_total, 2)
        self.assertTrue(any(e.bridge for e in generate_network(replace(Config(), mu=.4)).edges.values()))

    def test_M01_conditional_netlogo_replay(self):
        """Se fijan contactos y decisiones observadas; se contrastan ecuaciones y transiciones."""
        network = Network.from_records(read(REFERENCE / 'nodes.csv'), read(REFERENCE / 'edges.csv'), 'reference_netlogo')
        m = Model(Config(), network)
        by_month = defaultdict(list)
        for e in read(REFERENCE / 'events.csv'):
            by_month[e['month']].append(e)
        for month in range(1, 61):
            m.period_attempts = m.period_sends = m.period_adoptions = 0
            planned = {}
            for e in sorted(by_month[month], key=lambda r: (r['sender'], r['slot'])):
                # Cualquier U de este intervalo reproduce la decisión registrada.
                usend = 0 if e['sent'] else (1 + e['p_send']) / 2
                uadopt = 0 if e['adoption'] else (1 + (e['p_adopt'] or 0)) / 2
                self.assertTrue(0 <= usend < 1 and 0 <= uadopt < 1)
                planned[e['event_id']] = m.reserve_attempt(e['sender'], e['receiver'], e['slot'], e['route'],
                    e['selected_tier'], (0, 0, usend, uadopt, 0), month)
            for order, e in enumerate(by_month[month]):
                m.process_attempt(planned[e['event_id']], month, order)
                for name, value in e.items():
                    close(m.events[-1][name], value, f'NetLogo event {e["event_id"]}: {name}')
            m.month = month
            m.record_period()
        for actual, expected in zip(m.periods, read(REFERENCE / 'system_period.csv'), strict=True):
            for name, value in expected.items():
                close(actual[name], value, f'NetLogo period {actual["month"]}: {name}')
        for actual, expected in zip(m.agent_periods[-600:], read(REFERENCE / 'agent_final.csv'), strict=True):
            for name, value in expected.items():
                close(actual[name], value, f'NetLogo final agent {actual["agent_id"]}: {name}')
        for actual, expected in zip(m.cascades(), read(REFERENCE / 'cascades.csv'), strict=True):
            for name, value in expected.items():
                close(actual[name], value, f'NetLogo cascade {actual["root_id"]}: {name}')
        for name, value in read(REFERENCE / 'run_summary.csv')[0].items():
            close(m.summary()[name], value, f'NetLogo summary {name}')
        self.observed = f'{len(m.events)} recorded NetLogo events; 61 periods; 600 final states; cascades and summary match (tolerance 1e-10)'

    def test_M02_pairing_and_config(self):
        base = Model()
        for risk in (.2, .8):
            m = Model(replace(Config(), risk=risk))
            self.assertEqual(base.network.signature(), m.network.signature())
            self.assertEqual(base.tape.signature(), m.tape.signature())
        for mu in (.05, .4):
            network = generate_network(replace(Config(), mu=mu))
            self.assertEqual(base.network.needs, network.needs)
            self.assertEqual(base.network.fits, network.fits)
            self.assertEqual(base.network.seeds, network.seeds)
        self.assertNotEqual(base.network.signature(), generate_network(replace(Config(), repetition=2)).signature())
        self.assertEqual(Config.load(PROJECT / 'config/base_v0.2.json'), Config())
        for kwargs in ({'mu': 2}, {'population': 601}, {'monthly_capacity': 1.5}, {'risk': float('nan')},
                       {'max_candidates': 101}, {'strategy': 'F'}, {'seeded_communities': (0, 0)}):
            with self.assertRaises((ValueError, TypeError)):
                replace(Config(), **kwargs).validate()

    def test_M03_empty_exports(self):
        m = fixture([], seeds=())
        m.run()
        with tempfile.TemporaryDirectory() as directory:
            manifest_path = export_run(m, directory, 'empty')
            manifest = json.loads(manifest_path.read_text())
            self.assertEqual(read(Path(directory) / 'empty_events.csv'), [])
            self.assertEqual(read(Path(directory) / 'empty_cascades.csv'), [])
            self.assertEqual(read(Path(directory) / 'empty_network_candidates.csv'), [])
            summary = read(Path(directory) / 'empty_run_summary.csv')[0]
            self.assertIsNone(summary['conversion'])
            self.assertIsNone(summary['adoption_at_12'])
            for name, digest in manifest['output_sha256'].items():
                self.assertEqual(sha256(Path(directory) / name), digest)

    def test_M04_network_diagnostics(self):
        n = Network.from_records(read(REFERENCE / 'nodes.csv'), read(REFERENCE / 'edges.csv'))
        for expected in read(REFERENCE / 'network_diagnostics.csv'):
            actual = diagnostics(n, expected['active_only'])
            for name in ('edges', 'mean_degree', 'density', 'components', 'giant_component', 'bridges', 'modularity', 'mean_clustering'):
                close(actual[name], expected[name], f'NetLogo network metric {name}')
        m = fixture([(0, 1, .8, 'strong'), (0, 2, .8, 'strong'), (1, 2, .8, 'strong')])
        d = diagnostics(m.network, True)
        self.assertEqual((d['edges'], d['components'], d['giant_component']), (3, 6, 3))
        self.assertEqual(d['mean_clustering'], 3 / 8)
        self.assertAlmostEqual(d['modularity'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
