# Article 5 — Informe de migración y verificación Python v0.2

**La migración a Python está implementada y verificada: 20/20 pruebas y 7/7 auditorías aprobadas.** Las siete celdas de código del cuaderno se ejecutaron localmente y la entrada por terminal también funcionó. No se realizó calibración con datos reales.

## Alcance y correspondencia

Se conservaron las reglas y los parámetros del modelo mínimo: 600 consumidores, seis comunidades, 12 promotores iniciales, cinco estrategias, 60 períodos, energía cuatro y capacidad de dos intentos por promotor y período. El motor y sus pruebas requieren únicamente la biblioteca estándar de Python. La figura del cuaderno utiliza Matplotlib.

Python v0.2 pasa a ser la plataforma principal. NetLogo v0.1 y sus resultados se conservan como referencia histórica. Las secuencias aleatorias cambian entre plataformas: una misma semilla numérica no identifica la misma realización. Los datos v0.1 y v0.2 no deben combinarse como repeticiones de una misma versión.

## Ejecución final

- Inicio UTC: 2026-09-26T02:32:34.654582+00:00.
- Hora de Colombia: 2026-09-25T21:32:34.654582-05:00.
- Entorno: Python 3.12.14; Linux x86_64.
- Duración de pruebas y auditorías: 15.719 segundos en este entorno.
- Comando: `python run_verification.py`.
- Configuración ejecutable: `config/base_v0.2.json`; semilla base 20260925.
- Condición técnica A–E: repetición 1, riesgo 0.50 y mu 0.20.
- Piloto de 25 corridas y experimento principal: no ejecutados.

## Pruebas del modelo y de migración

| ID | Aspecto comprobado | Resultado |
|---|---|---|
| V01 | Red, atributos, comunidades y conectividad; rechazo estructural | PASS |
| V02 | Clases por fuerza y puentes como propiedades diferentes | PASS |
| V03 | Prioridades, sustituciones y transición de D del mes 12 al 13 | PASS |
| V04 | Selección uniforme: 20 000 sorteos con tolerancia prefijada | PASS |
| V05 | Recursos y condiciones iniciales/sorteos compartidos A–E | PASS |
| V06 | Compromiso K=0/K=1; costo del intento sin envío | PASS |
| V07 | Probabilidades acotadas y casos extremos numéricos | PASS |
| V08 | Confianza, riesgo y control w=0 | PASS |
| V09 | Control sin puentes: difusión confinada a comunidades sembradas | PASS |
| V10 | Entrada en una comunidad nueva mediante un puente funcional | PASS |
| V11 | Exposición repetida, alcance único y adopción única | PASS |
| V12 | Satisfacción mínima y activación diferida | PASS |
| V13 | Evento padre, raíz, profundidad y temporalidad | PASS |
| V14 | Reproducción exacta dentro de Python | PASS |
| V15 | Extinción, energía cero y silencio temporal | PASS |
| V16 | Balances y condiciones extremas | PASS |
| M01 | Reproducción condicionada de eventos registrados en NetLogo | PASS |
| M02 | Emparejamiento entre riesgos y mu; configuración JSON | PASS |
| M03 | Exportaciones sin eventos y huellas de integridad | PASS |
| M04 | Diagnósticos contrastados con NetLogo y red conocida | PASS |

V04 obtuvo 4936, 4996, 4998 y 5070 selecciones para cuatro candidatos, frente a 5000 esperadas por candidato y tolerancia prefijada de ±300. V14 exigió igualdad exacta de condiciones iniciales, sorteos, eventos, series, estados individuales, cascadas y resumen entre dos ejecuciones Python iguales.

**M01 comparó 410 eventos, 61 períodos, 600 estados finales, 12 cascadas y el resumen con los datos NetLogo de referencia.** Los valores coincidieron dentro de una tolerancia de 1e-10 para punto flotante. Esta es una reproducción condicionada: se fijaron los contactos, el orden y las decisiones observadas. Comprueba probabilidades, transiciones y contabilidad; no afirma equivalencia de los generadores aleatorios ni de trayectorias espontáneas entre lenguajes. Las reglas de selección se comprobaron separadamente con V03, V04 y V06.

M04 contrastó los diagnósticos de la misma red exportada por NetLogo. También verificó un triángulo con cinco nodos aislados: tres enlaces, seis componentes, componente gigante de tres y agrupamiento medio de 3/8.

## Auditoría independiente de exportaciones

El auditor reconstruyó los estados desde los eventos sin llamar a funciones de la dinámica. Contrastó probabilidades, elegibilidad, energía, exposiciones, adopción, ascendencia, indicadores por período, estados individuales, cascadas y resúmenes. Las seis corridas principales contienen 366 registros del sistema y 219 600 registros agente–período.

| Auditoría | Resultado |
|---|---|
| smoke_A | PASS |
| smoke_B | PASS |
| smoke_C | PASS |
| smoke_D | PASS |
| smoke_E | PASS |
| no_bridges | PASS |
| paired_initial_conditions_and_tapes | PASS |

La séptima auditoría confirmó igualdad de consumidores, enlaces, atributos, promotores iniciales y tablas de sorteos entre A–E. Los manifiestos conservan configuración, semillas, versiones y huellas SHA-256 del código y los datos. Se comprobó la integridad de los archivos finales antes de empaquetarlos.

## Registro de corridas técnicas

Estos valores documentan la ejecución del programa y corresponden a una única repetición por estrategia. No son una comparación experimental suficiente para establecer superioridad.

| Corrida | Intentos | Envíos | Nuevas adopciones | Adopción total | Alcance único | Extinción |
|---|---:|---:|---:|---:|---:|---:|
| smoke_A | 88 | 55 | 15 | 27 | 43 | 7 |
| smoke_B | 92 | 40 | 15 | 27 | 39 | 8 |
| smoke_C | 88 | 44 | 17 | 29 | 41 | 9 |
| smoke_D | 100 | 58 | 18 | 30 | 47 | 11 |
| smoke_E | 112 | 58 | 23 | 35 | 53 | 9 |
| no_bridges | 249 | 158 | 59 | 71 | 99 | 14 |

En esta repetición, las cinco estrategias base se extinguieron antes del mes 12. Por tanto, D no tuvo oportunidad de actuar con su segunda fase en esta realización. La transición está verificada en una prueba controlada; su oportunidad de actuación debe examinarse entre repeticiones durante el piloto. No se cambió retrospectivamente la fecha de transición ni la energía para favorecer su resultado.

El control sin puentes usa mu=0 y omite la exigencia de una componente gigante de 570 agentes, tal como prevé la especificación para esa prueba. No produjo adopciones fuera de las comunidades inicialmente sembradas.

## Cuaderno y ejecución por terminal

- Siete celdas de código ejecutadas en orden, sin errores, mediante Python local; figura inspeccionada y resultados guardados en el cuaderno.
- Demostración A, repetición 1: coincidió con la corrida técnica correspondiente.
- Entrada `run_model.py` con B, repetición 1: ejecución correcta y coincidencia con el resumen técnico.
- La celda opcional que repite toda la verificación queda desactivada por defecto.
- No se probó una sesión autenticada de Colab ni Windows/macOS. El cuaderno incluye la carga del ZIP para Colab; el entorno comprobado está identificado arriba.

## Incidencias y límites

El auditor detectó un archivo CSV incompleto entre ejecuciones intermedias. Se reforzó la exportación para publicar el archivo mediante sustitución atómica después de cerrar su escritura, y se repitió el conjunto completo. El paquete contiene las evidencias de la ejecución final satisfactoria.

Las pruebas verifican coherencia computacional y fidelidad de la implementación a las reglas elegidas. No demuestran correspondencia con un mercado real ni convierten los parámetros en estimaciones empíricas. Las series mensuales no son repeticiones independientes.

## Entrega y siguiente etapa

El paquete de código incluye el modelo, los datos de referencia necesarios para la prueba de migración, la configuración, las pruebas, la especificación v0.2, las decisiones y el cuaderno. Las evidencias se entregan en un ZIP separado. Al descomprimir ambos en el mismo lugar se reconstruye la estructura del proyecto.

El siguiente paso sigue siendo el piloto de **cinco estrategias por cinco repeticiones**, usando exclusivamente Python v0.2. Se revisarán variación, sustituciones, duración y posibilidad de actuación de D después del mes 12. El estudiante podrá utilizar el cuaderno para comprender los indicadores antes de iniciar ese análisis.
