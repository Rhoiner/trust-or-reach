# Migración NetLogo → Python — v0.2

Fecha de la decisión: 25 de septiembre de 2026, hora de Colombia. El usuario autorizó utilizar Python como plataforma principal después de completar el modelo NetLogo v0.1. La versión anterior y sus evidencias permanecen disponibles como referencia histórica.

## Correspondencia de implementación

| NetLogo v0.1 | Python v0.2 | Regla conservada |
|---|---|---|
| `setup-defaults` | `Config` y `config/base_v0.2.json` | Parámetros base y controles experimentales |
| `setup`, `classify-ties` | `generate_network`, `classify` | Red de bloques, atributos separados y clasificación global |
| `build-random-tapes` | `RandomTape` | Sorteos previos, orden fijo, comunes entre estrategias |
| `structural-targets`, `eligible-targets` | Métodos equivalentes de `Model` | Vecindad activa, adopción inicial del mes, tope de pareja y compromiso |
| `route-for`, `choose-target` | `route_for`, `choose_target` | Prioridades, selección uniforme y sustituciones A–E |
| `go`, `process-attempt` | `step`, `plan_period`, `process_attempt` | Reserva simultánea, orden aleatorio y activación diferida |
| `record-period`, `export-results` | `record_period`, `export_run` | Estados, balances, cascadas, CSV y metadatos |
| BehaviorSpace y `verify-all` | `run_verification.py` y `unittest` | Pruebas automatizadas y resultados legibles |

## Qué cambia

La configuración JSON ahora es una entrada ejecutable y se valida antes de simular. El modelo no requiere NetLogo, Java ni un framework de agentes. Cada consumidor se representa con una estructura `Agent`, cada enlace con `Edge` y las decisiones con funciones pequeñas. El cuaderno se mantiene separado del motor para que los resultados también puedan reproducirse desde una terminal.

La versión utiliza `random.Random` con generadores separados para topología, atributos relacionales, consumidores y semillas iniciales. Fuerza conserva las distribuciones Beta previstas, obtenidas mediante el cociente de dos variables Gamma. La dinámica mantiene la misma secuencia conceptual de sorteos: período, consumidor, slot y función; después, seguimiento por período y pareja dirigida activa. El código de eventos no consume sorteos adicionales.

Las secuencias numéricas son propias de Python. La misma semilla no se interpreta como la misma realización NetLogo. Dentro de Python, A–E comparten exactamente red, consumidores, promotores y tablas de sorteos; los cambios de riesgo conservan esa base. Los cambios de mu conservan los consumidores y promotores, pero generan otra red.

La tabla de diagnósticos añade la proporción de puentes de forma explícita. Si una ejecución termina antes de 12 períodos por configurar un horizonte menor, `adoption_at_12` es `NA`; en la condición prevista de 60 períodos conserva la misma definición. Los CSV se publican solo después de completarse y cerrar su escritura, mediante sustitución atómica del archivo.

## Pruebas de migración

**M01 — Reproducción condicionada de eventos NetLogo.** Se reutilizan consumidores, enlaces, contactos, orden y decisiones de envío/adopción de una corrida NetLogo conservada. Los sorteos utilizados para reproducir cada decisión se fijan dentro del intervalo compatible con el resultado observado. Python calcula de nuevo las probabilidades, las transiciones y las métricas. Se contrastan 410 eventos, 61 períodos, 600 estados finales, 12 cascadas y el resumen. La tolerancia para números de punto flotante es 1e-10. Los datos de referencia incluyen su procedencia y las huellas de los archivos originales.

Esta prueba comprueba la ejecución de eventos bajo entradas controladas. No verifica por sí sola la selección aleatoria de contactos, la distribución de trayectorias entre lenguajes ni equivalencia entre generadores. Las rutas, los seguimientos y la selección uniforme se verifican por separado mediante V03, V04 y V06.

**M02 — Emparejamiento y configuración.** Compara redes y sorteos entre riesgos; consumidores y promotores entre niveles de mu; y cambios entre repeticiones. Comprueba que el JSON reproduce los valores base y rechaza configuraciones inválidas.

**M03 — Exportaciones vacías.** Verifica que una red sin actividad conserva cabeceras, escribe `NA` para tasas indefinidas y produce archivos con huellas válidas.

**M04 — Diagnósticos de red.** Contrasta tamaño, grado, densidad, componentes, puentes, modularidad y agrupamiento con la red NetLogo de referencia. También utiliza un triángulo con cinco nodos aislados, cuyos indicadores son conocidos.

## Alcance de la evidencia

La migración vuelve a ejecutar V01–V16 y las auditorías de CSV. Las corridas técnicas no se combinan con las de NetLogo para aumentar el número de repeticiones. El piloto y los experimentos posteriores utilizarán únicamente una versión Python fijada y documentada.

No cambian satisfacción, energía, cooperación, compromiso, confianza, ecuación de adopción, horizonte ni prioridades de las estrategias. No se introduce aprendizaje, renovación de energía o calibración empírica. Esos cambios requerirían una decisión conceptual posterior.

Durante el desarrollo, el auditor detectó un CSV incompleto entre ejecuciones intermedias. Se reforzó la publicación atómica de archivos y se volvió a ejecutar el conjunto completo con comprobación de huellas. Solo la ejecución final satisfactoria se entrega como evidencia de v0.2.
