# Article 5 — Python v0.2

Modelo académico basado en agentes para estudiar conversión, alcance y redundancia de recomendaciones. **Python es ahora la plataforma principal.** La versión NetLogo v0.1 queda como referencia histórica. No se utiliza calibración con datos reales.

Se conservan 600 consumidores, seis comunidades, cinco estrategias A–E, 60 períodos y los parámetros de la especificación mínima. La migración cambia la implementación y el generador de sorteos; no redefine las hipótesis ni ajusta parámetros para favorecer una estrategia.

## Inicio rápido

Requisito: **Python 3.10 o posterior**. El motor, las pruebas, los diagnósticos y la exportación usan únicamente la biblioteca estándar. Descomprimir todo el ZIP y abrir una terminal en `Article_5_Python_v0.2`.

Para repetir las pruebas y las auditorías:

```bash
python run_verification.py
```

En Windows se puede usar `py` en lugar de `python`. No usar la opción `-O`, porque desactiva las comprobaciones del auditor. La ejecución correcta termina con `status: PASS`, 20 pruebas y 7 auditorías. Si hay un fallo, el proceso termina con código distinto de cero; revisar `outputs/verification/verification.log`.

Para ejecutar una corrida:

```bash
python run_model.py --strategy A --repetition 1
```

Los CSV y el manifiesto se guardan en `outputs/manual`. Una nueva ejecución con el mismo prefijo reemplaza esos archivos; usar `--prefix nombre_distinto` o `--output otra_carpeta` para conservarla por separado. Para modificar supuestos, copiar `config/base_v0.2.json` y pasar la copia con `--config ruta/a/config.json`. **El JSON sí se carga en Python.** Las opciones de estrategia y repetición prevalecen sobre el JSON si se indican en el comando.

## Cuaderno para el estudiante

Abrir `notebooks/Article_5_Python_v0.2.ipynb` en Jupyter o subirlo a Google Colab. En Colab, la primera celda de código pedirá el ZIP de código si todavía no está disponible; seleccionar `Article_5_Python_v0.2.zip`. No necesita NetLogo ni Java.

Ejecutar las celdas de arriba hacia abajo. El cuaderno explica los parámetros, ejecuta una corrida, muestra los indicadores y la trayectoria y exporta sus resultados. Incluye preguntas de interpretación y una celda opcional para todas las pruebas, desactivada por defecto. La figura requiere Matplotlib, habitualmente disponible en Colab; en un entorno local puede instalarse con `python -m pip install matplotlib`. La simulación y sus pruebas funcionan sin esa dependencia.

Para volver a usar los valores base, cargar otra vez el JSON. Las modificaciones del cuaderno se hacen con `dataclasses.replace`, creando una nueva configuración. Para comparar A–E, conservar repetición, riesgo, mu y los demás parámetros. El número de intentos total puede cambiar cuando una estrategia produce más promotores; lo equivalente es la capacidad individual y el presupuesto inicial.

## Organización

| Archivo o carpeta | Función |
|---|---|
| `article5/config.py` | Configuración y validación de parámetros |
| `article5/network.py` | Generación de red, atributos, clases y diagnósticos |
| `article5/model.py` | Sorteos precomputados, agentes, decisiones, estados y métricas |
| `article5/io.py` | Exportación CSV y manifiestos con huellas de integridad |
| `run_model.py` | Ejecuta una corrida desde el JSON |
| `run_verification.py` | Ejecuta las 20 pruebas y las 7 auditorías |
| `tests/test_model.py` | V01–V16 y pruebas de migración M01–M04 |
| `tests/audit_exports.py` | Auditor independiente de los CSV de las condiciones técnicas de 600 agentes y 60 períodos |
| `tests/reference_netlogo/` | Datos de referencia de NetLogo para verificar la migración |
| `notebooks/` | Cuaderno explicativo ejecutable |
| `docs/` | Especificación actualizada, decisiones e informe |
| `outputs/verification/` | Evidencias de las pruebas; también disponibles en un ZIP separado |

## Qué se verificó

- Las 16 condiciones previstas: red, clases y puentes, rutas, recursos, probabilidades, compromiso, exposiciones, adopción, activación, ascendencia, reproducción y extinción.
- Cuatro comprobaciones adicionales: reproducción condicionada de eventos NetLogo; emparejamiento y JSON; exportaciones vacías; diagnósticos de red contrastados con NetLogo y una red conocida.
- Seis auditorías de corridas completas —A–E y un control sin puentes— y una comprobación de igualdad de condiciones iniciales y tablas de sorteos entre A–E.

El entorno exacto y la fecha de la ejecución se registran en `verification_summary.json`. La ejecución automatizada se comprobó en Linux; el cuaderno se ejecutó localmente. No se ha probado una sesión autenticada de Colab ni un equipo Windows en esta entrega.

## Límites de comparación entre plataformas

Python y NetLogo generan secuencias distintas aunque se use la misma semilla numérica. Por eso los resultados aleatorios de v0.1 y v0.2 no son réplicas emparejadas y no deben mezclarse en una misma muestra. La prueba de migración fija los contactos y las decisiones del registro NetLogo para contrastar las ecuaciones, transiciones y balances; no afirma que ambos generadores produzcan las mismas trayectorias espontáneas.

La igualdad exacta se verifica dentro de la versión Python, con los mismos parámetros y entorno. Conservar la versión de Python y los manifiestos para reproducir resultados; una actualización del entorno debe verificarse antes de usarla para nuevas comparaciones.

## Estado del proyecto

El piloto de **25 corridas —cinco estrategias por cinco repeticiones— sigue pendiente**. Las corridas incluidas son de verificación, no evidencia suficiente para ordenar estrategias. La próxima etapa revisará duración, variación, sustituciones y oportunidad de actuación de D después del mes 12.

Carpeta del proyecto: <https://drive.google.com/drive/folders/1rNe2pfCmXN30877GPZY1-D9IWJp4aJnp>.
El código se organiza en `02_Codigo`, la documentación del diseño en `01_Diseno_del_modelo` y las pruebas en `03_Verificacion`. El manuscrito sigue siendo **Article 5 - NM - 2 - RD**.
