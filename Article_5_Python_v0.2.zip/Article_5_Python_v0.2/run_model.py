#!/usr/bin/env python3
"""Ejecuta una corrida. Ejemplo: python run_model.py --strategy B --repetition 1"""
import argparse
from dataclasses import replace
import json
from pathlib import Path

from article5 import Config, Model
from article5.io import export_run


def main():
    project = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=project / 'config/base_v0.2.json')
    parser.add_argument('--strategy', choices=list('ABCDE'))
    parser.add_argument('--repetition', type=int)
    parser.add_argument('--output', type=Path, default=project / 'outputs/manual')
    parser.add_argument('--prefix', default=None)
    args = parser.parse_args()
    config = Config.load(args.config)
    changes = {name: getattr(args, name) for name in ('strategy', 'repetition') if getattr(args, name) is not None}
    config = replace(config, experiment_id='manual_python', **changes).validate()
    model = Model(config).run()
    prefix = args.prefix or model.metadata()['run_id']
    manifest = export_run(model, args.output, prefix, purpose='manual_exploration')
    print(json.dumps({'summary': model.summary(), 'manifest': str(manifest)}, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
