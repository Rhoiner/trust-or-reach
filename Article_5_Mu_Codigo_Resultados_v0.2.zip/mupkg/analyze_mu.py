#!/usr/bin/env python3
"""mu 0.05, 0.20 y 0.40 (riesgo 0.50): análisis emparejado de 100 bloques de 15 celdas."""
import itertools, json, sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
from article5.io import write_csv,sha256
from tests.audit_exports import read
from run_risk import save_json
from analyze_risk import stats,interval,nondominated,contrast_row,STRATEGIES,LABELS,METRICS,PAIR_METRICS
T=ROOT/'outputs/tables';F=ROOT/'outputs/figures'
MUS=[.05,.2,.4]
METRICS=METRICS+['attempts_bridge']

def main():
    design=json.loads((ROOT/'design/mu_design.json').read_text())
    comp=json.loads((ROOT/'outputs/checks/mu_completion.json').read_text())
    assert comp['status']=='PASS' and comp['analysis_runs']==1500
    data=read(T/'run_summary_1500_mu.csv')
    by={(r['repetition_id'],r['mu'],r['strategy']):r for r in data}
    assert len(data)==len(by)==1500
    rng=np.random.default_rng(design['analysis_seed'])
    idx=rng.integers(0,100,size=(2000,100))
    arrays={};boots={};desc=[]
    for m in METRICS:
        a=np.array([[[np.nan if by[rep,mu,s][m] is None else float(by[rep,mu,s][m]) for s in STRATEGIES] for mu in MUS] for rep in range(1,101)])
        arrays[m]=a;boots[m]=np.nanmean(a[idx],axis=1)
        for i,mu in enumerate(MUS):
            for j,s in enumerate(STRATEGIES):
                desc.append(dict(mu=mu,strategy=s,metric=m,**stats(a[:,i,j]),**interval(boots[m][:,i,j])))
    write_csv(T/'descriptive_statistics_mu.csv',desc)
    lk={(r['mu'],r['strategy'],r['metric']):r for r in desc}
    within=[];mueff=[];inter=[]
    for i,mu in enumerate(MUS):
        for l,r in itertools.combinations(range(5),2):
            for m in PAIR_METRICS:
                d=arrays[m][:,i,r]-arrays[m][:,i,l]
                within.append(contrast_row(d,idx,dict(mu=mu,contrast=f'{STRATEGIES[r]}-{STRATEGIES[l]}',metric=m)))
    for lo,hi in [(0,1),(1,2),(0,2)]:
        for j,s in enumerate(STRATEGIES):
            for m in PAIR_METRICS+['attempts_bridge']:
                d=arrays[m][:,hi,j]-arrays[m][:,lo,j]
                mueff.append(contrast_row(d,idx,dict(strategy=s,contrast=f'{MUS[hi]}-{MUS[lo]}',metric=m)))
    for other in 'BDCE':
        j=STRATEGIES.index(other)
        for m in PAIR_METRICS:
            d=(arrays[m][:,2,0]-arrays[m][:,2,j])-(arrays[m][:,0,0]-arrays[m][:,0,j])
            inter.append(contrast_row(d,idx,dict(contrast=f'(A-{other})_mu040-(A-{other})_mu005',other_strategy=other,metric=m)))
    write_csv(T/'strategy_contrasts_within_mu.csv',within)
    write_csv(T/'paired_mu_effects.csv',mueff)
    write_csv(T/'paired_mu_strategy_interactions.csv',inter)
    surv=[]
    for mu in MUS:
        for s in STRATEGIES:
            rows=[by[rep,mu,s] for rep in range(1,101)]
            surv.append(dict(mu=mu,strategy=s,extinct_by_12=sum(r['early_extinction'] for r in rows),
                runs_with_attempts_after_12=sum(r['attempts_after_12']>0 for r in rows),
                attempts_after_12=sum(r['attempts_after_12'] for r in rows),censored_at_60=sum(not r['extinction_event'] for r in rows),
                mean_new_communities=lk[mu,s,'new_communities_adopted']['mean'],mean_fallback=lk[mu,s,'fallback_rate']['mean']))
    write_csv(T/'survival_and_communities_mu.csv',surv)
    front=[]
    for i,mu in enumerate(MUS):
        pt=np.stack([np.nanmean(arrays['coverage'][:,i],axis=0),np.nanmean(arrays['conversion'][:,i],axis=0)],axis=1)
        nd=nondominated(pt)
        bp=np.stack([boots['coverage'][:,i],boots['conversion'][:,i]],axis=2)
        bn=np.array([nondominated(p) for p in bp])
        for j,s in enumerate(STRATEGIES):
            front.append(dict(mu=mu,strategy=s,coverage_mean=float(pt[j,0]),conversion_mean=float(pt[j,1]),
                nondominated_mean=bool(nd[j]),bootstrap_nondominated_fraction=float(bn[:,j].mean())))
    write_csv(T/'finite_trust_reach_frontier_mu.csv',front)
    head=[dict(mu=mu,strategy=s,**{f'{m}_{k}':lk[mu,s,m][k] for m in ['new_adoptions','coverage','conversion','redundancy','new_communities_adopted','early_extinction'] for k in ['mean','ci95_low','ci95_high']}) for mu in MUS for s in STRATEGIES]
    write_csv(T/'headline_results_mu.csv',head)
    # diagnóstico de red desde manifiestos/tablas de corrida no requiere más; se resume fracción de puentes realizada
    plot(lk,boots,front)
    save_json(ROOT/'outputs/analysis_manifest_mu.json',dict(comparison_id='mu1500_python_v0.2',bootstrap_seed=20261001,
        scripts_sha256={'analyze_mu.py':sha256(ROOT/'analyze_mu.py')},completion_sha256=sha256(ROOT/'outputs/checks/mu_completion.json')))
    print('ANALYSIS_MU_OK')

def plot(lk,boots,front):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    F.mkdir(parents=True,exist_ok=True)
    col=dict(zip(STRATEGIES,['#0072B2','#D55E00','#009E73','#CC79A7','#666666']))
    fig,axes=plt.subplots(1,4,figsize=(15,4.4))
    for ax,m,t,pct in zip(axes,['new_adoptions','coverage','conversion','new_communities_adopted'],['Nuevas adopciones','Cobertura','Conversión','Nuevas comunidades con adopción'],[0,1,1,0]):
        for s in STRATEGIES:
            rows=[lk[mu,s,m] for mu in MUS]
            ax.errorbar(range(3),[r['mean'] for r in rows],yerr=[[r['mean']-r['ci95_low'] for r in rows],[r['ci95_high']-r['mean'] for r in rows]],marker='o',ms=4,capsize=3,color=col[s],label=f'{s} · {LABELS[s]}')
        ax.set_xticks(range(3),['0,05\n(separadas)','0,20','0,40\n(mezcladas)']);ax.set_title(t,fontweight='bold',fontsize=10);ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.18)
        if pct:ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
    h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,ncol=5,loc='lower center',frameon=False)
    fig.suptitle('Separación entre comunidades (mu), riesgo 0,50: medias e IC 95% bootstrap',fontweight='bold')
    fig.tight_layout(rect=(0,.08,1,.94))
    fig.savefig(F/'efectos_mu.png',dpi=200,facecolor='white');fig.savefig(F/'efectos_mu.pdf',facecolor='white');plt.close(fig)
if __name__=='__main__':main()
