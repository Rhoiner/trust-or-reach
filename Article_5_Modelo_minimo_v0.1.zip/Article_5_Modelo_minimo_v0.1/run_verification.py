#!/usr/bin/env python3
"""Run the fixed NetLogo verification suite and independently audit its CSV files."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

from tests.audit_outputs import audit_all, read


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--netlogo-dir', default=os.environ.get('NETLOGO_HOME'), help='NetLogo 6.4.0 installation directory')
    parser.add_argument('--timeout', type=int, default=600, help='Maximum execution time in seconds')
    args = parser.parse_args()
    if not args.netlogo_dir:
        parser.error('Provide --netlogo-dir or set NETLOGO_HOME')
    project = Path(__file__).resolve().parent
    folder = project / 'outputs' / 'verification'
    folder.mkdir(parents=True, exist_ok=True)
    installation = Path(args.netlogo_dir).expanduser().resolve()
    console = installation / ('NetLogo_Console.exe' if os.name == 'nt' else 'NetLogo_Console')
    legacy = installation / ('netlogo-headless.bat' if os.name == 'nt' else 'netlogo-headless.sh')
    if console.is_file():
        launcher = [str(console), '--headless']
    elif legacy.is_file():
        launcher = [str(legacy)]
    else:
        parser.error(f'NetLogo_Console or headless launcher not found in: {installation}')
    command = launcher + ['--model', str(project / 'model' / 'Article_5.nlogo'),
               '--setup-file', str(project / 'tests' / 'verification.xml'),
               '--experiment', 'verification', '--table', str(folder / 'behaviorspace.csv'), '--threads', '1']
    # Stale outputs must never make a failed run appear successful.
    known_names = {'behaviorspace.csv', 'netlogo_tests.csv', 'python_audit.csv', 'verification_summary.json', 'netlogo.log'}
    for path in folder.iterdir():
        generated_run = any(path.name.startswith(f'smoke_{s}_') for s in 'ABCDE') or path.name.startswith('no_bridges_')
        if path.is_file() and (path.name in known_names or (generated_run and path.suffix in ('.csv', '.json'))):
            path.unlink()
    timestamp = dt.datetime.now(dt.timezone.utc).isoformat()
    start = time.monotonic()
    print('Running NetLogo verification; see outputs/verification/netlogo.log', flush=True)
    with (folder / 'netlogo.log').open('w', encoding='utf-8') as log:
        process = subprocess.run(command, cwd=project / 'model', stdout=log, stderr=subprocess.STDOUT, timeout=args.timeout)
    if process.returncode:
        raise RuntimeError(f'NetLogo exit status {process.returncode}; inspect netlogo.log')
    tests = read(folder / 'netlogo_tests.csv')
    if len(tests) != 16 or any(t['status'] != 'PASS' for t in tests):
        raise RuntimeError('NetLogo verification failed; inspect netlogo_tests.csv')
    if 'VERIFICATION_COMPLETE failures=0' not in (folder / 'netlogo.log').read_text():
        raise RuntimeError('Missing successful completion marker')
    for prefix in [f'smoke_{s}' for s in 'ABCDE'] + ['no_bridges']:
        params = {r['parameter']: r['value'] for r in read(folder / f'{prefix}_parameters.csv')}
        if params['NetLogo'] != '6.4.0':
            raise RuntimeError(f"Reproduction requires NetLogo 6.4.0; found {params['NetLogo']}")
    audits = audit_all(folder, project, timestamp)
    result = {'status': 'PASS', 'execution_utc': timestamp, 'elapsed_seconds': round(time.monotonic() - start, 3),
              'netlogo_version': '6.4.0', 'python_version': platform.python_version(), 'platform': platform.platform(),
              'netlogo_tests_passed': len(tests), 'python_audits_passed': len(audits),
              'smoke_runs': 5, 'no_bridge_control_runs': 1, 'empirical_calibration': False,
              'pilot_executed': False, 'output_directory': 'outputs/verification'}
    (folder / 'verification_summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (AssertionError, RuntimeError, subprocess.TimeoutExpired, FileNotFoundError) as exc:
        print(f'VERIFICATION FAILED: {exc}', file=sys.stderr)
        sys.exit(1)
