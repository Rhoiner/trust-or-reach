# Article 5 — Modelo mínimo v0.1

Implementación académica en NetLogo de la especificación mínima v0.1 del proyecto **Trust or Reach?**. Incluye cinco estrategias de recomendación, pruebas deterministas y un verificador independiente de los archivos exportados. No utiliza datos reales ni calibración empírica.

## Qué contiene

| Archivo | Función |
|---|---|
| `model/Article_5.nlogo` | Modelo que se abre en NetLogo; interfaz y referencias al código |
| `model/model.nls` | Generación de red, decisiones, difusión, indicadores y exportación |
| `model/verification.nls` | Las 16 pruebas V01–V16 de la especificación |
| `tests/verification.xml` | Experimento de BehaviorSpace que ejecuta las pruebas |
| `tests/audit_outputs.py` | Reconstruye los eventos y contrasta los CSV con las ecuaciones y balances |
| `run_verification.py` | Ejecuta NetLogo, exige 16 resultados PASS, audita y genera manifiestos |
| `config/Article_5_Configuracion_base_v0.1.json` | Registro legible de parámetros y alcance |
| `docs/Implementacion_y_decisiones.md` | Reglas implementadas, correspondencia con la especificación y límites |
| `outputs/verification/` | Destino de las evidencias generadas; se crea al ejecutar el verificador |

La configuración JSON documenta el diseño; el modelo no la carga automáticamente. Los valores ejecutables están en `setup-defaults`, y cada corrida exporta los valores realmente utilizados en `*_parameters.csv` y `*_run_manifest.json`.

## Requisitos

- **NetLogo 6.4.0**. Usar esta versión para reproducir las evidencias entregadas. Las extensiones `csv`, `table` y `nw` están incluidas en su distribución.
- **Python 3.10 o posterior** para el verificador. No requiere instalar paquetes de Python.
- Descomprimir el paquete completo conservando las carpetas. No abrir solamente el archivo `.nlogo` separado de los dos `.nls`.

El entorno comprobado figura en `verification_summary.json`. La prueba automatizada se ejecutó en Linux; no se ha comprobado aquí la ejecución en Windows o macOS. La distribución de NetLogo no se incluye en este paquete. Página oficial: <https://www.netlogo.org/>. La documentación de BehaviorSpace y del lenguaje está en la carpeta `docs` de la instalación de NetLogo 6.4.0.

## Repetir todas las pruebas

Abrir una terminal en la carpeta descomprimida y ejecutar, sustituyendo la ruta por la instalación local:

```bash
python run_verification.py --netlogo-dir "/ruta/NetLogo-6.4.0-64"
```

En Windows se puede usar `py` en lugar de `python`. La carpeta indicada debe contener `NetLogo_Console` o `NetLogo_Console.exe`. El programa usa la aplicación de consola con su Java incluido; si no existe, busca el lanzador heredado `netlogo-headless.sh` o `.bat`, que necesita Java disponible en el sistema. También admite la variable de entorno `NETLOGO_HOME`.

Una ejecución correcta termina con `"status": "PASS"`, `"netlogo_tests_passed": 16` y `"python_audits_passed": 7`. El código de salida es cero. Ante un fallo se detiene con un código distinto de cero; revisar `outputs/verification/netlogo.log` y `netlogo_tests.csv`. El tiempo máximo predeterminado es diez minutos; se puede cambiar con `--timeout 1200`.

El verificador reemplaza sus archivos anteriores en `outputs/verification/`. Conservar una copia fuera de esa carpeta si se desea comparar versiones. No ejecuta el piloto de 25 corridas ni el experimento principal.

## Explorar una corrida en la interfaz

1. Abrir `model/Article_5.nlogo` en NetLogo 6.4.0.
2. Pulsar **Defaults and setup** para crear la condición base y los 12 promotores iniciales.
3. Pulsar **Step** para avanzar un mes o **Run** para llegar al mes 60.
4. Pulsar **Export results** para guardar los CSV `manual_*` en `outputs/verification/`.

La geometría del dibujo facilita ver comunidades; la distancia gráfica no determina los enlaces. Los agentes grises no han recibido una recomendación, los amarillos han sido expuestos y los rojos han adoptado.

Para ejecutar otra estrategia en el Command Center de NetLogo:

```text
setup-defaults
set strategy "B"
setup
run-to-end
set output-prefix "../outputs/verification/manual_B"
export-results
```

Para cambiar una condición, hacerlo después de `setup-defaults` y antes de `setup`. Por ejemplo, `set repetition 2` cambia la semilla de repetición. En las comparaciones A–E hay que conservar el mismo número de repetición, riesgo y mu. El botón **Defaults and setup** restablece los parámetros base.

En la interfaz también se pueden ejecutar las 16 pruebas escribiendo `verify-all`. Esto produce los CSV de NetLogo; la auditoría Python y los manifiestos se generan con el comando automatizado anterior. Los archivos de pruebas acompañan al modelo para que `verify-all` esté disponible, pero no intervienen en una corrida normal.

## Interpretar la verificación

Los resultados PASS comprueban reglas y consistencia interna. No demuestran que el modelo describa un mercado real ni que una estrategia sea superior. Las cinco corridas `smoke_A` a `smoke_E` comparten una sola repetición; `no_bridges` es un control estructural. Las redes pequeñas adicionales tienen condiciones impuestas para obtener resultados conocidos.

El siguiente paso es el **piloto de 25 corridas**: cinco estrategias por cinco repeticiones, en la condición base. Su propósito es revisar variación, sustituciones de ruta, duración de las cascadas y oportunidad de actuación de la estrategia D después del mes 12. El piloto y la sensibilidad se mantienen pendientes.

## Documentos del proyecto

- Carpeta general: <https://drive.google.com/drive/folders/1rNe2pfCmXN30877GPZY1-D9IWJp4aJnp>.
- Especificación: <https://docs.google.com/document/d/1n6m9jE3Gm27yJHSanmC4x0sGQEAVMJcr6BGN5QpGUIE/edit>.
- Manuscrito: <https://docs.google.com/document/d/1v4vr1AUlxTgWLZo1U7a0IJCR-Oxct7qBxrYYMZ6PXVM/edit>.

Este paquete acompaña al manuscrito. El estudiante debe poder explicar las ecuaciones, recorrer una prueba pequeña y reproducir el informe antes de iniciar el piloto.
