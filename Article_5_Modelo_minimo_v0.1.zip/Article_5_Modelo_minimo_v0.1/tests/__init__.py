"""Verification helpers for Article 5."""
