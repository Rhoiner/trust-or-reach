"""Independent CSV replay: standard library only; does not call NetLogo code."""
import csv
import hashlib
import itertools
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

META = ['run_id', 'experiment_id', 'repetition_id', 'strategy', 'risk', 'mu',
        'model_version', 'network_id', 'configuration_version']
SUFFIXES = ['nodes', 'edges', 'events', 'system_period', 'agent_period', 'cascades',
            'run_summary', 'network_diagnostics', 'network_candidates', 'parameters']


def scalar(value):
    if value in ('true', 'false'):
        return value == 'true'
    if value == 'NA':
        return None
    try:
        return float(value) if any(c in value for c in '.Ee') else int(value)
    except ValueError:
        return value


def read(path):
    with path.open(encoding='utf-8', newline='') as handle:
        reader = csv.DictReader(handle)
        assert reader.fieldnames and len(reader.fieldnames) == len(set(reader.fieldnames)), path
        result = []
        for row in reader:
            assert None not in row and None not in row.values(), f'Malformed CSV: {path}'
            result.append({k: scalar(v) for k, v in row.items()})
        return result


def close(actual, expected, message):
    if expected is None:
        assert actual is None, message
    elif isinstance(expected, float):
        assert isinstance(actual, (int, float)) and math.isclose(actual, expected, abs_tol=1e-10), message
    else:
        assert actual == expected, f'{message}: {actual!r} != {expected!r}'


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def content_hash(rows):
    data = [{k: v for k, v in row.items() if k not in META} for row in rows]
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def audit_run(folder, prefix):
    data = {s: read(folder / f'{prefix}_{s}.csv') for s in SUFFIXES}
    meta = {k: data['nodes'][0][k] for k in META}
    for rows in data.values():
        for row in rows:
            assert all(row[k] == meta[k] for k in META), f'{prefix}: inconsistent metadata'
    params = {r['parameter']: scalar(str(r['value'])) for r in data['parameters']}
    nodes = {r['agent_id']: r for r in data['nodes']}
    n, horizon = params['population'], params['horizon']
    assert len(nodes) == n == 600 and set(nodes) == set(range(n))
    assert Counter(r['community'] for r in nodes.values()) == {i: 100 for i in range(6)}
    seeds = {i for i, r in nodes.items() if r['initial_promoter']}
    assert len(seeds) == 12
    edges, adjacent = {}, defaultdict(list)
    for r in data['edges']:
        i, j = r['source'], r['target']
        assert i < j and (i, j) not in edges and i in nodes and j in nodes
        assert all(0 <= r[a] <= 1 for a in ('strength', 'trust', 'cooperation', 'commitment'))
        assert r['bridge'] == (nodes[i]['community'] != nodes[j]['community'])
        assert r['active'] == (r['strength'] >= params['inactive_cut'])
        edges[i, j] = r
        if r['active']:
            adjacent[i].append(j)
            adjacent[j].append(i)
    ranked = sorted((r for r in edges.values() if r['active']), key=lambda r: (r['strength'], r['source'], r['target']))
    nw, ns = math.floor(params['weak_share'] * len(ranked)), math.floor(params['strong_share'] * len(ranked))
    for idx, r in enumerate(ranked):
        assert r['tie_class'] == ('weak' if idx < nw else 'strong' if idx >= len(ranked) - ns else 'intermediate')
    assert all(r['tie_class'] == 'inactive' for r in edges.values() if not r['active'])
    events = data['events']
    assert [r['event_id'] for r in events] == list(range(len(events)))
    by_month, agents = defaultdict(list), defaultdict(dict)
    for r in events:
        assert 1 <= r['month'] <= horizon
        by_month[r['month']].append(r)
    for r in data['agent_period']:
        assert r['agent_id'] not in agents[r['month']]
        agents[r['month']][r['agent_id']] = r
    assert set(agents) == set(range(horizon + 1))
    assert all(set(rows) == set(nodes) for rows in agents.values())
    assert [r['month'] for r in data['system_period']] == list(range(horizon + 1))
    adopted = {i: 0 for i in seeds}
    root = {i: i for i in seeds}
    generation = {i: 0 for i in seeds}
    sat = {i: 0.9 for i in seeds}
    energy = Counter({i: params['initial_energy'] for i in seeds})
    attempts, sends, successes, exposures, pairs = (Counter() for _ in range(5))
    first_exposure, parents, parent_events = {}, {}, {}
    root_history = []
    total_sent = total_new = total_repeated = eligible_sent = 0
    for m in range(horizon + 1):
        snapshot = set(adopted)
        energy_start = energy.copy()
        local_pairs, slots = set(), defaultdict(list)
        records = by_month[m]
        assert [r['order'] for r in records] == list(range(len(records)))
        for e in records:
            i, j = e['sender'], e['receiver']
            edge = edges[min(i, j), max(i, j)]
            assert edge['active'] and i in snapshot and adopted[i] < m and j not in snapshot
            assert (i, j) not in local_pairs and pairs[i, j] < 2
            if pairs[i, j]:
                assert edge['commitment'] > 0
            local_pairs.add((i, j))
            pairs[i, j] += 1
            slots[i].append(e['slot'])
            assert sat[i] >= params['satisfaction_threshold']
            assert e['energy_before'] == energy_start[i] - e['slot']
            assert e['energy_after'] == e['energy_before'] - 1 >= 0
            energy[i] -= 1
            attempts[i] += 1
            assert attempts[i] <= params['initial_energy']
            for name in ('strength', 'trust', 'cooperation', 'commitment', 'bridge'):
                close(e[name], edge[name], f'{prefix}: edge {name}')
            assert e['sender_community'] == nodes[i]['community'] and e['receiver_community'] == nodes[j]['community']
            assert e['root_id'] == root[i]
            ps = sat[i] * (params['c0'] + (1 - params['c0']) * edge['cooperation'])
            close(e['p_send'], ps, 'p_send equation')
            if not e['sent']:
                assert e['prior_exposures'] is None and e['p_adopt'] is None
                assert not e['eligible_to_adopt'] and not e['adoption']
                continue
            total_sent += 1
            sends[i] += 1
            prior = exposures[j]
            assert e['prior_exposures'] == prior
            total_repeated += prior > 0
            exposures[j] += 1
            first_exposure.setdefault(j, m)
            assert e['eligible_to_adopt'] == (j not in adopted)
            if j in adopted:
                assert e['p_adopt'] is None and not e['adoption']
                continue
            eligible_sent += 1
            t, w, risk = edge['trust'], params['trust_weight'], params['risk']
            z = params['a0'] + params['bT'] * w * t - params['gR'] * risk * (1 - w * t) - params['bX'] * max(0, prior - 1)
            pa = nodes[j]['need'] * nodes[j]['fit'] / (1 + math.exp(-z))
            close(e['p_adopt'], pa, 'p_adopt equation')
            if e['adoption']:
                assert pa > 0
                adopted[j], root[j], generation[j] = m, root[i], generation[i] + 1
                parents[j], parent_events[j] = i, e['event_id']
                sat[j] = params['quality'] * (0.5 + 0.5 * nodes[j]['fit'])
                if sat[j] >= params['satisfaction_threshold']:
                    energy[j] = params['initial_energy']
                successes[i] += 1
                total_new += 1
        for used in slots.values():
            assert sorted(used) == list(range(len(used))) and len(used) <= params['monthly_capacity']
        viable = {i for i in adopted if energy[i] > 0 and sat[i] >= params['satisfaction_threshold']
                  and any(j not in adopted and pairs[i, j] < 2 and
                          (pairs[i, j] == 0 or edges[min(i, j), max(i, j)]['commitment'] > 0)
                          for j in adjacent[i])}
        active_roots = {root[i] for i in viable}
        root_history.append(active_roots)
        reach = sum(x > 0 for x in exposures.values())
        exposed_communities = {nodes[i]['community'] for i, count in exposures.items() if count > 0}
        adopted_communities = {nodes[i]['community'] for i in adopted}
        expected = {'attempts': len(records), 'sent': sum(e['sent'] for e in records),
                    'new_adoptions': sum(e['adoption'] for e in records), 'total_adoptions': len(adopted),
                    'cumulative_attempts': sum(attempts.values()), 'cumulative_sent': total_sent,
                    'unique_reach': reach, 'repeated_exposures': total_repeated,
                    'conversion': ratio(total_new, total_sent), 'coverage': ratio(reach, n - len(seeds)),
                    'redundancy': ratio(total_repeated, total_sent), 'communities_exposed': len(exposed_communities),
                    'communities_adopted': len(adopted_communities), 'new_communities_adopted': len(adopted_communities - {0, 1}),
                    'active_promoters': len(viable), 'active_cascades': len(active_roots)}
        for key, value in expected.items():
            close(data['system_period'][m][key], value, f'{prefix}: period {m} {key}')
        for i, r in agents[m].items():
            state = ('unaware' if not exposures[i] else 'aware') if i not in adopted else (
                'customer' if sat[i] < params['satisfaction_threshold'] else 'active_promoter' if i in viable else 'inactive_promoter')
            expected_agent = {'state': state, 'exposures': exposures[i], 'first_exposure': first_exposure.get(i),
                              'adoption_month': adopted.get(i), 'energy': energy[i], 'attempts': attempts[i],
                              'sent': sends[i], 'successes': successes[i], 'parent_agent': parents.get(i),
                              'parent_event': parent_events.get(i), 'root_id': root.get(i, -1),
                              'generation': generation.get(i, -1), 'satisfaction': sat.get(i, 0),
                              'seed': i in seeds, 'community': nodes[i]['community'],
                              'need': nodes[i]['need'], 'fit': nodes[i]['fit'],
                              'eligible_from': adopted[i] + 1 if i in adopted and sat[i] >= params['satisfaction_threshold'] else horizon + 1}
            for key, value in expected_agent.items():
                close(r[key], value, f'{prefix}: agent {i}, month {m}, {key}')
    extinct = next((m for m, roots in enumerate(root_history) if not roots), None)
    summary = data['run_summary'][0]
    for key, value in {'attempts': len(events), 'sent': total_sent, 'new_adoptions': total_new,
                       'total_adoptions': len(adopted), 'adoption_at_12': data['system_period'][12]['total_adoptions'],
                       'unique_reach': reach, 'repeated_exposures': total_repeated,
                       'conversion': ratio(total_new, total_sent), 'effort_efficiency': ratio(total_new, len(events)),
                       'eligible_sent': eligible_sent, 'eligible_conversion': ratio(total_new, eligible_sent),
                       'extinction_month': extinct, 'extinction_event': extinct is not None,
                       'observed_duration': horizon if extinct is None else extinct,
                       'early_extinction': extinct is not None and extinct <= 12, 'coverage_denominator': n - len(seeds)}.items():
        close(summary[key], value, f'{prefix}: summary {key}')
    for frac in (0.1, 0.25, 0.5):
        tm = next((r['month'] for r in data['system_period'] if r['total_adoptions'] >= frac * n), None)
        close(summary[f'time_{frac}'], tm, 'Threshold time')
        close(summary[f'event_{frac}'], tm is not None, 'Threshold event')
        close(summary[f'observed_{frac}'], horizon if tm is None else tm, 'Threshold censoring')
    assert total_sent == reach + total_repeated
    assert sum(c['size'] for c in data['cascades']) == total_new
    for c in data['cascades']:
        r = c['root_id']
        descendants = [i for i in adopted if root[i] == r and i != r]
        evs = [e for e in events if e['root_id'] == r and e['sent']]
        ads = [e for e in evs if e['adoption']]
        tm = next((m for m, roots in enumerate(root_history) if r not in roots), None)
        expected_cascade = {'size': len(descendants), 'depth': max((generation[i] for i in descendants), default=0),
                            'communities_exposed': len({e['receiver_community'] for e in evs}),
                            'communities_adopted': len({nodes[i]['community'] for i in [r] + descendants}),
                            'extinct': tm is not None, 'extinction_month': tm,
                            'observed_duration': horizon if tm is None else tm}
        for kind, records in (('send', evs), ('adoption', ads)):
            expected_cascade[f'first_{kind}_month'] = records[0]['month'] if records else None
            expected_cascade[f'last_{kind}_month'] = records[-1]['month'] if records else None
        for key, value in expected_cascade.items():
            close(c[key], value, f'{prefix}: cascade {r}, {key}')
    for community in {nodes[i]['community'] for i in adopted} - {0, 1}:
        first = next(e for e in events if e['adoption'] and e['receiver_community'] == community)
        assert first['bridge'], 'First adoption of unseeded community did not cross a bridge'
    if prefix == 'no_bridges':
        assert not any(e['bridge'] for e in edges.values())
        assert all(nodes[i]['community'] in (0, 1) for i in adopted)
    correlations = []
    for scope in ('all', 'active'):
        rels = [r for r in edges.values() if scope == 'all' or r['active']]
        for a, b in itertools.combinations(('strength', 'trust', 'cooperation', 'commitment'), 2):
            corr = statistics.correlation([r[a] for r in rels], [r[b] for r in rels])
            correlations.append({'run_id': meta['run_id'], 'scope': scope, 'attribute_1': a,
                                 'attribute_2': b, 'n': len(rels), 'pearson_r': corr})
    return data, meta, params, correlations


def audit_all(folder, project, timestamp):
    prefixes = [f'smoke_{s}' for s in 'ABCDE'] + ['no_bridges']
    results, signatures = [], []
    source_files = sorted(p for p in project.rglob('*') if p.is_file() and
                          p.suffix in ('.py', '.nls', '.nlogo', '.xml', '.json') and 'outputs' not in p.parts)
    code_hashes = {str(p.relative_to(project)): sha256(p) for p in source_files}
    for prefix in prefixes:
        data, meta, params, correlations = audit_run(folder, prefix)
        signature = {s: content_hash(data[s]) for s in ('nodes', 'edges')}
        if prefix.startswith('smoke_'):
            signatures.append(signature)
        corr_path = folder / f'{prefix}_relationship_correlations.csv'
        with corr_path.open('w', encoding='utf-8', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(correlations[0]))
            writer.writeheader()
            writer.writerows(correlations)
        manifest = {'execution_utc': timestamp, 'purpose': 'technical_verification_only',
                    'empirical_calibration': False, 'pilot': False, 'metadata': meta,
                    'parameters': params, 'initial_content_sha256_without_metadata': signature,
                    'source_sha256': code_hashes,
                    'output_sha256': {p.name: sha256(p) for p in sorted(folder.glob(f'{prefix}_*.csv'))},
                    'random_draw_order': ['month', 'consumer_id', 'attempt_slot', 'route_target_send_adopt_order'],
                    'followup_draw_order': ['month', 'sender_id', 'receiver_id']}
        (folder / f'{prefix}_run_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        results.append({'audit': prefix, 'status': 'PASS', 'detail': f"Independent replay: {len(data['events'])} events; 61 periods; 36600 agent-period records"})
    assert all(s == signatures[0] for s in signatures), 'Initial nodes/edges differ between strategies'
    results.append({'audit': 'paired_initial_conditions', 'status': 'PASS', 'detail': 'A-E: identical nodes, edges, attributes and initial promoters, excluding strategy metadata'})
    with (folder / 'python_audit.csv').open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=['audit', 'status', 'detail'])
        writer.writeheader()
        writer.writerows(results)
    return results
