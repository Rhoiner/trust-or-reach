# Article 5 — Informe de verificación del modelo mínimo v0.1

**Resultado: 16 de 16 grupos de pruebas NetLogo y 7 de 7 auditorías Python aprobados.**

El modelo mínimo está implementado y es reproducible en el entorno comprobado. Esta entrega verifica reglas y consistencia interna; no realiza calibración con datos reales ni estima efectos empíricos.

## Ejecución final

- Fecha y hora UTC: 2026-09-25T17:13:57.307073+00:00.
- Entorno: NetLogo 6.4.0; Python 3.12.14; Linux x86_64.
- Duración del comando completo: 20.385 segundos en este entorno; no es una estimación para otros equipos.
- Comando: `python run_verification.py --netlogo-dir "/ruta/NetLogo-6.4.0-64"`.
- Semilla base: 20260925; repetición técnica 1; riesgo 0.50 y mu 0.20 para A–E.
- Alcance: cinco corridas técnicas A–E, un control sin puentes y casos pequeños con resultados conocidos.
- Piloto de 25 corridas: pendiente. Experimento principal y sensibilidad: pendientes.

## Pruebas de NetLogo

| ID | Aspecto comprobado | Resultado |
|---|---|---|
| V01 | Red: tamaño, comunidades, enlaces, atributos y componente gigante | PASS |
| V02 | Clases por rango; fuerza distinta de puente; enlaces inactivos excluidos | PASS |
| V03 | Prioridades, sustituciones y probabilidades de las rutas A–E | PASS |
| V04 | Selección uniforme en un grupo de cuatro contactos | PASS |
| V05 | Recursos por promotor y mes; cinco corridas emparejadas completas | PASS |
| V06 | Compromiso K=0/K=1; seguimiento; costo de intentos sin envío | PASS |
| V07 | Probabilidades acotadas; necesidad/ajuste cero; estabilidad numérica | PASS |
| V08 | Eliminación de confianza con w=0; interacción confianza–riesgo | PASS |
| V09 | Ausencia de puentes impide adopción fuera de comunidades sembradas | PASS |
| V10 | Una adopción en comunidad nueva se atribuye a un puente funcional | PASS |
| V11 | Alcance único, repetición y prevención de adopción doble | PASS |
| V12 | Satisfacción mínima y activación desde el mes siguiente | PASS |
| V13 | Ascendencia, raíz, profundidad y adopción única | PASS |
| V14 | Reproducción exacta de condiciones iniciales, eventos y estados | PASS |
| V15 | Extinción frente a silencio temporal; energía cero; cocientes indefinidos | PASS |
| V16 | Balances de adopción y cascadas; condiciones extremas | PASS |

V04 realizó 20 000 selecciones entre cuatro candidatos. Los conteos fueron 4961, 5056, 5037 y 4946, frente a 5000 esperadas por candidato y una tolerancia prefijada de ±300. Esta comprobación detecta sesgos grandes del mecanismo; no es una prueba de validez del modelo de mercado.

V14 repitió la estrategia C y exigió igualdad exacta de nodos, enlaces, eventos, series del sistema, estados individuales y actividad de cascadas. V03 comprobó directamente el cambio de probabilidades de D entre los meses 12 y 13.

## Auditoría independiente de los archivos

Python reconstruyó la difusión desde los eventos sin llamar a funciones del modelo. Para cada una de las seis corridas comprobó ecuaciones de envío y adopción, secuencia temporal, energía, intentos por pareja, exposición, adopción, ascendencia, series, estados, cascadas y resúmenes. La séptima auditoría verificó que A–E comparten exactamente consumidores, enlaces, atributos y promotores iniciales, excluyendo los metadatos de estrategia.

| Auditoría | Resultado | Evidencia |
|---|---|---|
| smoke_A | PASS | 61 períodos y 36 600 registros agente–período reconstruidos |
| smoke_B | PASS | 61 períodos y 36 600 registros agente–período reconstruidos |
| smoke_C | PASS | 61 períodos y 36 600 registros agente–período reconstruidos |
| smoke_D | PASS | 61 períodos y 36 600 registros agente–período reconstruidos |
| smoke_E | PASS | 61 períodos y 36 600 registros agente–período reconstruidos |
| no_bridges | PASS | 61 períodos y 36 600 registros agente–período reconstruidos |
| paired_initial_conditions | PASS | Mismas condiciones iniciales en las cinco estrategias |

Las seis corridas exportaron 366 registros del sistema y 219 600 registros agente–período. Las huellas SHA-256 de los seis manifiestos se contrastaron con el código y los archivos efectivamente entregados. También se conservan las correlaciones realizadas entre fuerza, confianza, cooperación y compromiso, tanto en la red completa como en la activa.

## Ejecuciones técnicas: registro de resultados

La tabla siguiente documenta la ejecución usada para verificar el código. Contiene una sola repetición por estrategia y no permite inferir superioridad general, incertidumbre entre repeticiones ni significancia estadística.

| Estrategia/control | Intentos | Envíos | Nuevas adopciones | Adopción total | Mes de extinción |
|---|---:|---:|---:|---:|---:|
| A | 410 | 256 | 104 | 116 | 21 |
| B | 76 | 34 | 9 | 21 | 5 |
| C | 248 | 132 | 51 | 63 | 16 |
| D | 384 | 219 | 94 | 106 | 18 |
| E | 140 | 70 | 24 | 36 | 18 |
| A sin puentes | 398 | 255 | 102 | 114 | 16 |

En el control sin puentes se desactivó únicamente la exigencia de una componente gigante de 570 nodos, porque seis comunidades desconectadas no pueden cumplirla. No hubo adopciones fuera de las comunidades 0 y 1. Esta excepción estaba prevista para la prueba estructural.

## Incidencias y correcciones

- Se corrigieron errores de sintaxis de NetLogo antes de completar las pruebas.
- Se corrigieron coordenadas gráficas que situaban agentes fuera de los límites de la vista; la posición no interviene en las probabilidades ni en los enlaces.
- La auditoría rechazó un CSV incompleto en una ejecución intermedia. Se repitió íntegramente el comando y se comprobaron los archivos finales y sus huellas. No se conservó ese archivo intermedio como evidencia válida.
- La versión final terminó con código de salida cero, `VERIFICATION_COMPLETE failures=0` y el resumen global `PASS`.

## Uso de la entrega y siguiente paso

El paquete de código incluye la guía de ejecución, el modelo, las pruebas, la configuración documentada y el registro de decisiones. El paquete de evidencias contiene los CSV, los manifiestos, el registro de NetLogo y los resúmenes de ambas capas de verificación. Se pueden descomprimir en una misma carpeta para reconstruir la estructura completa.

La revisión con el estudiante puede empezar por una cadena de tres agentes y por el caso de dos emisores que recomiendan al mismo receptor. Después corresponde ejecutar el piloto previsto: cinco estrategias por cinco repeticiones. Ese piloto revisará variabilidad, sustituciones, duración y actividad de D después del mes 12. Los supuestos no se reajustarán retrospectivamente para producir una ventaja de una estrategia.

La verificación no evalúa correspondencia con observaciones reales. La relación impuesta entre confianza y adopción sigue siendo un supuesto del ejercicio, y debe declararse así al escribir el artículo.
