# Implementación y decisiones — v0.1

Fecha: 25 de septiembre de 2026. Base: especificación mínima v0.1. Alcance: generador de red, modelo de difusión, estrategias A–E, exportaciones y verificación previa al piloto. Todos los parámetros son supuestos de un ejercicio académico.

## Reglas del modelo

La red tiene 600 consumidores distribuidos en seis comunidades de 100. Cada pareja no dirigida se crea de forma independiente: la probabilidad interna es `10*(1-mu)/99`, y la externa es `10*mu/500`. La condición base usa `mu = 0.20`. Se acepta el primer candidato cuya componente gigante activa alcanza 570 agentes, con un máximo de 100 candidatos; se conserva el registro de candidatos, incluso los rechazados. Este filtro es una condición estructural del ejercicio, no calibración.

La fuerza S se genera como Beta(5,2) dentro de comunidades y Beta(2,5) entre comunidades. Se descartan de la difusión enlaces con S menor que 0.05. Sobre los enlaces activos se clasifica como débil el 30% inferior y como fuerte el 30% superior, truncando los conteos hacia abajo. Los empates se resuelven por los identificadores de los extremos. Un puente es cualquier enlace entre comunidades, independientemente de su fuerza.

Confianza T, cooperación C y compromiso K se generan por separado como `0.70*S + 0.30*U`, con sorteos U independientes. Los atributos del enlace son simétricos; los intentos y su historial son dirigidos. Se exportan las correlaciones de Pearson observadas entre S, T, C y K. El peso compartido 0.70 no se interpreta como una correlación de Pearson.

Cada consumidor tiene necesidad N y ajuste F uniformes entre 0.50 y 1. Los 12 promotores iniciales se eligen sin reemplazo: seis en la comunidad 0 y seis en la 1. Comienzan con satisfacción 0.90 y energía 4. Los clientes nuevos reciben satisfacción `Q*(0.50+0.50*F)`; si alcanza 0.70, pueden recomendar desde el siguiente mes y reciben energía 4. No hay refuerzo posterior de energía.

| Estrategia | Selección entre contactos elegibles |
|---|---|
| A | Fuertes; si no existen, todos |
| B | Débiles puente; luego débiles internos; luego otros puentes; luego todos |
| C | Ruta A con probabilidad 0.50; ruta B en otro caso |
| D | Ruta A con probabilidad 0.80 hasta el mes 12 incluido; 0.30 después |
| E | Selección uniforme entre todos |

Dentro de cada grupo la selección es uniforme. Se reservan como máximo dos intentos por promotor y mes. Un intento consume una unidad de energía aunque no produzca envío. Cada pareja dirigida admite un máximo de dos intentos en toda la ejecución y uno por mes. El primer intento no exige sorteo de compromiso; el segundo solo es elegible en meses posteriores cuando el sorteo sea menor que K. Un sorteo fallido de compromiso no consume energía.

La probabilidad de envío es `satisfacción*(0.20+0.80*C)`. Si el envío llega a una persona que aún no ha adoptado, la probabilidad de adopción es `N*F*logística(z)`, con:

```text
z = -0.50 + 3*w*T - 2*riesgo*(1-w*T) - 0.50*max(0, exposiciones_previas-1)
```

La condición base usa riesgo 0.50 y w = 1. El cálculo de la logística evita desbordamientos numéricos para valores extremos. Con w = 0 desaparece todo efecto de T, incluida su interacción con riesgo.

## Orden de actualización

Al comenzar el mes se conserva la lista de adoptantes. Cada promotor habilitado selecciona contactos y reserva energía usando esa fotografía. Los intentos reservados se procesan después en un orden aleatorio. Un receptor puede recibir varios envíos durante el mes, pero solo adoptar una vez. Los envíos posteriores a su adopción en ese mismo mes cuentan como exposiciones y no reevalúan adopción.

Cada adopción conserva evento padre, agente padre, raíz y generación. Un promotor se considera con capacidad de continuar si tiene energía y al menos un contacto no adoptante con intentos estructuralmente disponibles. Un seguimiento temporalmente bloqueado por el sorteo de K sigue siendo una oportunidad futura; con K = 0 no lo es. Las series se completan hasta el mes 60 aun cuando la difusión se extinga antes.

## Reproducción y emparejamiento

Para la repetición r se usa `20260925 + 1000*(r-1)`. Los desplazamientos son 0–99 para candidatos de red; 100–199 para sus atributos; 200 para promotores iniciales; 201 para dinámica; 202 para N y F. Se conserva el candidato aceptado.

Los sorteos de dinámica se generan antes de difundir en orden fijo: mes, consumidor, slot y función —ruta, contacto, envío, adopción, orden—. Después se generan los sorteos de seguimiento por mes y pareja dirigida activa. Se generan también los sorteos que una estrategia finalmente no usa. Esto evita desplazar la secuencia compartida cuando las estrategias toman decisiones diferentes.

El emparejamiento se verifica con igualdad de las condiciones iniciales A–E. La reproducción exacta se comprueba repitiendo C y comparando nodos, enlaces, eventos, series del sistema, estados individuales y actividad de cascadas. La reproducción byte a byte entre versiones distintas de NetLogo no se da por comprobada.

## Archivos y convenciones

Cada corrida genera nodos, enlaces, eventos, series por mes, estados individuales, cascadas, resumen, parámetros y diagnósticos de red. El verificador Python añade correlaciones y manifiestos JSON con versiones, semillas y huellas SHA-256. Las columnas comunes identifican corrida, experimento, repetición, estrategia, riesgo, mu, modelo, configuración y red.

Los cocientes con denominador cero y las probabilidades no aplicables se escriben como `NA`. Los indicadores lógicos se guardan como `true`/`false`, equivalentes a 1/0 para análisis. `selected_tier` empieza en cero y `fallback = true` indica un nivel posterior. `prior_exposures` es el conteo inmediatamente anterior al envío. `event_id` empieza en cero. Los adoptantes iniciales se excluyen de nuevas adopciones y alcance; su comunidad sí cuenta en comunidades adoptantes. La cobertura base divide por 588.

El identificador `network_id` describe repetición, mu y candidato dentro de la versión y configuración registradas; la huella de contenido permite confirmar identidad. Para verificar emparejamiento se conservan copias de nodos y enlaces por estrategia. En el experimento principal se podrán consolidar esas copias por red compartida, como prevé la especificación.

## Registro de decisiones de implementación

| Decisión | Motivo y efecto |
|---|---|
| Separar producción y pruebas en dos `.nls` | Facilita recorrer funciones cortas y probarlas sin duplicar la dinámica |
| Pruebas con redes pequeñas construidas | Hace verificables casos como adopción doble, espera de activación y ausencia de puentes |
| Usar la biblioteca estándar de Python | Permite auditar sin instalar paquetes adicionales |
| Añadir un verificador de los CSV | Reconstruye contabilidad y estados sin llamar a las funciones NetLogo |
| Usar coordenadas gráficas normalizadas | Corrige posiciones fuera del mundo; no cambia el generador de enlaces ni las reglas |
| Exportar actividad de cascadas por mes | Evita reconstrucciones costosas y permite verificar extinción frente a silencio temporal |
| Mantener el JSON como registro y exportar parámetros reales | La interfaz de NetLogo permite modificar parámetros; el manifiesto documenta lo efectivamente ejecutado |

Durante el desarrollo se corrigieron errores de sintaxis de NetLogo y de posición en la vista gráfica antes de ejecutar la versión final. No se modificaron los supuestos para favorecer resultados de difusión. Los registros entregados corresponden a la versión final verificada.

## Límites y trabajo pendiente

Esta entrega implementa el mínimo de la especificación. No incluye el piloto, el diseño principal de 2500 corridas, los portafolios adicionales, sensibilidad, remuestreo ni figuras del artículo. No se estimó ningún parámetro con observaciones reales. La verificación técnica no demuestra validez empírica.

La asignación de mayor confianza a vínculos fuertes y su efecto positivo en la ecuación de adopción son supuestos. Las comparaciones futuras deben estudiar los patrones conjuntos de conversión, alcance, redundancia y esfuerzo que resultan de esas reglas, sin presentar los efectos impuestos como descubrimientos empíricos.

NetLogo y sus extensiones conservan sus licencias. El archivo `.nlogo` utiliza formas gráficas estándar de NetLogo; no se redistribuye el entorno de ejecución.
