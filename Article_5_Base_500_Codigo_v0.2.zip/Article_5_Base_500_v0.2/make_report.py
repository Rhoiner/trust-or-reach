"""Informe derivado exclusivamente de las tablas de la comparación base."""
from pathlib import Path
import statistics as st
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parent
LABELS=dict(A='Fuerte',B='Débil / puente',C='Balanceada',D='Secuencial',E='Aleatoria')


def f(value,d=1):
    return 'NA' if value is None else f'{value:.{d}f}'.replace('.',',')


def ci(row,scale=1):
    return f"[{f(scale*row['ci95_low'])}; {f(scale*row['ci95_high'])}]"


def make_report(data,lookup,paired,survival,frontier,networks,completion,design):
    means='\n'.join(f"| {s} · {LABELS[s]} | {f(lookup[s,'new_adoptions']['mean'])} {ci(lookup[s,'new_adoptions'])} | {f(lookup[s,'new_adoptions']['median'])} | {f(lookup[s,'new_adoptions']['sd'])} | {f(100*lookup[s,'coverage']['mean'])}% | {f(100*lookup[s,'conversion']['mean'])}% |" for s in 'ABCDE')
    rates='\n'.join(f"| {s} | {f(100*lookup[s,'coverage']['mean'])} {ci(lookup[s,'coverage'],100)} | {f(100*lookup[s,'conversion']['mean'])} {ci(lookup[s,'conversion'],100)} | {f(100*lookup[s,'redundancy']['mean'])} | {f(100*lookup[s,'effort_efficiency']['mean'])} | {f(lookup[s,'new_communities_adopted']['mean'],2)} |" for s in 'ABCDE')
    contrasts={(r['contrast'],r['metric']):r for r in paired}
    pair_table='\n'.join(f"| {c} | {f(contrasts[c,'new_adoptions']['mean'])} {ci(contrasts[c,'new_adoptions'])} | {f(100*contrasts[c,'coverage']['mean'])} {ci(contrasts[c,'coverage'],100)} | {f(100*contrasts[c,'conversion']['mean'])} {ci(contrasts[c,'conversion'],100)} | {contrasts[c,'conversion']['n']} |" for c in sorted({r['contrast'] for r in paired}))
    survival_table='\n'.join(f"| {r['strategy']} | {r['extinct_by_12']}/100 | {f(100*r['early_ci_low'])}–{f(100*r['early_ci_high'])}% | {r['runs_with_attempts_after_12']}/100 | {r['censored_at_60']} |" for r in survival)
    frontier_table='\n'.join(f"| {r['strategy']} | {'Sí' if r['nondominated_mean'] else 'No'} | {f(100*r['bootstrap_mean_nondominated_fraction'])}% | {f(100*r['run_nondominated_fraction'])}% |" for r in frontier)
    d=[r for r in data if r['strategy']=='D'];late=sum(r['attempts_after_12'] for r in d)
    a_late=sum(r['route_A_after_12'] for r in d);b_late=sum(r['route_B_after_12'] for r in d)
    active=[r for r in networks if r['active_only']]
    nd=', '.join(r['strategy'] for r in frontier if r['nondominated_mean'])
    date=datetime.fromisoformat(completion['finalization_utc']).astimezone(ZoneInfo('America/Bogota')).strftime('%Y-%m-%d')
    fallback='\n'.join(f"| {s} | {f(100*lookup[s,'fallback_rate']['mean'])}% | {f(lookup[s,'attempts']['mean'])} | {f(lookup[s,'sent']['mean'])} |" for s in 'ABCDE')
    ext=[r['extinction_month'] for r in data if r['extinction_month'] is not None]
    censored=[f"r{r['repetition_id']:03d}_{r['strategy']}" for r in data if not r['extinction_event']]
    censor_text=', '.join(censored) if censored else 'ninguna'
    text=f'''# Artículo 5 — Comparación base de 500 corridas

Python v0.2 · Finalización local: {date} (Colombia) · Experimento `base500_python_v0.2`

## Resultado principal y alcance

Se ejecutaron **500 corridas: cinco estrategias por 100 repeticiones emparejadas**. Las 500 aprobaron la auditoría de exportaciones y los 100 bloques aprobaron la igualdad de condiciones iniciales y sorteos. No se modificó el motor v0.2 ni se calibraron parámetros con datos reales.

En esta condición base, A produjo la mayor media de nuevas adopciones ({f(lookup['A','new_adoptions']['mean'])}) y cobertura ({f(100*lookup['A','coverage']['mean'])}%). También tuvo la mayor conversión media puntual ({f(100*lookup['A','conversion']['mean'])}%), aunque las diferencias y su incertidumbre deben examinarse por separado. B registró menor redundancia, pero esa menor repetición no se tradujo en mayor alcance individual. D actuó después del período 12 en {sum(r['attempts_after_12']>0 for r in d)} de sus 100 corridas.

Estos resultados describen la dinámica del modelo bajo riesgo 0,50 y mu 0,20. No establecen superioridad universal ni predicen ventas de empresas reales. Los experimentos de riesgo, separación de comunidades y sensibilidad continúan pendientes.

## Diseño conservado

| Elemento | Valor |
|---|---|
| Consumidores y comunidades | 600; seis comunidades de 100 |
| Adoptantes/promotores iniciales | 12; seis en cada una de dos comunidades |
| Horizonte | 60 períodos, más registro inicial en 0 |
| Riesgo; mu | 0,50; 0,20 |
| Calidad; satisfacción para activar promotor | 0,90; umbral 0,70 |
| Recursos por promotor | Hasta dos intentos por período y cuatro en toda su actividad |
| A | Prioridad de vínculos fuertes; sustitución cuando no hay candidatos |
| B | Débiles entre comunidades, débiles internos, otros puentes, resto |
| C | Probabilidad 0,50 de solicitar ruta A; resto B |
| D | Probabilidad 0,80 de solicitar A hasta 12 y 0,30 desde 13; resto B |
| E | Selección uniforme entre candidatos elegibles |
| Repeticiones | 1–100; cinco estrategias dentro de cada bloque |
| Semilla base de repetición r | 20260925 + 1000 × (r − 1) |

Se comparte red, atributos, consumidores, promotores iniciales y cinta de sorteos dentro de cada bloque. Las redes difieren entre repeticiones. Los recursos iniciales y por promotor son iguales; los intentos totales pueden divergir porque crear nuevos promotores es parte de la dinámica.

Las semillas 1–5 ya se utilizaron en el piloto. Se ejecutaron nuevamente con los identificadores del experimento principal, y las 25 salidas numéricas coincidieron con la evidencia del piloto. **No se añadieron los registros del piloto: la base contiene 500 corridas y 100 repeticiones, no 525 ni 105.** La coincidencia es una comprobación de reproducción y no una replicación independiente adicional.

## Auditoría y trazabilidad

| Comprobación | Resultado |
|---|---:|
| Corridas ejecutadas y auditadas | 500 / 500 |
| Bloques emparejados correctos | 100 / 100 |
| Redes distintas | 100 |
| Reproducciones de resultados del piloto | 25 / 25 |
| Registros de sistema | {completion['system_period_rows']:,} |
| Registros agente–período | {completion['agent_period_rows']:,} |
| Intentos/eventos | {completion['events']:,} |
| Exclusiones de corridas | 0 |

La auditoría reconstruyó los eventos desde los CSV y verificó elegibilidad, envío y adopción, límites de recursos y contactos, exposiciones, adopción única, ascendencia, cascadas, indicadores y estados exportados. Se verificaron SHA-256 de datos y motor. No se excluyeron cascadas grandes o pequeñas por su resultado. Una auditoría de código no constituye validación empírica.

Las componentes activas mayores incluyeron entre {min(r['giant_component'] for r in active)} y {max(r['giant_component'] for r in active)} consumidores y cumplieron el umbral de aceptación de 570. El grado medio activo varió entre {f(min(r['mean_degree'] for r in active),2)} y {f(max(r['mean_degree'] for r in active),2)}. El número de redes que necesitaron otro candidato fue {sum(r['accepted_candidate']>0 for r in active)}. La aceptación dependió exclusivamente de la estructura. Mu representa mezcla esperada entre comunidades; no es la modularidad realizada.

## Estimación e incertidumbre

La unidad independiente es la repetición (n = 100). Consumidores, eventos y períodos no se tratan como repeticiones independientes. Las tasas son medias no ponderadas de tasas por corrida. Se conservaron sus denominadores; una tasa indefinida se registra como NA y no como cero.

Se realizaron 2.000 remuestreos con reemplazo de los 100 bloques completos, conservando juntas A–E. Semilla de análisis: 20261001; generador NumPy PCG64. Los IC del 95% corresponden a percentiles 2,5 y 97,5 de las medias o diferencias emparejadas remuestreadas. Son intervalos puntuales; no tienen corrección por comparaciones múltiples. Se priorizan magnitudes e incertidumbre y no se presentan pruebas de significación. Para conversión, cada contraste usa solo parejas con ambas tasas definidas e informa n.

Media, mediana, desviación estándar muestral, mínimo, máximo, cuartiles, rango intercuartílico y percentiles 5–95 están en `descriptive_statistics.csv`. Los percentiles entre corridas describen dispersión; no son IC de la media. La incertidumbre Monte Carlo aquí reportada no incluye incertidumbre sobre reglas o parámetros del modelo.

## Resultados agregados

Nuevas adopciones excluye a los 12 adoptantes iniciales. Cobertura = receptores únicos no iniciales / 588. Conversión = nuevas adopciones / recomendaciones enviadas.

| Estrategia | Nuevas adopciones: media [IC 95%] | Mediana | DE | Cobertura media | Conversión media |
|---|---:|---:|---:|---:|---:|
{means}

| Estrategia | Cobertura %, media [IC 95%] | Conversión %, media [IC 95%] | Redundancia media % | Adopciones / intentos % | Nuevas comunidades adoptantes, media |
|---|---:|---:|---:|---:|---:|
{rates}

Las nuevas comunidades adoptantes excluyen las dos inicialmente sembradas (máximo cuatro). B alcanzó en promedio {f(lookup['B','new_communities_adopted']['mean'],2)} nuevas comunidades frente a {f(lookup['A','new_communities_adopted']['mean'],2)} de A. Esto es compatible con que B tenga menor cobertura de personas: amplitud entre comunidades y alcance individual son resultados diferentes.

![Distribuciones e intervalos](figures/distribuciones_base500.png)

## Diferencias emparejadas

Cada fila indica la primera estrategia del rótulo menos la segunda. Las diferencias de tasas se expresan en **puntos porcentuales (pp)**. Los intervalos se calcularon sobre diferencias dentro de cada repetición, no restando extremos de intervalos marginales.

| Contraste | Nuevas adopciones: diferencia [IC 95%] | Cobertura: pp [IC 95%] | Conversión: pp [IC 95%] | Pares válidos de conversión |
|---|---:|---:|---:|---:|
{pair_table}

El contraste D menos A en conversión fue {f(100*contrasts['D-A','conversion']['mean'],2)} pp, con IC 95% {ci(contrasts['D-A','conversion'],100)} pp. El intervalo incluye cero: esta base no separa con claridad sus conversiones medias. En nuevas adopciones, D menos A fue {f(contrasts['D-A','new_adoptions']['mean'])}, con IC {ci(contrasts['D-A','new_adoptions'])}; la diferencia favorece a A bajo los supuestos fijados.

Los archivos `paired_differences.csv` y `paired_summary.csv` incluyen además eficiencia del esfuerzo, redundancia, nuevas comunidades y extinción temprana. El signo positivo favorece a la primera estrategia solo cuando un valor mayor del indicador es deseable; mayor redundancia o mayor extinción temprana no se interpreta como mejora.

## Extinción y segunda fase de D

| Estrategia | Extinción al cierre de 12 | IC 95% de la proporción | Corridas con intentos desde 13 | Sin extinción observada en 60 |
|---|---:|---:|---:|---:|
{survival_table}

La extinción significa ausencia de promotores con capacidad futura de continuar; no se confunde con un período sin envíos. Las extinciones observadas ocurrieron entre los períodos {min(ext)} y {max(ext)}. Corridas censuradas al cierre de 60: {censor_text}. No se les asignó artificialmente un período de extinción. Los resúmenes de `extinction_month` son condicionales a extinción observada y muestran su n; no estiman por sí solos una duración media que incorpore censura. Todas las series se conservaron hasta 60.

D acumuló {late:,} intentos en períodos 13–60: {a_late:,} solicitaron ruta A y {b_late:,} ruta B ({f(100*b_late/late) if late else 'NA'}% B, proporción agrupada). Generó {sum(r['adoptions_after_12'] for r in d):,} nuevas adopciones en esa fase. La mezcla asignada es probabilística, no una cuota exacta. La segunda fase tuvo oportunidad de actuar, pero su efecto aislado no se identifica comparando D con A o C: también difieren sus mezclas iniciales. No se cambió retrospectivamente el corte temporal.

`threshold_attainment.csv` conserva la fracción que alcanzó 10%, 25% y 50% de adopción total. Los tiempos entre quienes alcanzaron el umbral son descriptivos condicionales; los que no lo alcanzaron permanecen censurados en 60, sin convertirse en ceros.

![Trayectorias](figures/trayectorias_base500.png)

## Sustituciones y clase realmente seleccionada

| Estrategia | Sustituciones / intentos, media | Intentos, media | Envíos, media |
|---|---:|---:|---:|
{fallback}

Una sustitución utiliza un nivel posterior al primero de la ruta solicitada. En B, pasar de débiles entre comunidades a débiles internos ya cuenta como sustitución. E tiene un solo nivel y su tasa cero obedece a esta definición. Una estrategia solicitada no equivale siempre a la clase de vínculo usada.

`realized_selection_profiles.csv` informa clases y puentes realizados; `selection_tiers.csv` y su resumen distinguen rutas y niveles, incluyendo fases de D. `conversion_by_actual_tie_class.csv` separa conversión por clase realizada, corrida y fase, con sus denominadores. Esta comparación descriptiva por clase no identifica un efecto puro del vínculo porque cambian receptores, momentos y condiciones de selección. B combina debilidad y puente entre comunidades; A frente a B tampoco separa ambos efectos.

## Frontera confianza–alcance

Con cobertura y conversión como objetivos crecientes, las estrategias no dominadas según sus medias puntuales son: **{nd}**. El conjunto es finito y restringido a A–E en esta condición base. La nube de remuestreo permite examinar cómo cambia esta clasificación cuando varían los bloques usados para estimar las medias.

| Estrategia | No dominada en medias puntuales | No dominada entre medias bootstrap | No dominada dentro de cada repetición |
|---|---|---:|---:|
{frontier_table}

Estas frecuencias no son probabilidades de que una estrategia sea universalmente óptima. La última columna compara resultados dentro de cada bloque, mientras la columna bootstrap compara medias; no tienen la misma interpretación. La figura muestra incertidumbre Monte Carlo y no variaciones de riesgo o topología fuera del diseño.

![Frontera confianza–alcance](figures/frontera_confianza_alcance_base500.png)

## Interpretación para el artículo y próxima etapa

En esta base, priorizar vínculos fuertes produjo una difusión mayor, aun con más redundancia. La menor repetición de B no compensó su menor conversión y continuidad. Esto es compatible con las reglas del modelo, donde fuerza se relaciona con confianza, cooperación y compromiso, y las adopciones satisfechas pueden crear nuevos promotores. El patrón agregado surge de esos mecanismos; el vínculo impuesto entre confianza y adopción no debe presentarse como descubrimiento empírico.

La base permite estudiar diferencias entre estrategias bajo una condición fija. Aún no responde cómo cambian esas diferencias con el riesgo, la separación de comunidades o el peso de confianza. La siguiente etapa prevista en la especificación es comparar riesgo 0,20 y 0,80, reutilizando esta condición central: **1.000 corridas adicionales** para completar el experimento de riesgo. La separación y la sensibilidad permanecen como etapas distintas. No se ejecutaron en esta entrega.

## Reproducción y archivos

El README describe la reunión de los paquetes y los comandos. El motor permanece en `engine/`; el diseño y el plan están en `design/`; las referencias congeladas, en `provenance/`. `outputs/raw/` contiene 500 carpetas de corridas con 11 CSV y un manifiesto cada una. Los ZIP de datos se dividen por bloques de repeticiones y no omiten trazas agente–período. `outputs/checks/` conserva auditorías y comprobaciones de emparejamiento. `outputs/tables/` contiene datos de análisis y remuestreo. Las tres figuras se entregan en PNG y PDF.

Fuentes del proyecto: especificación mínima Python v0.2, motor verificado v0.2 e informe del piloto de 25 corridas. La especificación histórica conserva referencias al piloto pendiente; los índices posteriores registran su realización y esta etapa. El manuscrito no fue editado en esta entrega.
'''
    (ROOT/'outputs/Article_5_Informe_base_500_v0.2.md').write_text(text,encoding='utf-8')
