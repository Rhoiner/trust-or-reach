#!/usr/bin/env python3
"""Empaqueta trazas por cinco repeticiones; conserva todos los CSV originales."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent/'Article_5_Base_500_Entregables'


def package(name,paths):
    path=DEST/name
    files=sorted(p for p in paths if p.is_file() and '__pycache__' not in p.parts)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,str(Path(ROOT.name)/p.relative_to(ROOT)))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(files)
    result=dict(file=name,files=len(files),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    print(json.dumps(result),flush=True)
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--raw-only',action='store_true')
    parser.add_argument('--support-only',action='store_true')
    args=parser.parse_args()
    assert not(args.raw_only and args.support_only)
    DEST.mkdir(exist_ok=True)
    manifest=[]
    if not args.support_only:
        for start in range(1,101,5):
            end=start+4
            paths=[]
            for rep in range(start,end+1):
                for s in 'ABCDE':
                    folder=ROOT/'outputs/raw'/f'r{rep:03d}_{s}'
                    manifest_path=folder/f'{folder.name}_run_manifest.json'
                    manifest_data=json.loads(manifest_path.read_text())
                    # Solo exportaciones finalizadas; los temporales no son datos.
                    paths.extend([manifest_path,*[folder/name for name in manifest_data['output_sha256']]])
            assert len(paths)==300,(start,len(paths))
            row=package(f'Article_5_Base_500_Datos_r{start:03d}_r{end:03d}_v0.2.zip',paths)
            row.update(repetition_first=start,repetition_last=end,runs=25)
            manifest.append(row)
        assert sum(r['runs'] for r in manifest)==500
        (DEST/'raw_packages.json').write_text(json.dumps(manifest,indent=2)+'\n')
    if not args.raw_only:
        specs={
          'Article_5_Base_500_Codigo_v0.2.zip':[*ROOT.joinpath('engine').rglob('*'),*ROOT.joinpath('design').glob('*'),
             *ROOT.joinpath('provenance').rglob('*'),*ROOT.glob('*.py'),ROOT/'README.md',ROOT/'requirements-analysis.txt'],
          'Article_5_Base_500_Diseno_v0.2.zip':list(ROOT.joinpath('design').glob('*')),
          'Article_5_Base_500_Verificacion_v0.2.zip':list(ROOT.joinpath('outputs/checks').glob('*')),
          'Article_5_Base_500_Analisis_v0.2.zip':[*ROOT.joinpath('outputs/tables').glob('*'),*ROOT.joinpath('outputs/figures').glob('*'),
             ROOT/'outputs/Article_5_Informe_base_500_v0.2.md',ROOT/'outputs/analysis_manifest.json'],
          'Article_5_Base_500_Figuras_v0.2.zip':list(ROOT.joinpath('outputs/figures').glob('*'))}
        support=[package(name,paths) for name,paths in specs.items()]
        manifest=json.loads((DEST/'raw_packages.json').read_text())+support
        (DEST/'Article_5_Base_500_Manifiesto_paquetes_v0.2.json').write_text(json.dumps(manifest,indent=2)+'\n')


if __name__=='__main__':
    main()
