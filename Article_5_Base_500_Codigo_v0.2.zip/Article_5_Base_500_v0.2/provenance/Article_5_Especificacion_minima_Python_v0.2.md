# Especificación mínima de la simulación del Artículo 5

Versión 0.2 | Implementación Python y verificación previa al piloto | 25 de septiembre de 2026 (Colombia)

## 1 Propósito y alcance académico

Construiremos un modelo basado en agentes para estudiar cuándo distintas formas de seleccionar relaciones producen mayor conversión, mayor alcance o diferentes combinaciones de ambos. El trabajo será un ejercicio teórico con un estudiante de pregrado y acompañamiento de dos profesores. No utilizaremos datos reales para calibrar parámetros, estimar probabilidades o predecir ventas. Todos los valores numéricos serán supuestos experimentales explícitos.

Pregunta central: bajo recursos individuales equivalentes, ¿cómo cambian la conversión, el alcance único y la redundancia cuando las recomendaciones priorizan relaciones fuertes, relaciones débiles con prioridad de puente, una combinación, una secuencia o selección aleatoria?

La guía original constituye la orientación conceptual. La especificación v0.1 resolvió las decisiones operativas iniciales. La versión v0.2 conserva sus supuestos y adopta Python como plataforma principal del modelo, las pruebas y los análisis, por decisión del usuario. NetLogo v0.1 se conserva como referencia histórica. La implementación Python pasó 16 pruebas de la especificación, cuatro de migración y siete auditorías independientes. Se ejecutaron corridas técnicas; el piloto y el experimento principal continúan pendientes.

## 2 Configuración inicial

| Elemento | Valor o regla inicial |
|---|---|
| Población | 600 consumidores con identificadores de 0 a 599 |
| Comunidades | Seis grupos de 100 personas; comunidad = parte entera de id / 100 |
| Oferta | Una empresa y un producto; adopción única por persona |
| Horizonte | 60 períodos; se denominan meses como convención del modelo |
| Red | Estática, no dirigida, sin bucles ni enlaces duplicados |
| Grado esperado | 10 vecinos por consumidor |
| Promotores iniciales | 12; seis elegidos al azar en cada una de las comunidades 0 y 1 |
| Intentos por promotor | Hasta dos por período y cuatro durante toda su actividad |
| Energía | Cuatro unidades al activarse; cada intento consume una |
| Riesgo del producto | 0.50 en el escenario base; 0.20 y 0.80 en experimentos |
| Calidad del producto | 0.90; constante entre estrategias |
| Estrategias | A fuerte, B débil con prioridad de puente, C balanceada, D secuencial y E aleatoria |

Los períodos no representan duraciones empíricamente estimadas. No habrá incentivos, competencia, ingresos monetarios, capacidad de producción, pérdida de clientes, creación de vínculos ni difusión externa. Las necesidades permanecerán constantes. Estas simplificaciones reducen el trabajo de programación y permiten concentrarse en la selección de relaciones.

## 3 Red y atributos relacionales

### 3.1 Generación de la red

Para cada pareja no ordenada de consumidores se sortea un enlace de manera independiente. Definimos mu como la proporción esperada de vecinos de otras comunidades. Con grupos de 100 y grado esperado de 10:

    p_in = 10 * (1 - mu) / 99
    p_out = 10 * mu / 500

| Condición | mu | p_in | p_out |
|---|---:|---:|---:|
| Separación alta entre comunidades | 0.05 | 0.09596 | 0.00100 |
| Separación media y escenario base | 0.20 | 0.08081 | 0.00400 |
| Separación baja entre comunidades | 0.40 | 0.06061 | 0.00800 |

Los rótulos describen la separación prevista. Mu no es la modularidad observada. Se calcularán grado, densidad, distribución de grados, agrupamiento, componentes, proporción de puentes y modularidad de la partición conocida, tanto para la red generada como para su parte activa. No afirmaremos que el grado realizado permanece exactamente constante entre redes.

Cada red se acepta si su componente activa mayor contiene al menos 570 consumidores. Si falla, se regenera con la siguiente semilla de generación y se registra el motivo. Máximo de 100 candidatos por repetición; si ninguno cumple, se detiene esa condición y se revisa el generador. La aceptación depende exclusivamente de la estructura, nunca del desempeño de difusión. La prueba sin puentes omite expresamente este criterio de conectividad.

### 3.2 Fuerza y función del vínculo

La fuerza S se genera con Beta(5,2) para enlaces internos y Beta(2,5) para enlaces entre comunidades. Un enlace con S < 0.05 es inactivo y no puede seleccionarse. El puente se identifica únicamente porque sus extremos pertenecen a comunidades distintas. Las distribuciones se superponen: habrá relaciones débiles internas y algunas fuertes entre comunidades.

En los M enlaces activos, ordenar S de menor a mayor; romper empates por los identificadores de sus extremos. Los primeros floor(0.30*M) se clasifican como débiles y los últimos floor(0.30*M) como fuertes; los demás son intermedios. La clasificación es global, se calcula una vez y permanece fija durante la ejecución. En una red de prueba con M < 4 se asignarán explícitamente las clases para evitar grupos vacíos debidos al redondeo.

Confianza T, cooperación C y compromiso K se generan por separado para cada enlace:

    X = rho * S + (1 - rho) * U_X
    X pertenece a {T, C, K}; U_X es uniforme entre 0 y 1
    rho = 0.70

Los tres sorteos son independientes entre sí y entre enlaces. Rho controla el peso compartido de la fuerza; no es un coeficiente de correlación de Pearson. Se conservarán las correlaciones realizadas. Por simplicidad, los atributos son simétricos; los intentos y sus resultados sí son direccionales. Esta aproximación limita la representación de relaciones asimétricas y se declarará en el artículo.

## 4 Consumidores y estados

Cada consumidor tiene necesidad N y ajuste del producto F, ambos independientes y uniformes entre 0.50 y 1.00. Se generan una sola vez y se reutilizan en todas las estrategias de una misma repetición. Los casos extremos de verificación podrán fijarlos en cero o uno.

Se almacenan por separado conocimiento de la oferta, adopción y actividad promotora. Los estados visibles son desconocedor, conocedor sin adopción, cliente, promotor activo y promotor inactivo. La evaluación ocurre dentro del evento de recomendación: no es un estado con duración propia. Una decisión negativa no es un rechazo permanente; una recomendación posterior puede generar otra evaluación.

La satisfacción después de adoptar es Q * (0.50 + 0.50*F), con Q = 0.90. Si alcanza 0.70, el cliente recibe cuatro unidades de energía y puede recomendar desde el período siguiente. En caso contrario continúa como cliente. Los 12 promotores iniciales son una condición de arranque: satisfacción de 0.90, energía de cuatro y disponibilidad desde el período 1. Se excluyen de los indicadores de nuevas adopciones y alcance por recomendaciones.

No se añade un mecanismo independiente de influencia social, susceptibilidad o reputación en esta versión. Podrá incorporarse después si resulta necesario para la pregunta científica.

## 5 Elegibilidad y estrategias

### 5.1 Contactos disponibles

Al inicio de cada período, un candidato debe ser vecino mediante enlace activo, no haber adoptado al comienzo del período y haber recibido menos de dos intentos de ese emisor en toda la ejecución. Cada emisor puede seleccionar a una persona una sola vez en el mismo período.

El primer intento por pareja dirigida es elegible directamente. Después de un primer intento, haya sido enviado o no, solo se permite un segundo intento en un período posterior. En cada período posterior, un sorteo uniforme debe ser menor que K para habilitarlo. Si falla el sorteo, no se consume energía y se podrá reconsiderar en otro período. Así, el compromiso controla la persistencia del seguimiento, sin confundirse con cooperación o confianza.

Esta regla supone que los promotores conocen si sus propios vecinos ya habían adoptado al inicio del período. No conocen el historial global de exposiciones ni utilizan esa información para seleccionar contactos. Todas las estrategias comparten esta misma información. La novedad se mide como resultado; no se concede conocimiento adicional a la estrategia B.

### 5.2 Prioridades y sustitución

En cada intento se elige uniformemente dentro del primer grupo no vacío de la prioridad correspondiente. Si un grupo queda vacío, se utiliza el siguiente y se registra la sustitución. Si no queda ningún candidato, no hay intento ni gasto de energía.

| Estrategia | Regla operativa |
|---|---|
| A fuerte | Relaciones fuertes; si no hay, cualquier candidato restante |
| B débil con prioridad de puente | Débiles entre comunidades; luego débiles internas; luego otros puentes; finalmente cualquier candidato restante |
| C balanceada | Elegir ruta A con probabilidad 0.50 y ruta B con probabilidad 0.50 por intento |
| D secuencial | Elegir ruta A con probabilidad 0.80 en períodos 1 a 12 y 0.30 en períodos 13 a 60; en otro caso usar B |
| E aleatoria | Selección uniforme entre todos los candidatos elegibles |

Las proporciones son probabilidades de asignación, no cuotas exactas en cada promotor. Se guardará la ruta solicitada y la clase realmente seleccionada, pues las sustituciones pueden cambiar la combinación realizada. Los empates no se resuelven por el orden del identificador: se sortean.

La estrategia B combina intensidad y posición entre comunidades. Una diferencia entre A y B no identificará por separado el efecto puro de debilidad y el de puente. Esta limitación debe mantenerse visible en la interpretación.

## 6 Decisiones de envío y adopción

### 6.1 Decisión del emisor

Cada contacto seleccionado constituye un intento y consume una unidad de energía, aunque finalmente no se envíe la recomendación. No se recupera energía después de una adopción.

    p_send = satisfacción_emisor * (c0 + (1 - c0) * C)
    c0 = 0.20

Un sorteo uniforme menor que p_send produce el envío. La cooperación afecta esta decisión; el compromiso actúa en la elegibilidad del seguimiento. La estrategia únicamente selecciona la ruta y no modifica directamente las probabilidades de envío o adopción.

### 6.2 Decisión del receptor

Solo se evalúa adopción si la recomendación se envió y el receptor todavía no ha adoptado al procesar el evento. Sea x el número de recomendaciones enviadas que había recibido antes de ese evento:

    exceso = max(0, x - 1)
    z = a0 + bT*w*T - gR*riesgo*(1 - w*T) - bX*exceso
    p_adopt = N * F / (1 + exp(-z))

Valores iniciales: a0 = -0.50; bT = 3.00; gR = 2.00; bX = 0.50; w = 1.00. Todos son supuestos de exploración, sin fuente empírica ni interpretación de estimadores. W es un control experimental entre cero y uno que habilita o reduce el papel de confianza.

La primera y segunda exposición tienen la misma penalización de repetición, igual a cero. La tercera y posteriores incorporan una penalización creciente. No se añade un premio por segunda exposición en la versión mínima.

Con estos signos, aumentar el riesgo nunca eleva directamente p_adopt para un consumidor y vínculo dados. La confianza reduce esa penalización. Su efecto sobre z aumenta con el riesgo; el efecto marginal sobre la probabilidad puede no crecer en todo el dominio por la curvatura de la función logística. La verificación distinguirá ambos niveles.

Cuando w = 0, se elimina todo efecto de confianza, incluida la interacción con riesgo. N = 0 o F = 0 implica adopción imposible. Una recomendación enviada actualiza conocimiento y contador de exposiciones aunque no produzca adopción.

## 7 Orden de ejecución y seguimiento de cascadas

Para cada período se conserva una fotografía de los adoptantes, promotores y candidatos iniciales. Se habilitan los seguimientos por K y cada promotor inicial del período reserva hasta dos intentos, sujetos a energía. Se seleccionan contactos sin reemplazo dentro del período y se descuenta la energía. Luego se procesan todos los intentos en un orden aleatorio reproducible, igual en su mecanismo para todas las estrategias.

En cada evento se decide envío; si se envía, se registra x, se actualiza exposición y se evalúa adopción cuando corresponda. Dos emisores pueden seleccionar al mismo receptor: si el primero logra adopción, el segundo envío sigue contando como exposición, pero no genera otra compra. La satisfacción y la asignación de energía se calculan al adoptar; los nuevos promotores solo actuarán desde el próximo período.

Al cerrar el período se actualizan indicadores y se exportan resultados. Un promotor queda inactivo cuando agota energía o no le queda ningún vecino no adoptante con intentos disponibles. Un seguimiento bloqueado temporalmente por el sorteo de compromiso no implica inactividad definitiva. Si K = 0, ese segundo intento es imposible y no cuenta como oportunidad disponible.

Cada promotor inicial es la raíz de una cascada, con profundidad cero. Toda adopción posterior registra un único evento causal dentro del modelo, su emisor, la raíz heredada del emisor y profundidad del emisor más uno. La primera recomendación que logra la adopción recibe esa atribución; no se infiere que sea la única influencia en contextos reales. Las cascadas no se fusionan y una misma adopción no pertenece a dos raíces.

Una cascada tiene capacidad de continuar mientras exista un promotor de su raíz con energía y contactos estructuralmente disponibles, sin exigir que el sorteo de seguimiento del período sea favorable. La difusión se extingue cuando ninguna cascada conserva esa capacidad. Un período sin adopciones no prueba extinción. Las series se completan hasta el período 60, con ceros de actividad y acumulados constantes cuando haya extinción.

## 8 Indicadores y denominadores

| Indicador | Definición |
|---|---|
| Intentos | Contactos seleccionados; incluye decisiones de no enviar |
| Envíos | Intentos que produjeron una recomendación efectiva |
| Conversión | Nuevas adopciones / envíos |
| Alcance único | Personas no iniciales que recibieron al menos un envío |
| Cobertura por WOM | Alcance único / 588 |
| Redundancia | Envíos a receptores con x mayor que cero / envíos |
| Adopción total | 12 adoptantes iniciales más nuevas adopciones |
| Eficiencia del esfuerzo | Nuevas adopciones / intentos; cada intento equivale a una unidad de energía |
| Comunidades expuestas | Comunidades con al menos un receptor no inicial de una recomendación |
| Comunidades con adopción | Comunidades con al menos un adoptante, incluidas las dos iniciales |
| Nuevas comunidades adoptantes | Comunidades con adopción fuera de las dos iniciales; máximo cuatro |
| Conversión entre receptores elegibles | Nuevas adopciones / envíos recibidos antes de adoptar; indicador complementario |
| Extinción temprana | Ninguna cascada con capacidad de continuar al cierre del período 12 |
| Tamaño de cascada | Descendientes adoptantes de cada raíz, excluida la raíz |
| Profundidad de cascada | Máxima profundidad observada de sus adoptantes |

Todo cociente con denominador cero se guarda como NA, junto al denominador; no como cero. Los resúmenes indicarán cuántas repeticiones permiten calcularlo. Se comprobará que envíos = alcance único + exposiciones repetidas.

Se medirá el primer período en que la adopción total alcanza 60, 150 y 300 personas, equivalentes al 10%, 25% y 50% del mercado. Si no ocurre, el tiempo será NA y el indicador de evento será cero; para análisis temporal se registrará censura en 60. Se conservarán adopción a 12 y 60, último período con envío, último período con adopción y extinción observada o censurada.

La frontera confianza–alcance usará cobertura por WOM en el eje horizontal y conversión en el vertical. Entre las estrategias comparadas, un punto es no dominado si ningún otro mejora al menos una dimensión sin empeorar la otra. Se mostrará incertidumbre entre repeticiones y se evitará presentar esa frontera finita como un óptimo universal.

## 9 Comparaciones y semillas

Una repetición incluye una red, consumidores, promotores iniciales y sorteos reproducibles. Para comparar estrategias dentro de la misma condición, se reutilizan exactamente la red, los atributos y los promotores. Entre riesgos se conserva también esa misma base. Entre niveles de separación cambia la red, manteniendo la población y el grado esperado.

Para la repetición r, de 1 a 100, se define base_r = 20260925 + 1000*(r-1). Los candidatos de red utilizan base_r + 0 a 99; los atributos del candidato usan base_r + 100 a 199 respectivamente. La selección inicial usa base_r + 200 y la dinámica base_r + 201. Se conserva cuál candidato fue aceptado. N y F se generan con base_r + 202, en orden de consumidor, y se reutilizan entre niveles de separación. Los atributos relacionales usan la semilla del candidato y se generan en orden de pareja.

La implementación generará antes de difundir los sorteos de dinámica en orden fijo: período, consumidor, slot de intento 1 o 2, y función del sorteo. Las funciones son elección de ruta, elección de contacto, envío, adopción y orden del evento. Los sorteos de seguimiento se generan por período y pareja dirigida activa en orden fijo. Se generan incluso cuando un agente no esté activo, para que las decisiones de una estrategia no desplacen la secuencia de las otras. Se guardan semillas y orden del generador; no es obligatorio exportar toda la tabla de sorteos.

La independencia corresponde a las repeticiones; las estrategias dentro de cada repetición se comparan de forma emparejada. La igualdad de recursos significa la misma capacidad por promotor y el mismo presupuesto inicial. Si una estrategia crea más promotores, puede acumular mayor esfuerzo total; eso es un resultado endógeno y se informa con los indicadores de eficiencia. No se afirmará que los intentos totales fueron forzosamente iguales.

## 10 Verificación antes del piloto

El registro de pruebas tendrá identificador, condición, resultado esperado, resultado observado, semilla y estado. En Python v0.2 las 16 pruebas fueron ejecutadas y aprobadas; el informe y los CSV de verificación documentan los resultados. Se añadieron M01–M04 para contrastar la migración, el emparejamiento, la configuración y los diagnósticos. Las expectativas agregadas de la guía no se convierten en requisitos para favorecer una estrategia.

| Prueba | Criterio para aprobar |
|---|---|
| V01 Red | 600 agentes, seis comunidades, ausencia de bucles y duplicados, atributos dentro de cero y uno |
| V02 Clases y puentes | Clasificación por rango correcta; prueba construida con un débil interno y un fuerte entre comunidades |
| V03 Estrategias | En redes pequeñas conocidas, cada ruta respeta prioridades, probabilidades asignadas y sustituciones |
| V04 Aleatoriedad | Con prioridades desactivadas, el mecanismo selecciona uniformemente candidatos; comprobar con muestra amplia y tolerancia documentada |
| V05 Recursos | Máximo dos intentos por período, energía nunca negativa, máximo cuatro intentos por promotor |
| V06 Compromiso | K = 0 impide segundo intento; K = 1 lo habilita desde el período siguiente; nunca más de dos por pareja dirigida |
| V07 Probabilidades | Envío y adopción entre cero y uno; N = 0 o F = 0 impide adopción |
| V08 Confianza y riesgo | Con w = 0, cambiar T no cambia p_adopt; con w = 1, el coeficiente de T en z es bT + gR*riesgo |
| V09 Sin puentes | Ninguna adopción fuera de las comunidades inicialmente sembradas |
| V10 Puente funcional | La primera adopción de cada comunidad no sembrada proviene de un evento entre comunidades |
| V11 Exposiciones | Dos envíos al mismo receptor producen alcance uno, dos exposiciones y una repetida |
| V12 Promotores | Satisfacción inferior a 0.70 impide activación; los nuevos promotores esperan hasta el siguiente período |
| V13 Adopción y ascendencia | Cada persona adopta como máximo una vez; toda adopción no inicial tiene un evento padre y una raíz válidos |
| V14 Reproducción | Parámetros, versión y semillas idénticos generan las mismas tablas, salvo metadatos de ejecución |
| V15 Extinción | Energía inicial cero produce cero intentos; ausencia temporal de envíos no declara extinción si quedan oportunidades |
| V16 Contabilidad | 12 + suma de nuevas adopciones = adopción total; suma de tamaños de cascada = nuevas adopciones |

También se inspeccionarán casos de todos adoptantes, ajuste perfecto, confianza cero, población sin necesidad, presupuesto muy alto pero finito y red muy mezclada. Ajuste perfecto o confianza alta no implican adopción segura. No se exigirá que una estrategia gane para aprobar el modelo.

La revisión docente examinará las reglas y algunas trazas de eventos. Esta revisión y las pruebas de código no constituyen validación empírica. El protocolo ODD se construirá a partir de esta especificación y se actualizará con las decisiones reales de implementación.

## 11 Experimentos por etapas

| Etapa | Diseño | Ejecuciones |
|---|---|---:|
| Piloto técnico | Cinco estrategias por cinco repeticiones, riesgo y separación medios | 25 |
| Comparación base | Cinco estrategias por 100 repeticiones | 500 |
| Riesgo | Tres riesgos por cinco estrategias por 100 repeticiones | 1500, incluidas las 500 base |
| Separación de comunidades | Tres valores de mu por cinco estrategias por 100 repeticiones, riesgo medio | 1500, incluidas las 500 base |
| Portafolio | Probabilidad de ruta A igual a 0, 0.20, 0.40, 0.60, 0.80 y 1, con 100 repeticiones | 600, con dos extremos reutilizables |

Los experimentos base, riesgo y separación contienen 2500 ejecuciones únicas, porque comparten la condición central. No constituyen un cruce completo de riesgo y modularidad: no permiten estimar su interacción conjunta. El portafolio agrega 400 ejecuciones si sus extremos reproducen exactamente A y B; de lo contrario, se ejecutan y documentan por separado. El piloto queda identificado como técnico y no se mezcla con la base principal.

El piloto revisará errores, recursos, frecuencia de sustituciones, supervivencia al período 12 y variación de resultados. Si la difusión termina antes del cambio de fase, se reportará la limitada oportunidad de actuar de D. No se moverá retrospectivamente el cambio de fase para obtener una ventaja; una secuencia más temprana requerirá una versión y un experimento separados.

Tras estabilizar el modelo, se priorizará sensibilidad de un factor a la vez: peso de confianza w = 0, 0.50 y 1; acoplamiento rho = 0 y 0.70; energía = 2, 4 y 8; penalización bX = 0 y 0.50; y ubicación de semillas en una, dos o seis comunidades manteniendo 12 promotores. Se examinarán además el efecto de cooperación y compromiso, cortes de fuerza 20% y 40%, y umbral de satisfacción 0.65 y 0.75. Primero se usarán cinco semillas para diagnóstico; los escenarios que se utilicen como evidencia en el artículo se ampliarán a 100 repeticiones. No se requiere una búsqueda global de parámetros ni calibración con observaciones reales.

## 12 Exportaciones y análisis

Cada ejecución tendrá run_id, experiment_id, repetition_id, estrategia, riesgo, mu, versión del modelo, versión de configuración y semillas. Los identificadores se repetirán como llaves en las tablas. Los datos numéricos usarán punto decimal y los CSV se guardarán en UTF-8. Las fechas de ejecución son metadatos y nunca sustituyen el período simulado.

Se exportarán los siguientes archivos:

- nodes.csv y edges.csv: red y atributos iniciales; guardar una copia por red compartida, con network_id.
- events.csv: una fila por intento con emisor, receptor, período, slot, ruta solicitada, grupo utilizado, sustitución, S, T, C, K, comunidades, puente, envío, probabilidad de envío, exposiciones previas, elegibilidad de adopción, probabilidad de adopción, resultado y energía consumida. Las probabilidades no aplicables se marcan NA.
- system_period.csv: una fila por período, incluidos cero y 60, con intentos, envíos, adopciones, alcance, repetición, comunidades y promotores activos.
- agent_period.csv: estado, exposiciones, adopción, satisfacción, energía, intentos y recomendaciones acumuladas de cada agente por período.
- cascades.csv: raíz, descendientes, profundidad, comunidades de adoptantes y de receptores expuestos, períodos de primera y última actividad y extinción o censura.
- run_summary.csv: una fila por ejecución con indicadores finales, tempranos, tiempos hasta umbrales y sus denominadores.
- run_manifest.json: configuración, versiones, semillas, identificador de red y huellas de los archivos iniciales y del código.

Las proporciones por clase de vínculo se calcularán usando la clase realmente utilizada. Los resultados mensuales describen trayectorias; no son repeticiones independientes. Se reportarán media, mediana, desviación estándar, rango intercuartílico, percentiles 5 y 95 e intervalos de confianza entre repeticiones.

Para comparar estrategias se calcularán diferencias emparejadas por repetition_id. Los intervalos del 95% se podrán obtener mediante 2000 remuestreos de las repeticiones completas, conservando juntas sus estrategias; semilla de análisis 20261001. En cada contraste de conversión se usarán las parejas con ambas tasas definidas y se informará su número. Se dará prioridad a magnitud e incertidumbre frente a pruebas múltiples de significación. No se eliminarán cascadas grandes o pequeñas por ser inesperadas; cualquier exclusión por error técnico se registrará y corregirá antes del análisis.

## 13 Responsabilidades y siguiente entrega

El estudiante implementará módulos pequeños, mantendrá el registro de decisiones, ejecutará las pruebas y preparará las figuras y el primer análisis. Los profesores revisarán la coherencia conceptual, los supuestos, la verificación y las interpretaciones. La asistencia automatizada puede apoyar código y documentación; el estudiante deberá poder explicar cada regla y reproducir la ejecución.

El generador de red y el modelo mínimo con sus pruebas se entregaron en Python v0.2. El siguiente paso es revisar el código con el estudiante y ejecutar el piloto de 25 corridas. La revisión cubre la separación entre fuerza, confianza, cooperación y compromiso; selección de contactos; contabilidad de recursos; exposición única; y ascendencia de cascadas.

El manuscrito se redactará en el documento original Article 5 - NM - 2 - RD. Esta especificación es un documento técnico complementario. La guía de ejecución, la organización y los enlaces están en README.md del paquete Article_5_Python_v0.2.

Los resultados se describirán como patrones producidos bajo los supuestos del modelo. No se presentará el vínculo impuesto entre confianza y adopción como descubrimiento empírico, ni se afirmará que alguna estrategia es óptima para todos los emprendedores.


## 14 Registro de la migración a Python

La migración conserva el modelo conceptual y los valores experimentales. El motor y sus pruebas usan la biblioteca estándar de Python 3.10 o posterior; el entorno comprobado se registra en cada manifiesto. El JSON `config/base_v0.2.json` ahora es una entrada ejecutable. Los CSV conservan las definiciones y los indicadores de v0.1. Se añade proporción de puentes explícita a diagnósticos; `adoption_at_12` es NA si se solicita una ejecución de menos de 12 períodos.

Python utiliza `random.Random` con los bloques de semillas definidos arriba. Fuerza Beta se obtiene como cociente de dos Gamma; los sorteos de dinámica mantienen el orden fijo. No se exige igualdad de las secuencias aleatorias entre Python y NetLogo. Las corridas de ambas versiones no se mezclan ni se emparejan por compartir una semilla numérica.

La prueba M01 reutiliza el registro de contactos y decisiones de una corrida NetLogo para contrastar probabilidades, transiciones, estados y balances en Python bajo entradas controladas. No prueba equivalencia de los generadores ni identidad de trayectorias espontáneas. V03, V04 y V06 comprueban selección, rutas y seguimiento, y V14 comprueba reproducción exacta dentro de Python.

No se realizó calibración empírica. El piloto de 25 corridas permanece pendiente; la selección de lenguaje no cambia ese diseño.
