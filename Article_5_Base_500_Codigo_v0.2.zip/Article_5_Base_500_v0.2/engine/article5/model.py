"""Difusión WOM. El orden de eventos y la energía siguen la especificación v0.2."""
from array import array
from collections import Counter
from dataclasses import dataclass
import hashlib
import math
import random

from .config import Config
from .network import generate_network

EVENT_FIELDS = ['event_id', 'month', 'order', 'sender', 'receiver', 'slot', 'route', 'selected_tier',
                'fallback', 'strength', 'trust', 'cooperation', 'commitment', 'sender_community',
                'receiver_community', 'bridge', 'prior_exposures', 'sent', 'eligible_to_adopt',
                'p_send', 'p_adopt', 'adoption', 'energy_before', 'energy_after', 'root_id', 'receiver_generation']


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def send_probability(satisfaction, cooperation, config):
    return satisfaction * (config.c0 + (1 - config.c0) * cooperation)


def adoption_score(trust, prior, config):
    return config.a0 + config.bT * config.trust_weight * trust - config.gR * config.risk * (1 - config.trust_weight * trust) - config.bX * max(0, prior - 1)


def adoption_probability(need, fit, trust, prior, config):
    z = adoption_score(trust, prior, config)
    logistic = 1 / (1 + math.exp(-z)) if z >= 0 else math.exp(z) / (1 + math.exp(z))
    return need * fit * logistic


def route_for(strategy, month, uniform):
    if strategy in ('A', 'B', 'E'):
        return strategy
    if strategy not in ('C', 'D'):
        raise ValueError('Estrategia desconocida')
    probability = 0.5 if strategy == 'C' else (0.8 if month <= 12 else 0.3)
    return 'A' if uniform < probability else 'B'


class RandomTape:
    """Sorteos precomputados; ningún evento consume un generador global."""
    def __init__(self, config, network):
        self.population = config.population
        self.capacity = config.monthly_capacity
        self.pairs = tuple((i, j) for i, js in enumerate(network.adjacent) for j in js)
        self.pair_index = {pair: idx for idx, pair in enumerate(self.pairs)}
        rng = random.Random(config.seed_offset + 201)
        self.dynamic = array('d', (rng.random() for _ in range(config.horizon * config.population * config.monthly_capacity * 5)))
        self.follow = array('d', (rng.random() for _ in range(config.horizon * len(self.pairs))))

    def at(self, month, consumer, slot):
        offset = (((month - 1) * self.population + consumer) * self.capacity + slot) * 5
        return tuple(self.dynamic[offset:offset + 5])

    def follow_at(self, month, sender, receiver):
        return self.follow[(month - 1) * len(self.pairs) + self.pair_index[sender, receiver]]

    def signature(self):
        digest = hashlib.sha256()
        digest.update(self.dynamic.tobytes())
        digest.update(self.follow.tobytes())
        digest.update(repr(self.pairs).encode())
        return digest.hexdigest()


@dataclass
class Agent:
    agent_id: int
    community: int
    need: float
    fit: float
    seed: bool = False
    adopted: bool = False
    satisfaction: float = 0.0
    energy: int = 0
    eligible_from: int = 0
    exposures: int = 0
    first_exposure: int | None = None
    adoption_month: int | None = None
    parent_event: int | None = None
    parent_agent: int | None = None
    root_id: int = -1
    generation: int = -1
    attempts: int = 0
    sent: int = 0
    successes: int = 0


@dataclass(frozen=True)
class Attempt:
    sender: int
    receiver: int
    slot: int
    route: str
    tier: int
    uniforms: tuple[float, ...]
    energy_before: int


class Model:
    def __init__(self, config=None, network=None):
        self.config = (config or Config()).validate()
        c = self.config
        self.network = network if network is not None else generate_network(c)
        if len(self.network.communities) != c.population:
            raise ValueError('Población de la red incompatible con la configuración')
        self.agents = [Agent(i, group, self.network.needs[i], self.network.fits[i], eligible_from=c.horizon + 1)
                       for i, group in enumerate(self.network.communities)]
        for i in self.network.seeds:
            a = self.agents[i]
            a.seed = a.adopted = True
            a.satisfaction, a.energy, a.eligible_from = 0.9, c.initial_energy, 1
            a.adoption_month, a.root_id, a.generation = 0, i, 0
        self.tape = RandomTape(c, self.network)
        self.history, self.last_attempt = Counter(), {}
        self.events, self.periods, self.agent_periods, self.cascade_activity = [], [], [], []
        self.month = 0
        self.attempted_total = self.sent_total = self.new_total = self.repeated_total = self.eligible_sent_total = 0
        self.period_attempts = self.period_sends = self.period_adoptions = 0
        self.extinction_month = None
        self.record_period()

    def structural_targets(self, sender, adopted_snapshot):
        return [j for j in self.network.adjacent[sender] if j not in adopted_snapshot
                and self.history[sender, j] < 2
                and (self.history[sender, j] == 0 or self.network.edge(sender, j).commitment > 0)]

    def eligible_targets(self, sender, adopted_snapshot, month):
        return [j for j in self.structural_targets(sender, adopted_snapshot)
                if not self.history[sender, j] or
                (self.last_attempt[sender, j] < month and self.tape.follow_at(month, sender, j) < self.network.edge(sender, j).commitment)]

    def choose_target(self, sender, candidates, route, uniform):
        # candidates permanece ordenado por id; se sortea dentro del grupo elegido.
        if not 0 <= uniform < 1:
            raise ValueError('El sorteo debe pertenecer a [0,1)')
        edge = lambda j: self.network.edge(sender, j)
        groups = [candidates]
        if route == 'A':
            groups = [[j for j in candidates if edge(j).tie_class == 'strong'], candidates]
        elif route == 'B':
            groups = [[j for j in candidates if edge(j).tie_class == 'weak' and edge(j).bridge],
                      [j for j in candidates if edge(j).tie_class == 'weak' and not edge(j).bridge],
                      [j for j in candidates if edge(j).bridge], candidates]
        elif route != 'E':
            raise ValueError('Ruta desconocida')
        for tier, group in enumerate(groups):
            if group:
                return group[math.floor(uniform * len(group))], tier
        return None, None

    def reserve_attempt(self, sender, receiver, slot, route, tier, uniforms, month):
        a = self.agents[sender]
        if a.energy <= 0:
            raise ValueError('Intento sin energía')
        plan = Attempt(sender, receiver, slot, route, tier, uniforms, a.energy)
        a.energy -= 1
        a.attempts += 1
        self.history[sender, receiver] += 1
        self.last_attempt[sender, receiver] = month
        return plan

    def plan_period(self):
        c, month = self.config, self.month + 1
        adopted_snapshot = {a.agent_id for a in self.agents if a.adopted}
        planned = []
        for a in self.agents:
            if not (a.adopted and a.satisfaction >= c.satisfaction_threshold and a.energy > 0 and a.eligible_from <= month):
                continue
            candidates = self.eligible_targets(a.agent_id, adopted_snapshot, month)
            slot = 0
            while slot < c.monthly_capacity and a.energy > 0 and candidates:
                uniforms = self.tape.at(month, a.agent_id, slot)
                route = route_for(c.strategy, month, uniforms[0])
                receiver, tier = self.choose_target(a.agent_id, candidates, route, uniforms[1])
                planned.append(self.reserve_attempt(a.agent_id, receiver, slot, route, tier, uniforms, month))
                candidates.remove(receiver)
                slot += 1
        return sorted(planned, key=lambda p: (p.uniforms[4], p.sender * c.monthly_capacity + p.slot))

    def process_attempt(self, plan, month, order):
        c = self.config
        sender, receiver = self.agents[plan.sender], self.agents[plan.receiver]
        edge = self.network.edge(plan.sender, plan.receiver)
        ps = send_probability(sender.satisfaction, edge.cooperation, c)
        sent = plan.uniforms[2] < ps
        prior, pa = None, None
        eligible = adoption = False
        event_id = len(self.events)
        self.attempted_total += 1
        self.period_attempts += 1
        if sent:
            self.sent_total += 1
            self.period_sends += 1
            sender.sent += 1
            prior = receiver.exposures
            self.repeated_total += int(prior > 0)
            eligible = not receiver.adopted
            if prior == 0:
                receiver.first_exposure = month
            receiver.exposures += 1
            if eligible:
                self.eligible_sent_total += 1
                pa = adoption_probability(receiver.need, receiver.fit, edge.trust, prior, c)
                if plan.uniforms[3] < pa:
                    adoption = receiver.adopted = True
                    receiver.adoption_month = month
                    receiver.parent_event, receiver.parent_agent = event_id, sender.agent_id
                    receiver.root_id, receiver.generation = sender.root_id, sender.generation + 1
                    receiver.satisfaction = c.quality * (0.5 + 0.5 * receiver.fit)
                    if receiver.satisfaction >= c.satisfaction_threshold:
                        receiver.energy, receiver.eligible_from = c.initial_energy, month + 1
                    sender.successes += 1
                    self.new_total += 1
                    self.period_adoptions += 1
        self.events.append(dict(zip(EVENT_FIELDS, [event_id, month, order, sender.agent_id, receiver.agent_id,
            plan.slot, plan.route, plan.tier, plan.tier > 0, edge.strength, edge.trust, edge.cooperation,
            edge.commitment, sender.community, receiver.community, edge.bridge, prior, sent, eligible, ps, pa,
            adoption, plan.energy_before, plan.energy_before - 1, sender.root_id, receiver.generation])))

    def step(self):
        if self.month >= self.config.horizon:
            return False
        self.period_attempts = self.period_sends = self.period_adoptions = 0
        for order, plan in enumerate(self.plan_period()):
            self.process_attempt(plan, self.month + 1, order)
        self.month += 1
        self.record_period()
        return True

    def run(self):
        while self.step():
            pass
        return self

    def viable_ids(self):
        adopted = {a.agent_id for a in self.agents if a.adopted}
        return {a.agent_id for a in self.agents if a.adopted and a.energy > 0
                and a.satisfaction >= self.config.satisfaction_threshold
                and self.structural_targets(a.agent_id, adopted)}

    def state_name(self, agent, viable):
        if not agent.adopted:
            return 'aware' if agent.exposures else 'unaware'
        if agent.satisfaction < self.config.satisfaction_threshold:
            return 'customer'
        return 'active_promoter' if agent.agent_id in viable else 'inactive_promoter'

    def record_period(self):
        viable = self.viable_ids()
        active_roots = {self.agents[i].root_id for i in viable}
        self.cascade_activity.append((self.month, tuple(sorted(active_roots))))
        if not viable and self.extinction_month is None:
            self.extinction_month = self.month
        reach = sum(not a.seed and a.exposures > 0 for a in self.agents)
        exposed_communities = {a.community for a in self.agents if not a.seed and a.exposures > 0}
        adopted_communities = {a.community for a in self.agents if a.adopted}
        self.periods.append(dict(month=self.month, attempts=self.period_attempts, sent=self.period_sends,
            new_adoptions=self.period_adoptions, total_adoptions=sum(a.adopted for a in self.agents),
            cumulative_attempts=self.attempted_total, cumulative_sent=self.sent_total, unique_reach=reach,
            repeated_exposures=self.repeated_total, conversion=ratio(self.new_total, self.sent_total),
            coverage=ratio(reach, self.config.population - len(self.network.seeds)),
            redundancy=ratio(self.repeated_total, self.sent_total), communities_exposed=len(exposed_communities),
            communities_adopted=len(adopted_communities),
            new_communities_adopted=len(adopted_communities - set(self.config.seeded_communities)),
            active_promoters=len(viable), active_cascades=len(active_roots)))
        for a in self.agents:
            self.agent_periods.append(dict(month=self.month, agent_id=a.agent_id, community=a.community,
                state=self.state_name(a, viable), need=a.need, fit=a.fit, exposures=a.exposures,
                first_exposure=a.first_exposure, adoption_month=a.adoption_month, satisfaction=a.satisfaction,
                energy=a.energy, attempts=a.attempts, sent=a.sent, successes=a.successes,
                parent_event=a.parent_event, parent_agent=a.parent_agent, root_id=a.root_id,
                generation=a.generation, eligible_from=a.eligible_from, seed=a.seed))

    def cascades(self):
        rows = []
        for root in self.network.seeds:
            descendants = [a for a in self.agents if a.adopted and not a.seed and a.root_id == root]
            evs = [e for e in self.events if e['root_id'] == root and e['sent']]
            ads = [e for e in evs if e['adoption']]
            extinct_month = next((m for m, roots in self.cascade_activity if root not in roots), None)
            rows.append(dict(root_id=root, size=len(descendants), depth=max((a.generation for a in descendants), default=0),
                communities_exposed=len({e['receiver_community'] for e in evs}),
                communities_adopted=len({self.agents[root].community} | {a.community for a in descendants}),
                first_send_month=evs[0]['month'] if evs else None,
                first_adoption_month=ads[0]['month'] if ads else None,
                last_send_month=evs[-1]['month'] if evs else None,
                last_adoption_month=ads[-1]['month'] if ads else None,
                extinct=extinct_month is not None, extinction_month=extinct_month,
                observed_duration=self.month if extinct_month is None else extinct_month))
        return rows

    def summary(self):
        final = self.periods[-1]
        ext = self.extinction_month
        row = dict(attempts=self.attempted_total, sent=self.sent_total, new_adoptions=self.new_total,
            total_adoptions=final['total_adoptions'],
            adoption_at_12=self.periods[12]['total_adoptions'] if self.month >= 12 else None,
            unique_reach=final['unique_reach'], repeated_exposures=self.repeated_total,
            conversion=ratio(self.new_total, self.sent_total), effort_efficiency=ratio(self.new_total, self.attempted_total),
            eligible_sent=self.eligible_sent_total, eligible_conversion=ratio(self.new_total, self.eligible_sent_total),
            extinction_month=ext, early_extinction=ext is not None and ext <= 12)
        for fraction in (0.1, 0.25, 0.5):
            month = next((p['month'] for p in self.periods if p['total_adoptions'] >= fraction * self.config.population), None)
            row.update({f'time_{fraction}': month, f'event_{fraction}': month is not None,
                        f'observed_{fraction}': self.month if month is None else month})
        for name in ('coverage', 'redundancy', 'communities_exposed', 'communities_adopted',
                     'new_communities_adopted', 'active_promoters', 'active_cascades'):
            row[name] = final[name]
        sends, adoptions = [e for e in self.events if e['sent']], [e for e in self.events if e['adoption']]
        row.update(coverage_denominator=self.config.population - len(self.network.seeds),
                   last_send_month=sends[-1]['month'] if sends else None,
                   last_adoption_month=adoptions[-1]['month'] if adoptions else None,
                   extinction_event=ext is not None, observed_duration=self.month if ext is None else ext)
        return row

    def metadata(self):
        c = self.config
        return dict(run_id=f'{c.experiment_id}_r{c.repetition}_{c.strategy}_risk{c.risk}_mu{c.mu}',
                    experiment_id=c.experiment_id, repetition_id=c.repetition, strategy=c.strategy,
                    risk=c.risk, mu=c.mu, model_version='0.2', network_id=self.network.network_id,
                    configuration_version='0.2')

    def parameters(self):
        c = self.config
        values = c.to_dict() | dict(seed_offset=c.seed_offset, network_seed=c.seed_offset + self.network.accepted_candidate,
            attribute_seed=c.seed_offset + 100 + self.network.accepted_candidate,
            seed_selection_seed=c.seed_offset + 200, dynamics_seed=c.seed_offset + 201,
            consumer_seed=c.seed_offset + 202, initial_seeds=len(self.network.seeds), seed_ids=list(self.network.seeds))
        return [dict(parameter=k, value=v) for k, v in values.items()]
