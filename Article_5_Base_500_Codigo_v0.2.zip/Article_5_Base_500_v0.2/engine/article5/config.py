"""Parámetros experimentales, sin calibración empírica."""
from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class Config:
    population: int = 600
    communities: int = 6
    community_size: int = 100
    expected_degree: float = 10.0
    mu: float = 0.20
    horizon: int = 60
    repetition: int = 1
    strategy: str = "A"
    seed_base: int = 20260925
    rho: float = 0.70
    inactive_cut: float = 0.05
    weak_share: float = 0.30
    strong_share: float = 0.30
    quality: float = 0.90
    risk: float = 0.50
    initial_energy: int = 4
    monthly_capacity: int = 2
    seeds_per_community: int = 6
    seeded_communities: tuple[int, ...] = (0, 1)
    satisfaction_threshold: float = 0.70
    c0: float = 0.20
    a0: float = -0.50
    bT: float = 3.0
    gR: float = 2.0
    bX: float = 0.50
    trust_weight: float = 1.0
    min_active_giant: int = 570
    max_candidates: int = 100
    experiment_id: str = "verification_python"

    @property
    def seed_offset(self):
        return self.seed_base + 1000 * (self.repetition - 1)

    def validate(self):
        integers = ('population', 'communities', 'community_size', 'horizon', 'repetition',
                    'seed_base', 'initial_energy', 'monthly_capacity', 'seeds_per_community',
                    'min_active_giant', 'max_candidates')
        for name in integers:
            if type(getattr(self, name)) is not int:
                raise ValueError(f'{name} debe ser entero')
        if self.population != self.communities * self.community_size:
            raise ValueError('Población y tamaños de comunidades no coinciden')
        if min(self.communities, self.community_size) < 2:
            raise ValueError('Se requieren al menos dos comunidades de dos agentes')
        if min(self.horizon, self.repetition, self.monthly_capacity, self.max_candidates) < 1:
            raise ValueError('Horizonte, repetición, capacidad y candidatos deben ser positivos')
        if self.max_candidates > 100:
            raise ValueError('Máximo 100 candidatos para conservar bloques de semillas separados')
        if self.initial_energy < 0 or not 0 <= self.min_active_giant <= self.population:
            raise ValueError('Energía o conectividad mínima inválidas')
        for name in ('mu', 'rho', 'inactive_cut', 'weak_share', 'strong_share', 'quality',
                     'risk', 'satisfaction_threshold', 'c0', 'trust_weight'):
            value = getattr(self, name)
            if not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f'{name} debe pertenecer a [0,1]')
        for name in ('expected_degree', 'bT', 'gR', 'bX'):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f'{name} debe ser finito y no negativo')
        if not math.isfinite(self.a0):
            raise ValueError('a0 debe ser finito')
        if self.weak_share + self.strong_share > 1:
            raise ValueError('Las clases de fuerza no pueden superponerse')
        if self.strategy not in ('A', 'B', 'C', 'D', 'E'):
            raise ValueError('Estrategia desconocida')
        if len(set(self.seeded_communities)) != len(self.seeded_communities):
            raise ValueError('Comunidades sembradas duplicadas')
        if any(type(c) is not int or not 0 <= c < self.communities for c in self.seeded_communities):
            raise ValueError('Comunidad sembrada inexistente')
        if not 0 <= self.seeds_per_community <= self.community_size:
            raise ValueError('Número de semillas por comunidad inválido')
        if self.expected_degree * (1 - self.mu) / (self.community_size - 1) > 1 or self.expected_degree * self.mu / (self.population - self.community_size) > 1:
            raise ValueError('Probabilidad de enlace mayor que uno')
        if not self.experiment_id or any(c in self.experiment_id for c in '/\\'):
            raise ValueError('experiment_id debe ser un identificador simple')
        return self

    def to_dict(self):
        return asdict(self)

    def save(self, path):
        Path(path).write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    @classmethod
    def load(cls, path):
        data = json.loads(Path(path).read_text(encoding='utf-8'))
        if 'seeded_communities' in data:
            data['seeded_communities'] = tuple(data['seeded_communities'])
        return cls(**data).validate()
