"""CSV UTF-8, manifiestos y huellas para conservar la procedencia."""
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import tempfile

from .model import EVENT_FIELDS
from .network import Edge, correlations, diagnostics


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def csv_value(value):
    if value is None:
        return 'NA'
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (list, tuple, dict)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    return value


def write_csv(path, rows, fields=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0]) if rows else []
    # Publicar solo archivos completos, aun si una ejecución se interrumpe.
    with tempfile.NamedTemporaryFile('w', dir=path.parent, prefix=path.name + '.', suffix='.pending',
                                     encoding='utf-8', newline='', delete=False) as handle:
        temporary = Path(handle.name)
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: csv_value(row[k]) for k in fields} for row in rows)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def export_run(model, folder, prefix, purpose='technical_verification'):
    if not prefix or '/' in prefix or '\\' in prefix:
        raise ValueError('El prefijo debe ser un nombre de archivo simple')
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    network, metadata = model.network, model.metadata()
    datasets = {
        'nodes': (network.node_records(), ['agent_id', 'community', 'need', 'fit', 'initial_promoter']),
        'edges': (network.edge_records(), list(Edge.__dataclass_fields__)),
        'events': (model.events, EVENT_FIELDS),
        'system_period': (model.periods, None),
        'agent_period': (model.agent_periods, None),
        'cascades': (model.cascades(), ['root_id', 'size', 'depth', 'communities_exposed', 'communities_adopted',
                     'first_send_month', 'first_adoption_month', 'last_send_month', 'last_adoption_month',
                     'extinct', 'extinction_month', 'observed_duration']),
        'run_summary': ([model.summary()], None),
        'network_diagnostics': ([diagnostics(network, False), diagnostics(network, True)], None),
        'network_candidates': (list(network.candidate_log), ['candidate', 'network_seed', 'active_giant_component', 'accepted']),
        'parameters': (model.parameters(), ['parameter', 'value']),
        'relationship_correlations': (correlations(network), None),
    }
    output_hashes = {}
    for name, (rows, fields) in datasets.items():
        fields = fields if fields is not None else list(rows[0])
        path = folder / f'{prefix}_{name}.csv'
        write_csv(path, [metadata | row for row in rows], list(metadata) + fields)
        output_hashes[path.name] = sha256(path)
    project = Path(__file__).resolve().parent.parent
    source_hashes = {str(p.relative_to(project)): sha256(p) for p in sorted(project.rglob('*'))
                     if p.is_file() and p.suffix in ('.py', '.json') and not {'outputs', '__pycache__'} & set(p.relative_to(project).parts)}
    manifest = dict(execution_utc=datetime.now(timezone.utc).isoformat(), purpose=purpose,
                    empirical_calibration=False, metadata=metadata, config=model.config.to_dict(),
                    seeds={r['parameter']: r['value'] for r in model.parameters() if 'seed' in r['parameter']},
                    python_version=platform.python_version(), platform=platform.platform(),
                    random_generator='random.Random; MT19937; Gamma ratio for Beta; no NetLogo seed equivalence',
                    random_draw_order=['month', 'consumer_id', 'attempt_slot', 'route,target,send,adopt,order'],
                    followup_draw_order=['month', 'sender_id', 'receiver_id'],
                    tape_sha256=model.tape.signature(), tape_byte_order=sys.byteorder,
                    network_content_sha256=network.signature(), source_sha256=source_hashes,
                    output_sha256=output_hashes)
    path = folder / f'{prefix}_run_manifest.json'
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return path
