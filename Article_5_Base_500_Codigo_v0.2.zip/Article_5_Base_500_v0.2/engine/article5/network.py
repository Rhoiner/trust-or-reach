"""Red de bloques, atributos y diagnósticos sin dependencias externas."""
from dataclasses import asdict, dataclass, replace
import hashlib
import itertools
import json
import math
import random
import statistics

from .config import Config


@dataclass(frozen=True)
class Edge:
    source: int
    target: int
    strength: float
    trust: float
    cooperation: float
    commitment: float
    active: bool
    bridge: bool
    tie_class: str


@dataclass
class Network:
    communities: tuple[int, ...]
    needs: tuple[float, ...]
    fits: tuple[float, ...]
    seeds: tuple[int, ...]
    edges: dict[tuple[int, int], Edge]
    network_id: str
    accepted_candidate: int = 0
    candidate_log: tuple[dict, ...] = ()

    def __post_init__(self):
        n = len(self.communities)
        if not len(self.needs) == len(self.fits) == n or n == 0:
            raise ValueError('Atributos de consumidores incompatibles')
        if len(set(self.seeds)) != len(self.seeds) or any(i not in range(n) for i in self.seeds):
            raise ValueError('Promotores iniciales inválidos')
        if any(not 0 <= x <= 1 for x in self.needs + self.fits):
            raise ValueError('Necesidad/ajuste fuera de [0,1]')
        adjacent = [[] for _ in range(n)]
        for key, edge in self.edges.items():
            i, j = key
            if not 0 <= i < j < n or key != (edge.source, edge.target):
                raise ValueError('Enlace inválido')
            if edge.bridge != (self.communities[i] != self.communities[j]):
                raise ValueError('Puente incoherente')
            if any(not 0 <= x <= 1 for x in (edge.strength, edge.trust, edge.cooperation, edge.commitment)):
                raise ValueError('Atributo de enlace fuera de [0,1]')
            if edge.active:
                adjacent[i].append(j)
                adjacent[j].append(i)
        self.adjacent = tuple(tuple(sorted(js)) for js in adjacent)

    def edge(self, i, j):
        return self.edges[min(i, j), max(i, j)]

    def node_records(self):
        return [dict(agent_id=i, community=c, need=self.needs[i], fit=self.fits[i], initial_promoter=i in self.seeds)
                for i, c in enumerate(self.communities)]

    def edge_records(self):
        return [asdict(self.edges[k]) for k in sorted(self.edges)]

    def signature(self):
        content = [self.node_records(), self.edge_records()]
        return hashlib.sha256(json.dumps(content, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

    @classmethod
    def from_records(cls, nodes, edges, network_id='fixed_input'):
        nodes = sorted(nodes, key=lambda r: r['agent_id'])
        if [r['agent_id'] for r in nodes] != list(range(len(nodes))):
            raise ValueError('Se requieren identificadores consecutivos desde cero')
        fields = tuple(Edge.__dataclass_fields__)
        parsed = [Edge(**{k: r[k] for k in fields}) for r in edges]
        keyed = {(e.source, e.target): e for e in parsed}
        if len(keyed) != len(parsed):
            raise ValueError('Enlace duplicado')
        return cls(tuple(r['community'] for r in nodes), tuple(r['need'] for r in nodes),
                   tuple(r['fit'] for r in nodes), tuple(r['agent_id'] for r in nodes if r['initial_promoter']),
                   keyed, network_id)


def components(adjacent):
    remaining = set(range(len(adjacent)))
    result = []
    while remaining:
        root = min(remaining)
        remaining.remove(root)
        stack, found = [root], {root}
        while stack:
            for j in adjacent[stack.pop()]:
                if j in remaining:
                    remaining.remove(j)
                    found.add(j)
                    stack.append(j)
        result.append(found)
    return result


def classify(edges, config):
    ranked = sorted((e for e in edges.values() if e.active), key=lambda e: (e.strength, e.source, e.target))
    nw = math.floor(config.weak_share * len(ranked))
    ns = math.floor(config.strong_share * len(ranked))
    for idx, e in enumerate(ranked):
        kind = 'weak' if idx < nw else 'strong' if idx >= len(ranked) - ns else 'intermediate'
        edges[e.source, e.target] = replace(e, tie_class=kind)


def generate_network(config: Config):
    c = config.validate()
    groups = tuple(i // c.community_size for i in range(c.population))
    consumer_rng = random.Random(c.seed_offset + 202)
    attributes = [(0.5 + 0.5 * consumer_rng.random(), 0.5 + 0.5 * consumer_rng.random()) for _ in groups]
    candidate_log = []
    for candidate in range(c.max_candidates):
        topology_rng = random.Random(c.seed_offset + candidate)
        relation_rng = random.Random(c.seed_offset + 100 + candidate)
        edges = {}
        for i in range(c.population):
            for j in range(i + 1, c.population):
                bridge = groups[i] != groups[j]
                probability = c.expected_degree * c.mu / (c.population - c.community_size) if bridge else c.expected_degree * (1 - c.mu) / (c.community_size - 1)
                if topology_rng.random() >= probability:
                    continue
                a, b = (2, 5) if bridge else (5, 2)
                x, y = relation_rng.gammavariate(a, 1), relation_rng.gammavariate(b, 1)
                strength = x / (x + y)
                trust, cooperation, commitment = [c.rho * strength + (1 - c.rho) * relation_rng.random() for _ in range(3)]
                edges[i, j] = Edge(i, j, strength, trust, cooperation, commitment,
                                   strength >= c.inactive_cut, bridge, 'inactive')
        network = Network(groups, tuple(a[0] for a in attributes), tuple(a[1] for a in attributes), (), edges,
                          f'py_r{c.repetition}_mu{c.mu}_candidate{candidate}', candidate)
        giant = max(map(len, components(network.adjacent)))
        accepted = giant >= c.min_active_giant
        candidate_log.append(dict(candidate=candidate, network_seed=c.seed_offset + candidate,
                                  active_giant_component=giant, accepted=accepted))
        if accepted:
            break
    else:
        raise RuntimeError('Ningún candidato cumple el criterio estructural de conectividad')
    classify(network.edges, c)
    seed_rng = random.Random(c.seed_offset + 200)
    seeds = []
    for group in c.seeded_communities:
        pool = [i for i, g in enumerate(groups) if g == group]
        for _ in range(c.seeds_per_community):
            seeds.append(pool.pop(seed_rng.randrange(len(pool))))
    network.seeds = tuple(sorted(seeds))
    network.candidate_log = tuple(candidate_log)
    return network


def diagnostics(network, active_only):
    n = len(network.communities)
    edges = [e for e in network.edges.values() if not active_only or e.active]
    adjacent = [set() for _ in range(n)]
    for e in edges:
        adjacent[e.source].add(e.target)
        adjacent[e.target].add(e.source)
    degrees = [len(js) for js in adjacent]
    m = len(edges)
    clusters = components(adjacent)
    q = 0.0
    if m:
        for group in sorted(set(network.communities)):
            internal = sum(network.communities[e.source] == group and network.communities[e.target] == group for e in edges)
            volume = sum(degrees[i] for i, g in enumerate(network.communities) if g == group)
            q += internal / m - (volume / (2 * m)) ** 2
    coefficients = [sum(v in adjacent[u] for u, v in itertools.combinations(js, 2)) / math.comb(len(js), 2) if len(js) >= 2 else 0.0 for js in adjacent]
    return dict(active_only=active_only, edges=m, mean_degree=sum(degrees) / n,
                density=2 * m / (n * (n - 1)), components=len(clusters),
                giant_component=max(map(len, clusters)), bridges=sum(e.bridge for e in edges),
                bridge_share=sum(e.bridge for e in edges) / m if m else None,
                modularity=q, mean_clustering=sum(coefficients) / n, degrees=degrees)


def correlations(network):
    rows = []
    for scope in ('all', 'active'):
        edges = [e for e in network.edges.values() if scope == 'all' or e.active]
        for a, b in itertools.combinations(('strength', 'trust', 'cooperation', 'commitment'), 2):
            try:
                r = statistics.correlation([getattr(e, a) for e in edges], [getattr(e, b) for e in edges])
            except statistics.StatisticsError:
                r = None
            rows.append(dict(scope=scope, attribute_1=a, attribute_2=b, n=len(edges), pearson_r=r))
    return rows
