"""Modelo académico Article 5; biblioteca estándar de Python."""
from .config import Config
from .model import Model

__version__ = "0.2"
__all__ = ["Config", "Model"]
