#!/usr/bin/env python3
"""Análisis reproducible de la comparación base; remuestreo de bloques completos."""
from collections import Counter
import csv
import itertools
import json
from pathlib import Path
import platform
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'engine'))
from article5.io import write_csv, sha256
from tests.audit_exports import read
from run_base500 import verify_manifest, save_json

TABLES = ROOT / 'outputs/tables'
FIGURES = ROOT / 'outputs/figures'
STRATEGIES = list('ABCDE')
LABELS = dict(A='Fuerte', B='Débil / puente', C='Balanceada', D='Secuencial', E='Aleatoria')
METRICS = ['new_adoptions', 'total_adoptions', 'adoption_at_12', 'attempts', 'sent', 'unique_reach',
           'coverage', 'conversion', 'eligible_conversion', 'effort_efficiency', 'redundancy',
           'new_communities_adopted', 'communities_exposed', 'fallback_rate', 'extinction_month',
           'early_extinction', 'viable_after_12', 'attempts_after_12', 'adoptions_after_12',
           'max_cascade_size', 'max_cascade_depth']
PAIR_METRICS = ['new_adoptions', 'coverage', 'conversion', 'effort_efficiency', 'redundancy',
                'new_communities_adopted', 'early_extinction']


def stats(a):
    a = np.asarray([x for x in a if x is not None], dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return dict(n=0, mean=None, sd=None, median=None, minimum=None, maximum=None,
                    q1=None, q3=None, iqr=None, p05=None, p95=None)
    q = np.quantile(a, [.05, .25, .50, .75, .95], method='linear')
    return dict(n=int(len(a)), mean=float(a.mean()), sd=float(a.std(ddof=1)) if len(a)>1 else None,
                median=float(q[2]), minimum=float(a.min()), maximum=float(a.max()),
                q1=float(q[1]), q3=float(q[3]), iqr=float(q[3]-q[1]), p05=float(q[0]), p95=float(q[4]))


def interval(a):
    a = np.asarray(a)
    a = a[np.isfinite(a)]
    if not len(a):
        return dict(ci95_low=None, ci95_high=None, bootstrap_valid=0)
    q = np.quantile(a, [.025, .975], method='linear')
    return dict(ci95_low=float(q[0]), ci95_high=float(q[1]), bootstrap_valid=int(len(a)))


def nondominated(points):
    # Ambas dimensiones se maximizan. Igualdad no implica dominación estricta.
    return np.array([not any(np.all(q >= p) and np.any(q > p) for q in points) for p in points])


def main():
    completion_path = ROOT / 'outputs/checks/base500_completion.json'
    completion = json.loads(completion_path.read_text())
    design = json.loads((ROOT / 'design/base500_design.json').read_text())
    assert completion['status'] == 'PASS' and completion['completed_runs'] == 500
    assert completion['runner_sha256'] == sha256(ROOT / 'run_base500.py')
    assert completion['design_sha256'] == sha256(ROOT / 'design/base500_design.json')
    data = read(TABLES / 'run_summary_500.csv')
    assert len(data) == 500
    by_key = {(r['repetition_id'], r['strategy']): r for r in data}
    assert len(by_key) == 500
    for rep in range(1, 101):
        for s in STRATEGIES:
            prefix = f'r{rep:03d}_{s}'
            receipt_path = ROOT / 'outputs/checks' / f'{prefix}_audit.json'
            assert sha256(receipt_path) == completion['receipt_sha256'][receipt_path.name]
            receipt = json.loads(receipt_path.read_text())
            manifest_path = ROOT / 'outputs/raw' / prefix / f'{prefix}_run_manifest.json'
            assert sha256(manifest_path) == receipt['manifest_sha256']
            verify_manifest(manifest_path)
            assert all(by_key[rep, s][k] == v for k, v in receipt['result'].items()
                       if k not in ('model_version', 'configuration_version'))

    # Un único conjunto de índices de bloques se utiliza en todas las comparaciones.
    rng = np.random.default_rng(design['analysis_seed'])
    indices = rng.integers(0, 100, size=(design['analysis_bootstrap_replicates'], 100))
    assert indices.shape == (2000, 100)
    write_csv(TABLES / 'bootstrap_block_indices.csv',
              [dict(bootstrap_id=i+1, **{f'draw_{j+1:03d}':int(rep)+1 for j, rep in enumerate(row)})
               for i, row in enumerate(indices)])
    arrays = {}
    boots = {}
    descriptives = []
    for metric in METRICS:
        a = np.array([[np.nan if by_key[rep, s][metric] is None else by_key[rep, s][metric]
                       for s in STRATEGIES] for rep in range(1,101)], dtype=float)
        arrays[metric] = a
        boot = np.nanmean(a[indices], axis=1)
        boots[metric] = boot
        for j, s in enumerate(STRATEGIES):
            descriptives.append(dict(strategy=s, metric=metric, **stats(a[:,j]), **interval(boot[:,j])))
    write_csv(TABLES / 'descriptive_statistics.csv', descriptives)
    lookup = {(r['strategy'],r['metric']):r for r in descriptives}
    paired = []
    paired_summary = []
    for left, right in itertools.combinations(range(5), 2):
        for metric in PAIR_METRICS:
            a = arrays[metric]
            delta = a[:,right] - a[:,left]  # Solo pares con ambas tasas definidas.
            bd = np.nanmean(delta[indices], axis=1)
            for rep, value in enumerate(delta,1):
                paired.append(dict(repetition_id=rep, contrast=f'{STRATEGIES[right]}-{STRATEGIES[left]}',
                                   metric=metric, delta_right_minus_left=None if np.isnan(value) else float(value)))
            paired_summary.append(dict(contrast=f'{STRATEGIES[right]}-{STRATEGIES[left]}', metric=metric,
                                       **stats(delta), **interval(bd), positive=int(np.sum(delta>0)),
                                       zero=int(np.sum(delta==0)), negative=int(np.sum(delta<0))))
    write_csv(TABLES / 'paired_differences.csv', paired)
    write_csv(TABLES / 'paired_summary.csv', paired_summary)

    survival = []
    for s in STRATEGIES:
        g=[r for r in data if r['strategy']==s]
        early=lookup[s,'early_extinction']
        survival.append(dict(strategy=s, runs=100, extinct_by_12=sum(r['early_extinction'] for r in g),
                             early_extinction_rate=early['mean'], early_ci_low=early['ci95_low'], early_ci_high=early['ci95_high'],
                             viable_at_end_12=sum(r['viable_after_12'] for r in g),
                             runs_with_attempts_after_12=sum(r['attempts_after_12']>0 for r in g),
                             attempts_after_12=sum(r['attempts_after_12'] for r in g),
                             adoptions_after_12=sum(r['adoptions_after_12'] for r in g),
                             observed_extinctions=sum(r['extinction_event'] for r in g),
                             censored_at_60=sum(not r['extinction_event'] for r in g)))
    write_csv(TABLES / 'survival_at_12.csv', survival)
    dcols=['repetition_id','active_promoters_at_12','active_cascades_at_12','extinction_month',
           'attempts_after_12','sent_after_12','adoptions_after_12','route_A_after_12','route_B_after_12']
    write_csv(TABLES / 'strategy_D_phase2.csv', [{k:r[k] for k in dcols} for r in data if r['strategy']=='D'])

    attainment = []
    for s in STRATEGIES:
        for threshold in ['0.1','0.25','0.5']:
            g=[by_key[rep,s] for rep in range(1,101)]
            reached=np.array([r[f'event_{threshold}'] for r in g],dtype=float)
            attainment.append(dict(strategy=s, threshold=float(threshold), reached=int(reached.sum()), runs=100,
                                   fraction=float(reached.mean()), **interval(reached[indices].mean(axis=1)),
                                   **{f'time_among_reached_{k}':v for k,v in stats([r[f'time_{threshold}'] for r in g]).items()}))
    write_csv(TABLES / 'threshold_attainment.csv', attainment)

    profiles=[]
    selection=[]
    networks=[]
    periods=[]
    for r in data:
        rep,s=r['repetition_id'],r['strategy']
        p=f'r{rep:03d}_{s}'
        folder=ROOT/'outputs/raw'/p
        profiles.append({k:r[k] for k in ['repetition_id','strategy','attempts','fallback_attempts','fallback_rate']} |
                        {f'fraction_{c}':r[f'attempts_{c}']/r['attempts'] if r['attempts'] else None
                         for c in ['strong','weak','intermediate','bridge']})
        events=read(folder/f'{p}_events.csv')
        edges={(x['source'],x['target']):x for x in read(folder/f'{p}_edges.csv')}
        for phase,ev in [('all',events),('1_12',[e for e in events if e['month']<=12]),('13_60',[e for e in events if e['month']>=13])]:
            for tie in ['strong','weak','intermediate']:
                subset=[e for e in ev if edges[min(e['sender'],e['receiver']),max(e['sender'],e['receiver'])]['tie_class']==tie]
                sent=sum(e['sent'] for e in subset)
                new=sum(e['adoption'] for e in subset)
                selection.append(dict(repetition_id=rep,strategy=s,phase=phase,tie_class=tie,attempts=len(subset),
                                      sent=sent,new_adoptions=new,conversion=new/sent if sent else None))
        for x in read(folder/f'{p}_system_period.csv'):
            periods.append({k:x[k] for k in ['repetition_id','strategy','month','total_adoptions','coverage','conversion',
                                            'active_promoters','new_communities_adopted']} |
                           dict(cumulative_new_adoptions=x['total_adoptions']-12))
        if s=='A':
            for x in read(folder/f'{p}_network_diagnostics.csv'):
                networks.append({k:x[k] for k in ['repetition_id','active_only','edges','mean_degree','density','components',
                                                 'giant_component','bridges','bridge_share','modularity','mean_clustering']} |
                                dict(accepted_candidate=r['accepted_candidate']))
    write_csv(TABLES/'realized_selection_profiles.csv',profiles)
    write_csv(TABLES/'conversion_by_actual_tie_class.csv',selection)
    write_csv(TABLES/'network_diagnostics_100.csv',networks)
    write_csv(TABLES/'system_trajectories_500.csv',periods)
    # Las fases '1_12' y '13_60' son etiquetas. int() acepta guiones bajos,
    # por lo que el lector numérico genérico no debe aplicarse a esta columna.
    with (TABLES/'selection_tiers.csv').open(encoding='utf-8',newline='') as handle:
        tier_rows=[dict(strategy=r['strategy'],phase=r['phase'],requested_route=r['requested_route'],
                        selected_tier=int(r['selected_tier']),attempts=int(r['attempts']),
                        route_attempts=int(r['route_attempts']),
                        fraction=None if r['fraction']=='NA' else float(r['fraction']))
                   for r in csv.DictReader(handle)]
    tier_groups={}
    for r in tier_rows:
        key=tuple(r[k] for k in ['strategy','phase','requested_route','selected_tier'])
        tier_groups.setdefault(key,[]).append(r)
    tier_summary=[]
    for key,rows in sorted(tier_groups.items()):
        num=sum(r['attempts'] for r in rows);den=sum(r['route_attempts'] for r in rows)
        tier_summary.append(dict(zip(['strategy','phase','requested_route','selected_tier'],key)) |
                            dict(attempts_pooled=num,route_attempts_pooled=den,fraction_pooled=num/den if den else None) |
                            stats([r['fraction'] for r in rows]))
    write_csv(TABLES/'selection_tier_summary.csv',tier_summary)

    # Frontera finita entre las cinco estrategias; incertidumbre de las medias por bootstrap.
    point=np.stack([np.nanmean(arrays['coverage'],axis=0),np.nanmean(arrays['conversion'],axis=0)],axis=1)
    valid=np.all(np.isfinite(arrays['coverage']) & np.isfinite(arrays['conversion']),axis=1)
    observed_nd=nondominated(point)
    bpoints=np.stack([boots['coverage'],boots['conversion']],axis=2)
    bootstrap_nd=np.array([nondominated(p) for p in bpoints])
    raw_nd=np.array([nondominated(np.stack([arrays['coverage'][i],arrays['conversion'][i]],axis=1)) for i in np.where(valid)[0]])
    frontier=[dict(strategy=s,coverage_mean=float(point[j,0]),conversion_mean=float(point[j,1]),
                   nondominated_mean=bool(observed_nd[j]),bootstrap_mean_nondominated_fraction=float(bootstrap_nd[:,j].mean()),
                   run_nondominated_fraction=float(raw_nd[:,j].mean()),complete_blocks=int(valid.sum())) for j,s in enumerate(STRATEGIES)]
    write_csv(TABLES/'finite_trust_reach_frontier.csv',frontier)
    write_csv(TABLES/'bootstrap_frontier_points.csv', [dict(bootstrap_id=b+1,strategy=s,coverage=float(bpoints[b,j,0]),
                                                         conversion=float(bpoints[b,j,1]),nondominated=bool(bootstrap_nd[b,j]))
                                                     for b in range(2000) for j,s in enumerate(STRATEGIES)])

    trajectory=[]
    for s in STRATEGIES:
        for month in range(61):
            selected=[r for r in periods if r['strategy']==s and r['month']==month]
            for metric in ['cumulative_new_adoptions','coverage','active_promoters','new_communities_adopted']:
                trajectory.append(dict(strategy=s,month=month,metric=metric,**stats([r[metric] for r in selected])))
    write_csv(TABLES/'trajectory_summary.csv',trajectory)
    headline=[]
    for s in STRATEGIES:
        a=lookup[s,'new_adoptions'];c=lookup[s,'coverage'];v=lookup[s,'conversion']
        headline.append(dict(strategy=s,new_adoptions_mean=a['mean'],new_adoptions_median=a['median'],new_adoptions_sd=a['sd'],
                             new_adoptions_ci_low=a['ci95_low'],new_adoptions_ci_high=a['ci95_high'],
                             coverage_mean=c['mean'],conversion_mean=v['mean'],early_extinction_rate=lookup[s,'early_extinction']['mean']))
    write_csv(TABLES/'headline_results.csv',headline)
    plot(data,arrays,lookup,boots,frontier,trajectory)
    from make_report import make_report
    make_report(data,lookup,paired_summary,survival,frontier,networks,completion,design)
    import matplotlib
    generated=sorted(TABLES.glob('*.csv'))+sorted(FIGURES.glob('*'))+[ROOT/'outputs/Article_5_Informe_base_500_v0.2.md']
    save_json(ROOT/'outputs/analysis_manifest.json',dict(experiment_id=design['experiment_id'],independent_blocks=100,
              bootstrap_replicates=2000,bootstrap_seed=20261001,bootstrap_generator='numpy.default_rng / PCG64',
              interval_method='percentile 2.5% and 97.5%; linear interpolation; pointwise, no multiplicity adjustment',
              rates='unweighted mean of run-level ratios unless explicitly marked pooled',
              python_version=platform.python_version(),numpy_version=np.__version__,matplotlib_version=matplotlib.__version__,
              script_sha256={p:sha256(ROOT/p) for p in ['analyze_base500.py','make_report.py']},
              completion_sha256=sha256(completion_path),output_sha256={str(p.relative_to(ROOT)):sha256(p) for p in generated}))
    print(json.dumps(dict(status='PASS',runs=500,blocks=100,headline=headline,survival=survival,frontier=frontier),indent=2))


def plot(data,arrays,lookup,boots,frontier,trajectory):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    FIGURES.mkdir(parents=True,exist_ok=True)
    colors=dict(zip(STRATEGIES,['#0072B2','#D55E00','#009E73','#CC79A7','#666666']))
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':200})
    fig,axes=plt.subplots(1,3,figsize=(12,4.5))
    jitter=np.random.default_rng(260927).uniform(-.17,.17,size=(100,5))
    for ax,m,title,pct in zip(axes,['new_adoptions','coverage','conversion'],['Nuevas adopciones','Cobertura por WOM','Conversión'],[False,True,True]):
        for j,s in enumerate(STRATEGIES):
            values=arrays[m][:,j];v=values[np.isfinite(values)]
            ax.scatter(j+jitter[:,j],values,s=11,alpha=.25,color=colors[s],edgecolors='none')
            ax.boxplot([v],positions=[j],widths=.36,showfliers=False,patch_artist=False,
                       medianprops=dict(color='black',lw=1.6),boxprops=dict(color=colors[s]))
            d=lookup[s,m]
            ax.errorbar(j+.26,d['mean'],yerr=[[d['mean']-d['ci95_low']],[d['ci95_high']-d['mean']]],
                        fmt='D',ms=4,color='black',capsize=3)
        ax.set_xticks(range(5),STRATEGIES);ax.set_title(title,fontweight='bold');ax.set_ylim(bottom=0);ax.grid(axis='y',alpha=.16)
        if pct:ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
    fig.suptitle('Comparación base: 100 repeticiones por estrategia',fontweight='bold')
    fig.text(.5,.045,'Puntos: corridas · Caja: cuartiles y mediana · Rombo: media e IC 95% bootstrap',ha='center',fontsize=9)
    fig.text(.5,.005,'A fuerte · B débil / puente · C balanceada · D secuencial · E aleatoria',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.09,1,.95));savefig(fig,'distribuciones_base500')

    fig,ax=plt.subplots(figsize=(8,6))
    for j,s in enumerate(STRATEGIES):
        x,y=lookup[s,'coverage'],lookup[s,'conversion']
        ax.scatter(boots['coverage'][:,j],boots['conversion'][:,j],s=4,alpha=.05,color=colors[s],rasterized=True)
        ax.errorbar(x['mean'],y['mean'],xerr=[[x['mean']-x['ci95_low']],[x['ci95_high']-x['mean']]],
                    yerr=[[y['mean']-y['ci95_low']],[y['ci95_high']-y['mean']]],fmt='o',ms=7,capsize=3,color=colors[s],label=f'{s} · {LABELS[s]}')
        ax.annotate(s,(x['mean'],y['mean']),xytext=(7,6),textcoords='offset points',fontweight='bold',color=colors[s])
    nd=sorted([r for r in frontier if r['nondominated_mean']],key=lambda r:r['coverage_mean'])
    if len(nd)>1:ax.plot([r['coverage_mean'] for r in nd],[r['conversion_mean'] for r in nd],ls='--',lw=1,color='black',zorder=0)
    ax.set_xlabel('Cobertura media por WOM');ax.set_ylabel('Conversión media');ax.xaxis.set_major_formatter(PercentFormatter(1));ax.yaxis.set_major_formatter(PercentFormatter(1))
    ax.set_title('Frontera confianza–alcance en la condición base',fontweight='bold',pad=13)
    frontier_caption=('Línea: medias no dominadas entre A–E.' if len(nd)>1 else
                      f"{nd[0]['strategy']} es la única media no dominada entre A–E.")
    ax.grid(alpha=.16);ax.legend(frameon=False,loc='best');fig.text(.5,.02,'Nubes: 2.000 remuestreos de bloques · Barras: IC 95% puntuales de las medias\n'+frontier_caption+' No representa un óptimo universal.',ha='center',fontsize=8.5)
    fig.tight_layout(rect=(0,.07,1,1));savefig(fig,'frontera_confianza_alcance_base500')

    fig,axes=plt.subplots(2,3,figsize=(12,6.5),sharex=True,sharey=True)
    for ax,s in zip(axes.flat,STRATEGIES):
        rows=[r for r in trajectory if r['strategy']==s and r['metric']=='cumulative_new_adoptions']
        x=[r['month'] for r in rows]
        ax.fill_between(x,[r['p05'] for r in rows],[r['p95'] for r in rows],color=colors[s],alpha=.18)
        ax.plot(x,[r['median'] for r in rows],color=colors[s],lw=1.8,label='Mediana')
        ax.plot(x,[r['mean'] for r in rows],color=colors[s],lw=1,ls=':',label='Media')
        ax.axvline(12,color='#777777',ls='--',lw=.9);ax.set_title(f'{s} · {LABELS[s]}',fontweight='bold');ax.grid(alpha=.16);ax.set_xlim(0,60);ax.set_ylim(bottom=0)
    axes.flat[-1].axis('off')
    axes.flat[-1].text(.02,.9,'Banda: percentiles 5–95 entre corridas.\nLínea continua: mediana.\nLínea punteada: media.\n\nLa banda no es un intervalo de confianza.\n\nCorte vertical: cierre del período 12.\nD cambia su mezcla desde el período 13.',transform=axes.flat[-1].transAxes,va='top',fontsize=9,linespacing=1.5)
    fig.suptitle('Difusión en 500 corridas — Python v0.2',fontweight='bold');fig.supxlabel('Período del modelo');fig.supylabel('Nuevas adopciones acumuladas (excluye 12 iniciales)')
    fig.tight_layout(rect=(.015,.02,1,.95));savefig(fig,'trayectorias_base500')


def savefig(fig,name):
    fig.savefig(FIGURES/f'{name}.png',facecolor='white')
    fig.savefig(FIGURES/f'{name}.pdf',facecolor='white',metadata={'CreationDate':None,'ModDate':None})
    import matplotlib.pyplot as plt
    plt.close(fig)


if __name__=='__main__':
    main()
