# Artículo 5 — Comparación base de 500 corridas, Python v0.2

Ejercicio académico sin calibración empírica. Cinco estrategias por 100 repeticiones emparejadas, con riesgo 0,50 y mu 0,20. Se conserva el motor v0.2 utilizado en el piloto. Las 500 corridas se ejecutaron y auditaron; las 25 correspondientes a las primeras cinco repeticiones reprodujeron los resultados numéricos del piloto.

## Archivos y lectura

Los ZIP comparten la carpeta superior `Article_5_Base_500_v0.2`. Extraer código, datos, verificación y análisis en un mismo directorio. Los 20 ZIP de datos abarcan cinco repeticiones cada uno (25 corridas); sus nombres indican el primer y último número de repetición. Son archivos ZIP independientes, no fragmentos binarios de un ZIP único.

- `engine/`: motor, configuración y auditor v0.2, intactos.
- `design/`: diseño congelado y plan de las 500 corridas.
- `provenance/`: especificación histórica y 25 comprobantes del piloto usados para verificar reproducción.
- `outputs/raw/`: 500 carpetas con 11 CSV y un manifiesto por corrida; incluye todas las trazas agente–período.
- `outputs/checks/`: 500 auditorías, comprobaciones emparejadas, reproducción del piloto y cierre.
- `outputs/tables/`: resultados por corrida, estadísticas, diferencias emparejadas, remuestreos, perfiles y trayectorias.
- `outputs/figures/`: tres figuras en PNG y PDF. Incluidas en el análisis y disponibles también en un ZIP separado.
- `outputs/Article_5_Informe_base_500_v0.2.md`: informe en español.

Leer primero el informe. La tabla breve es `headline_results.csv`; la base de 500 observaciones es `run_summary_500.csv`. `descriptive_statistics.csv` contiene media, DE, mediana, rango, cuartiles, IQR, P5/P95 e IC del 95%. `paired_summary.csv` conserva los diez contrastes, su tamaño e incertidumbre.

## Reproducir desde cero

Python 3.10 o posterior; entorno original Python 3.12.14. El motor y el auditor utilizan solo la biblioteca estándar. Descomprimir el paquete de código en un directorio nuevo, entrar a su carpeta y ejecutar:

```bash
python run_base500.py --workers 4
```

Cada proceso ejecuta un bloque completo de cinco estrategias. Las semillas no dependen de la cantidad ni del orden de los procesos. Se pueden ejecutar intervalos con `--start 1 --stop 10`. El ejecutor reanuda corridas ya auditadas únicamente después de confirmar integridad y compatibilidad de diseño y ejecutor. No utilizar `python -O`, que desactiva comprobaciones del auditor.

Con todos los datos y comprobantes descargados, `python run_base500.py --finalize-only` valida los archivos y regenera el cierre. Esta operación cambia su fecha; ejecutar después el análisis para actualizar su manifiesto. Para conservar el cierre original, el análisis verifica directamente su integridad sin regenerarlo.

## Reproducir el análisis

```bash
python -m pip install -r requirements-analysis.txt
python analyze_base500.py
```

NumPy procesa los remuestreos; Matplotlib genera las figuras. El análisis verifica los datos y comprobantes antes de calcular resultados. No modifica parámetros ni ejecuta simulaciones. Regenera tablas, figuras, informe y manifiesto del análisis. Requiere tener reunidos todos los ZIP de datos y verificación.

Para volver a crear los archivos de entrega:

```bash
python package_outputs.py
```

El empaquetador incluye únicamente las exportaciones enumeradas en los manifiestos, nunca temporales de escritura. El manifiesto de paquetes registra tamaños y SHA-256. Requiere espacio para unos 4 GB de CSV sin comprimir y sus ZIP adicionales.

## Diseño e interpretación

600 agentes, seis comunidades de 100, 12 promotores iniciales, 60 períodos, cuatro intentos por promotor y hasta dos por período. El diseño comparte red, atributos, consumidores, promotores y cinta de sorteos dentro de cada repetición. Hay 100 redes distintas. Las semillas base siguen `20260925 + 1000*(r-1)` para r de 1 a 100.

A prioriza vínculos fuertes. B prioriza débiles entre comunidades, después débiles internos, otros puentes y resto. C solicita A/B con probabilidades 0,50/0,50. D solicita A/B con 0,80/0,20 hasta el período 12 y 0,30/0,70 desde el 13. E selecciona uniformemente. Se registran ruta solicitada, nivel de prioridad usado, clase real y puente. Los recursos por promotor son iguales; el esfuerzo agregado puede crecer cuando se crean nuevos promotores.

La unidad independiente es el bloque de repetición, n = 100. No se tratan consumidores, períodos ni eventos como observaciones independientes para comparar estrategias. Las primeras cinco semillas coinciden con el piloto; se ejecutaron de nuevo y no se agregaron sus resultados como cinco repeticiones adicionales.

Los IC del 95% utilizan 2.000 remuestreos de bloques completos, semilla 20261001, NumPy `default_rng` (PCG64), y percentiles 2,5/97,5 con interpolación lineal. Los mismos índices de bloques se utilizan en todos los análisis y se exportan. Los contrastes de tasas usan pares con ambas tasas definidas y reportan n. Los intervalos son puntuales, sin ajuste por multiplicidad; no se calculan pruebas de significación. No incluyen incertidumbre sobre los parámetros o reglas del modelo.

## Diccionario mínimo

CSV: coma, punto decimal, UTF-8, `true`/`false`, `NA` para valores no definidos. Tasas en fracciones 0–1; el informe muestra porcentajes. Las fases `all`, `1_12` y `13_60` deben leerse como texto.

| Campo / archivo | Significado |
|---|---|
| `new_adoptions` | Adopciones nuevas; excluye 12 iniciales |
| `total_adoptions` | Iniciales más nuevas |
| `adoption_at_12` | Adopción total al cierre de 12 |
| `unique_reach`, `coverage` | Receptores únicos no iniciales; receptores / 588 |
| `conversion` | Nuevas adopciones / envíos |
| `eligible_conversion` | Nuevas adopciones / envíos recibidos antes de adoptar |
| `effort_efficiency` | Nuevas adopciones / intentos |
| `redundancy` | Exposiciones repetidas / envíos |
| `new_communities_adopted` | Comunidades adoptantes fuera de las dos inicialmente sembradas, máximo cuatro |
| `fallback_rate` | Intentos que usan nivel posterior al primero / intentos |
| `extinction_month`, `extinction_event` | Período de extinción y ocurrencia observada; NA si no ocurre en 60 |
| `early_extinction` | Sin capacidad de continuar al cierre de 12 |
| `attempts_after_12` | Intentos efectivamente observados en 13–60 |
| `time_*`, `event_*`, `observed_*` | Tiempo hasta 10%, 25% y 50% de adopción total; evento y censura |
| `paired_differences.csv` | Primera estrategia del rótulo menos segunda; diferencias de tasas guardadas como fracción |
| `selection_tier_summary.csv` | Media por corrida y proporción agrupada, esta última rotulada `pooled` |
| `conversion_by_actual_tie_class.csv` | Adopciones/envíos por clase realmente utilizada; comparación descriptiva, no efecto causal puro |
| `finite_trust_reach_frontier.csv` | No dominación puntual, en medias bootstrap y dentro de repeticiones |

Las tasas medias no se ponderan por número de eventos. Los tiempos entre corridas que alcanzaron un umbral y las extinciones observadas son resúmenes condicionales. No se convierte censura en evento. Las bandas de P5–P95 en las trayectorias muestran variación de corridas, no IC de medias. Las frecuencias de no dominación no son probabilidades de optimalidad universal.

## Alcance de esta entrega

Completa únicamente la comparación base de 500 corridas. Los análisis de riesgo, separación de comunidades, portafolio y sensibilidad continúan pendientes. No se realiza calibración empírica, no se seleccionan parámetros para obtener un ganador y no se modifica el manuscrito. La especificación histórica incluida conserva su fecha y sus estados de trabajo anteriores; el informe y los índices posteriores describen el avance actual.
